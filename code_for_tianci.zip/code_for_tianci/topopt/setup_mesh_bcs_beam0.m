function [mesh, mesh_data, geom, elem, Vrho] = setup_mesh_bcs_beam0(nelem, porder)

% Set number of dimensions and variables, check input
ndim = 2; nvar = ndim;
if rem(nelem(2), 2) ~= 0
    error('Must have even number of elements in y-direction');
end

% Domain limits
xlims = [0, 40];
ylims = [-12.5, 12.5];

% Create element geometry
qex = 3*porder; nquad = ceil(0.5*(qex+1));
geom = create_geom_hcube(ndim, porder, nquad);

% Create finite element mesh
[xcg, e2vcg, e2bnd] = create_mesh_hcube([xlims(:)'; ylims(:)'], nelem, porder, 1:4);
[~, f2v, ~] = create_nodes_bndy_refdom_hcube(ndim, porder);
ldof2gdof = create_map_ldof_to_gdof(nvar, e2vcg);
[cooidx, lmat2gmat] = create_sparsity_struct(ldof2gdof);
[nnode_per_elem, nelem] = size(e2vcg);

% Create isoparametric data
mesh_data = create_mesh_data(geom, xcg, e2vcg, e2bnd);

% Update elem, elem_data for particular application
E = 1; nu = 0.3; f = zeros(ndim, 1);
K = E/3/(1-2*nu); lam = E*nu/(1+nu)/(1-2*nu); mu = (3/2)*(K-lam);
eqn_pars_fcn = @(x) [lam; mu; f];
nbc_val_fcn = @(x, bnd) [0; -0.02]*(bnd==3)*(abs(x(2))<1);
[elem, mesh_data] = create_elem_update_mesh_data_linelast(geom, mesh_data);
elem.lam = lam; elem.mu = mu;
mesh_data = update_mesh_data_pars(mesh_data, [], eqn_pars_fcn, nbc_val_fcn);

% Extract indices and set values of dirichlet boundary conditions
dbc_idx = get_gdof_from_bndtag(1:ndim, 1, ndim, ldof2gdof, e2bnd, f2v);
dbc_val = 0*dbc_idx;

% Create structure for convenience
mesh = struct('xcg', xcg, 'e2vcg', e2vcg, 'e2bnd', e2bnd, ...
              'dbc_idx', dbc_idx, 'dbc_val', dbc_val, ...
              'ldof2gdof', ldof2gdof, 'cooidx', cooidx, ...
              'lmat2gmat', lmat2gmat);
          
% Compute element centroids
xdg = reshape(xcg(:, e2vcg), [ndim, nnode_per_elem, nelem]);
ecntr = squeeze(mean(xdg, 2));

% Use a basis to parametrize a few topologies
ntop = 10;
Vrho = zeros(nelem, ntop);
Vrho(:, 1) = ones(nelem, 1);
Vrho(:, 2) = (ecntr(1, :)-8).^2+(ecntr(2, :)-8).^2 < 3^2;
Vrho(:, 3) = (ecntr(1, :)-20).^2+(ecntr(2, :)-8).^2 < 3^2;
Vrho(:, 4) = (ecntr(1, :)-32).^2+(ecntr(2, :)-8).^2 < 3^2;
Vrho(:, 5) = (ecntr(1, :)-8).^2+(ecntr(2, :)).^2 < 3^2;
Vrho(:, 6) = (ecntr(1, :)-20).^2+(ecntr(2, :)).^2 < 3^2;
Vrho(:, 7) = (ecntr(1, :)-32).^2+(ecntr(2, :)).^2 < 3^2;
Vrho(:, 8) = (ecntr(1, :)-8).^2+(ecntr(2, :)+8).^2 < 3^2;
Vrho(:, 9) = (ecntr(1, :)-20).^2+(ecntr(2, :)+8).^2 < 3^2;
Vrho(:, 10) = (ecntr(1, :)-32).^2+(ecntr(2, :)+8).^2 < 3^2;

end
function [mesh_data] = update_mesh_data_linelast_topo(mesh_data, rho, lam0, mu0)

nelem = numel(mesh_data);
nq = size(mesh_data(1).eqn_pars, 2);
for e = 1:nelem
    for k = 1:nq
        mesh_data(e).eqn_pars(:, k) = [rho(e)*lam0; rho(e)*mu0; mesh_data(e).eqn_pars(3:end, k)];
    end
end

end
function [y] = solve_rom_linelast_topo(yrho, Kr, Fr)

nrom_mat = numel(yrho);

% Compute reduced stiffness matrix given parameters yrho 
Krr = Kr(:, :, 1);
for k = 2:nrom_mat
    Krr = Krr + Kr(:, :, k)*yrho(k);
end

% Solve ROM
y = -Krr\Fr;

end
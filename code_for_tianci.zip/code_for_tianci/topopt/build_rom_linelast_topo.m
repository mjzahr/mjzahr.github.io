function [Kr, Fr] = build_rom_linelast_topo(V, Vrho, elem, mesh_data, dbc_idx, ldof2gdof, cooidx, lmat2gmat)

% Extract information from mesh
nrom_stvc = size(V, 2);
nrom_mat = size(Vrho, 2);
ndof = max(ldof2gdof(:));
U = zeros(ndof, 1);

% Build reduced force vector
[Fe, ~] = eval_unassembled_resjac(U, elem, mesh_data, ldof2gdof);
F = assemble_nobc_vec(Fe, ldof2gdof);
Ff = rstr_to_free_dof_vec(F, dbc_idx);
Fr = V'*Ff;

% Build reduced stiffness matrices
Kr = zeros(nrom_stvc, nrom_stvc, nrom_mat);
for k = 1:size(Vrho, 2)
    
    % Update mesh_data with new topology
    mesh_data = update_mesh_data_linelast_topo(mesh_data, Vrho(:, k), elem.lam, elem.mu);
    
    % Create unassembled element stiffness matrices, assemble stiffness
    % matrix, and restrict to free degrees of freedom
    [~, Ke] = eval_unassembled_resjac(U, elem, mesh_data, ldof2gdof);
    K = assemble_nobc_mat(Ke, cooidx, lmat2gmat, ldof2gdof);
    Kff = rstr_to_free_dof_mat(K, dbc_idx);
    
    % Project into reduced space
    Kr(:, :, k) = V'*Kff*V;
end

end
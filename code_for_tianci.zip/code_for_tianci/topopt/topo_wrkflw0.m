
% Setup mesh and boundary conditions
porder = 1;
nel = [80, 50];
[mesh, mesh_data, geom, elem, Vrho] = setup_mesh_bcs_beam0(nel, porder);
ndof = max(mesh.ldof2gdof(:));
ndbc = numel(mesh.dbc_idx);
free_idx = setdiff(1:ndof, mesh.dbc_idx);

% Create topology snapshots
nrom_mat = size(Vrho, 2);
nsamp_per_dim = 3;
nsnap = nsamp_per_dim^(nrom_mat-1);
R0 = tensprod_vector_from_onedim_unif(linspace(0, 1, nsamp_per_dim), nrom_mat-1);
R = [ones(1, nsnap); R0];

% Partition topology snapshots into test/train sets
train_idx = find(sum(R0, 1)==1 & any(R0==1, 1));
ntrain = numel(train_idx);

test_idx = find(sum(R0, 1)==1);
ntest = numel(test_idx);

train_test_idx = [train_idx, test_idx];
Itrain = 1:ntrain; Itest = ntrain+1:ntrain+ntest;
ntraintest = ntrain+ntest;

% Create snapshots by varying topologies
X = zeros(ndof-ndbc, ntraintest);
for k = 1:ntraintest
    % Update mesh
    rho = Vrho*R(:, train_test_idx(k));
    mesh_data = update_mesh_data_linelast_topo(mesh_data, rho, elem.lam, elem.mu);
    
    % Solve elasticity equations
    U_ = solve_fem_linelast_topo(rho, mesh, mesh_data, geom, elem, false);
    X(:, k) = U_(free_idx);
end
Xtrain = X(:, Itrain);
Xtest = X(:, Itest);

% Create reduced basis from snapshots
nrom_stvc = 6;
[U, S, ~] = svd(Xtrain, 'econ');
V = U(:, 1:nrom_stvc);

% Create reduced order model
dbc_idx = mesh.dbc_idx;
ldof2gdof = mesh.ldof2gdof;
cooidx = mesh.cooidx;
lmat2gmat = mesh.lmat2gmat;
[Kr, Fr] = build_rom_linelast_topo(V, Vrho, elem, mesh_data, dbc_idx, ldof2gdof, cooidx, lmat2gmat);

% Solve ROM at all training and testing points
Y = zeros(ndof-ndbc, ntraintest);
for k = 1:ntraintest
    yrho = R(:, train_test_idx(k));
    y = solve_rom_linelast_topo(yrho, Kr, Fr);
    Y(:, k) = V*y;
end
Ytrain = Y(:, Itrain);
Ytest = Y(:, Itest);

% Error
error_per_snapshot_train = max(abs(Xtest-Ytest), [], 1)
error_per_snapshot_test = max(abs(Xtest-Ytest), [], 1)

max_error_train = max(error_per_snapshot_train)
max_error_test = max(error_per_snapshot_test)
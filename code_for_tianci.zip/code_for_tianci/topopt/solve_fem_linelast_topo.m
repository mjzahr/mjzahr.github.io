function [U] = solve_fem_linelast_topo(rho, mesh, mesh_data, geom, elem, pltit)

% Extract information from mesh
xcg = mesh.xcg;
e2vcg = mesh.e2vcg;
e2bnd = mesh.e2bnd;
dbc_idx = mesh.dbc_idx;
dbc_val = mesh.dbc_val;
ldof2gdof = mesh.ldof2gdof;
cooidx = mesh.cooidx;
lmat2gmat = mesh.lmat2gmat;

% Modify topology
mesh_data = update_mesh_data_linelast_topo(mesh_data, rho, elem.lam, elem.mu);

% Solve FEM
[U, ~] = solve_fem_static(elem, mesh_data, dbc_idx, dbc_val, ldof2gdof, cooidx, lmat2gmat);

% Visualize
if pltit, visualize_fem(rho, xcg+reshape(U, [ndim, nnode]), e2vcg, e2bnd, geom, false, true); end

end
function [U, info] = solve_linelast_hcyl0(c, r1, r2, h, nelem, porder, pltit)
%SOLVE_LINELAST_HCYL0 Solve linear elasticity equation on hollow cylinder
%using FEM with simplex elements of polynomial completeness PORDER.
%
% Input arguments
% ---------------
%   XLIMS, YLIMS, ZLIMS : Array (2,) : Domain limits
%
%   NEL : Array (NDIM,) : Number of elements in mesh in each direction
%     (must be a multiple of 5 in z-direction for layered plate).
%
%   PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

ndim = 3; nvar = ndim;

% Create finite element mesh
[xcg, e2vcg, e2bnd] = create_mesh_hollow_cylinder(c, r1, r2, h, nelem, porder, 1:4);
ldof2gdof = create_map_ldof_to_gdof(nvar, e2vcg);

% Setup equation parameters and natural boundary conditions
E = 1; nu = 0.33; p1 = -1; p2 = 0.25;
K = E/3/(1-2*nu); lam = E*nu/(1+nu)/(1-2*nu); mu = (3/2)*(K-lam);
f = zeros(ndim, 1);
eqn_pars_fcn = @(x) [lam; mu; f];
nbc_val_fcn = @(x, bnd) [(p1/norm(x(1:2)-c,2))*(x(1:2)-c); 0]*(bnd==1) + [0; 0; p2]*(bnd==4);

% Extract indices and set values of dirichlet boundary conditions
[~, f2v, ~] = create_nodes_bndy_refdom_hcube(ndim, porder);
dbc_idx = get_gdof_from_bndtag(1:ndim, 2, ndim, ldof2gdof, e2bnd, f2v);
dbc_val = 0*dbc_idx;

% Solve linear elasticity
rbar = 0.5*(r1+r2);
xeval = [rbar*ones(1, 100); 0*ones(1, 100); linspace(0, h, 100)];
[U, ux, ~, ~, info] = solve_linelast('hcube', porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                                     eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, xeval);

if pltit
    figure;
    plot(xeval(3, :), ux(1, :), 'b-', 'linewidth', 2); hold on;
    plot(xeval(3, :), ux(2, :), 'k-', 'linewidth', 2);
    plot(xeval(3, :), ux(3, :), 'r-', 'linewidth', 2);
end

end
function [U, info] = solve_ins_nd0(rho, nu, porder, pltit, U0)
%SOLVE_INS_ND0 Solve for flow through the ND logo problem where the fluid
%is modeled by the incompressible Navier-Stokes equations using FEM on a
%simplicial mesh of polynomial completeness PORDER. 
%
% Input arguments
% ---------------
%   RHO, NU : number : Density and viscosity of the fluid
%
%   PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
%   U0 : Array (NDOF,) : Initial guess for solution (if no initial guess
%     available, use [])
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

ndim = 2;

% Create finite element mesh
[xcg, e2vcg, e2bnd] = load_mesh('nd', 'simp', porder);
[~, e2vcg2, ~] = load_mesh('nd', 'simp', porder-1);
ldof2gdof = create_map_ldof_to_gdof_mixed(ndim, e2vcg, 1, e2vcg2);

% Setup equation parameters and natural boundary conditions
nbc_val_fcn = @(x, bnd) 0;
eqn_pars_fcn = @(x) [rho; nu];

% Extract indices and set values of dirichlet boundary conditions
nv1 = size(e2vcg, 1);
ndofU = ndim*size(xcg, 2);
ldof2gdof1 = ldof2gdof(1:ndim*nv1, :);
xmin = min(xcg(1, :)); ymin = min(xcg(2, :));
[~, f2v, ~] = create_nodes_bndy_refdom_simp(ndim, porder);

dbc_idx1 = get_gdof_from_bndtag(1, 1, 2, ldof2gdof1, e2bnd, f2v);
dbc_idx2 = get_gdof_from_bndtag(2, 1, 2, ldof2gdof1, e2bnd, f2v);
dbc_idx3 = get_gdof_from_bndtag(1, 2, 2, ldof2gdof1, e2bnd, f2v); dbc_idx3 = zeros(1, 0);
dbc_idx4 = get_gdof_from_bndtag(2, 2, 2, ldof2gdof1, e2bnd, f2v); dbc_idx4 = zeros(1, 0);
dbc_idx5 = get_gdof_from_bndtag(1, 3, 2, ldof2gdof1, e2bnd, f2v);
dbc_idx6 = get_gdof_from_bndtag(2, 3, 2, ldof2gdof1, e2bnd, f2v);
dbc_idx7 = [0]+ndofU;
dbc_idx = [dbc_idx1; dbc_idx2; dbc_idx3; dbc_idx4; dbc_idx5; dbc_idx6; dbc_idx7];

dbc_val1 = 0*dbc_idx1;
dbc_val2 = 1 + 0*dbc_idx2;
dbc_val3 = 0*dbc_idx3;
dbc_val4 = 0*dbc_idx4;
dbc_val5 = 0*dbc_idx5;
dbc_val6 = 0*dbc_idx6;
dbc_val7 = 0*dbc_idx7;
dbc_val = [dbc_val1; dbc_val2; dbc_val3; dbc_val4; dbc_val5; dbc_val6; dbc_val7];

[dbc_idx, I, ~] = unique(dbc_idx);
dbc_val = dbc_val(I);

% Solve incompressible Navier-Stokes equations
xeval1 = [0.33*ones(1, 100); linspace(-1, 0, 100)];
xeval2 = [0.73*ones(1, 100); linspace(-1, 0, 100)];
xeval3 = [linspace(0, 1, 100); -0.25*ones(1, 100)];
xeval4 = [linspace(0, 1, 100); -0.64*ones(1, 100)];
xeval5 = [linspace(0.33, 0.71, 100); linspace(-0.075, -0.8, 100)];
xeval = [xeval1, xeval2, xeval3, xeval4, xeval5];
[U, ux, ~, info] = solve_ins('simp', porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                             eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, U0, ...
                             xeval);
ux1 = ux(:, 1:100);
ux2 = ux(:, 101:200);
ux3 = ux(:, 201:300);
ux4 = ux(:, 301:400);
ux5 = ux(:, 401:end);

if pltit
    figure;
    plot(xeval1(2, :), ux1(1, :), 'k-', 'linewidth', 2); hold on;
    plot(xeval1(2, :), ux1(2, :), 'r-', 'linewidth', 2);
    
    figure;
    plot(xeval2(2, :), ux2(1, :), 'k-', 'linewidth', 2); hold on;
    plot(xeval2(2, :), ux2(2, :), 'r-', 'linewidth', 2);
    
    figure;
    plot(xeval3(1, :), ux3(1, :), 'k-', 'linewidth', 2); hold on;
    plot(xeval3(1, :), ux3(2, :), 'r-', 'linewidth', 2);
    
    figure;
    plot(xeval4(1, :), ux4(1, :), 'k-', 'linewidth', 2); hold on;
    plot(xeval4(1, :), ux4(2, :), 'r-', 'linewidth', 2);
    
    figure;
    s = squeeze(sum(bsxfun(@minus, xeval5, xeval5(:, 1)).^2, 1));
    plot(s, ux5(1, :), 'k-', 'linewidth', 2); hold on;
    plot(s, ux5(2, :), 'r-', 'linewidth', 2);
end

end
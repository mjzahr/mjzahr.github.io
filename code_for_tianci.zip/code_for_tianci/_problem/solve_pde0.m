function [U, e, info] = solve_pde0(nelem, porder, pltit)
%SOLVE_PDE0 Solve PDE0 using FEM with NELEM elements of polynomial
%completeness PORDER
%
% Input arguments
% ---------------
%   NELEM : number : Number of elements in mesh
%
%   PORDER : number : Order of polynomial completeness
%
%   PLTIT : bool : Whether to plot solution
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   E : number : L2 error using mass matrix
%
%   INFO : See NEWTRAPH

% Create element and element data for particular element and application
ndim = 1; nquad = 3*2*(2*(porder-1)+1);
geom = create_geom_hcube(ndim, porder, nquad);

% Create finite element mesh
dlims = [0, 1];
[xcg, e2vcg, e2bnd] = create_mesh_hcube(dlims, nelem, porder, [1, 2]);
mesh_data = create_mesh_data(geom, xcg, e2vcg, e2bnd);
nnode = size(xcg, 2);

% Update elem, mesh_data for particular application
eqn_pars_fcn = @(x) x^2;
nbc_val_fcn = @(x, bnd) -1*(bnd==2);
[elem, mesh_data] = create_elem_update_mesh_data_pde0(geom, mesh_data);
mesh_data = update_mesh_data_pars(mesh_data, [], eqn_pars_fcn, nbc_val_fcn);

% Create ldof2gdof and sparsity structure
ldof2gdof = create_map_ldof_to_gdof(elem.nvar, e2vcg);
[cooidx, lmat2gmat] = create_sparsity_struct(ldof2gdof);

% Extract indices and set values of dirichlet boundary conditions
dbc_idx = get_gdof_from_bndtag(1, 1, elem.nvar, ldof2gdof, e2bnd, geom.f2v);
dbc_val = 0*dbc_idx;

% Solve finite element
tol = 1.0e-8; maxit = 10;
Uf0 = zeros(elem.nvar*nnode-numel(dbc_idx), 1);
[U, info] = solve_fem_static(elem, mesh_data, dbc_idx, dbc_val, ldof2gdof, cooidx, lmat2gmat, Uf0, tol, maxit);

% Visualize FEM solution and exact solution
Ue = (2*cos(1-xcg)-sin(xcg))/cos(1) + xcg.^2 - 2; Ue = Ue(:);
if pltit
    visualize_fem(U, xcg, e2vcg, e2bnd, geom, false, false);
    hold on;
    plot(xcg, Ue, 'ko');
end

% Compute L2 error
Me = eval_unassembled_mass(elem, mesh_data);
M = assemble_nobc_mat(Me, cooidx, lmat2gmat, ldof2gdof);
E = U-Ue;
e = sqrt(E'*M*E);

end
function [U, info] = solve_poi_nd0(porder, pltit)
%SOLVE_POI_ND0 Solve Poisson equation on ND logo mesh using FEM with
%simplex elements of polynomial completeness PORDER
%
% Input arguments
% ---------------
%   PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

ndim = 2;
nvar = 1;

% Load finite element mesh
[xcg, e2vcg, e2bnd] = load_mesh('nd', 'simp', porder);
ldof2gdof = create_map_ldof_to_gdof(nvar, e2vcg);

% Setup equation parameters and natural boundary conditions
I = eye(ndim);
eqn_pars_fcn = @(x) [I(:); 0];
nbc_val_fcn = @(x, bnd) 0*(bnd==3);

% Extract indices and set values of dirichlet boundary conditions
[~, f2v, ~] = create_nodes_bndy_refdom_simp(ndim, porder);

dbc_idx1 = get_gdof_from_bndtag(1, 1, nvar, ldof2gdof, e2bnd, f2v);
dbc_idx2 = get_gdof_from_bndtag(1, 2, nvar, ldof2gdof, e2bnd, f2v);
dbc_idx = [dbc_idx1; dbc_idx2];

dbc_val1 = 0*dbc_idx1;
dbc_val2 = 10+0*dbc_idx2;
dbc_val = [dbc_val1; dbc_val2];

% Solve Poisson equation
xeval = [linspace(0, 1, 100); -0.5*ones(1, 100)];
[U, ux, ~, ~, info] = solve_poi('simp', porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                                eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, ...
                                pltit, xeval);

if pltit
    figure;
    plot(xeval(1, :), ux, 'k-', 'linewidth', 2);
end

end
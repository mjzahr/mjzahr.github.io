function [U, info] = solve_poi_pde1(etype, nelem, porder, pltit)
%SOLVE_POI_PDE1 Solve PDE1 using FEM with NELEM elements of polynomial
%completeness PORDER
%
% Input arguments
% ---------------
%   ETYPE, NELEM, PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

ndim = 2;
nvar = 1;

% Create finite element mesh
[xcg, e2vcg, e2bnd] = create_mesh_hcube([0, 1; 0, 1], nelem, porder, 1:4);
if strcmpi(etype, 'simp')
    [e2vcg, e2bnd] = split_quad_mesh_into_tri_mesh(e2vcg, e2bnd);
end
ldof2gdof = create_map_ldof_to_gdof(nvar, e2vcg);

% Setup equation parameters and natural boundary conditions
I = eye(ndim);
eqn_pars_fcn = @(x) [I(:); 0];
nbc_val_fcn = @(x, bnd) 1*(bnd==1);

% Extract indices and set values of dirichlet boundary conditions
dbc_idx = find(xcg(1, :)'>1-1.0e-12|xcg(2, :)'>1-1.0e-12);
dbc_val = 0*dbc_idx;

% Solve Poisson equation
xeval = [linspace(0, 1, 100); 0.5*ones(1, 100)];
[U, ux, ~, ~, info] = solve_poi(etype, porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                                eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, xeval);
                         
if pltit
    figure;
    plot(xeval(1, :), ux, 'k-', 'linewidth', 2);
end

end
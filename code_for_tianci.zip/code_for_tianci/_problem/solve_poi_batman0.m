function [U, info] = solve_poi_batman0(porder, pltit)
%SOLVE_POI_BATMAN0 Solve Poisson equation on Batman mesh using FEM with
%simplex elements of polynomial completeness PORDER
%
% Input arguments
% ---------------
%   PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

ndim = 2;
nvar = 1;

% Load finite element mesh
[xcg, e2vcg, e2bnd] = load_mesh('batman', 'simp', porder);
ldof2gdof = create_map_ldof_to_gdof(nvar, e2vcg);

% Setup equation parameters and natural boundary conditions
K = [1, 0; 0, 10];
eqn_pars_fcn = @(x) [K(:); 0];
nbc_val_fcn = @(x, bnd) -10*sin(x(1))*(bnd==1|bnd==2);

% Extract indices and set values of dirichlet boundary conditions
[~, f2v, ~] = create_nodes_bndy_refdom_simp(ndim, porder);
dbc_idx = get_gdof_from_bndtag(1, 3, nvar, ldof2gdof, e2bnd, f2v);
dbc_val = 0*dbc_idx;

% Solve Poisson equation
xeval = [linspace(0.3, 0.7, 100); -0.2*ones(1, 100)];
[U, ux, ~, ~, info] = solve_poi('simp', porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                                  eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, ...
                                  pltit, xeval);
                              
if pltit
    figure;
    plot(xeval(1, :), ux, 'k-', 'linewidth', 2);
end

end
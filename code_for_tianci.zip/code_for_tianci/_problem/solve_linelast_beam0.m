function [U, info] = solve_linelast_beam0(xlims, ylims, nelem, etype, porder, pltit)
%SOLVE_LINELAST_BEAM0 Solve linear elasticity equation around
%multimaterial beam using FEM with simplex elements of polynomial
%completeness PORDER.
%
% Input arguments
% ---------------
%   XLIMS, YLIMS : Array (2,) : Domain limits
%
%   NEL : Array (NDIM,) : Number of elements in mesh in each direction
%     (must be even in x-direction for multimaterial beam).
%
%   ETYPE, PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

ndim = 2; nvar = ndim;

% Check input
if rem(nelem(1), 2)~=0, error('nelem(1) must be multiple of 2'); end

% Create finite element mesh
[xcg, e2vcg, e2bnd] = create_mesh_hcube([xlims(:)'; ylims(:)'], nelem, porder, 1:4);
if strcmpi(etype, 'simp')
    [e2vcg, e2bnd] = split_quad_mesh_into_tri_mesh(e2vcg, e2bnd);
    [~, f2v, ~] = create_nodes_bndy_refdom_simp(ndim, porder);
elseif strcmpi(etype, 'hcube')
    [~, f2v, ~] = create_nodes_bndy_refdom_hcube(ndim, porder);
end
ldof2gdof = create_map_ldof_to_gdof(nvar, e2vcg);

% Setup equation parameters and natural boundary conditions
xmid = mean(xlims);
nu = 0.33; f = zeros(ndim, 1);
E1 = 500; K1 = E1/3/(1-2*nu); lam1 = E1*nu/(1+nu)/(1-2*nu); mu1 = (3/2)*(K1-lam1);
E2 = 50; K2 = E2/3/(1-2*nu); lam2 = E2*nu/(1+nu)/(1-2*nu); mu2 = (3/2)*(K2-lam2);
eqn_pars_fcn = @(x) [lam1*(x(1)<xmid)+lam2*(x(1)>=xmid); mu1*(x(1)<xmid)+mu2*(x(1)>=xmid); f];
nbc_val_fcn = @(x, bnd) [0; -0.1]*(bnd==3);

% Extract indices and set values of dirichlet boundary conditions
dbc_idx = get_gdof_from_bndtag(1:ndim, 1, ndim, ldof2gdof, e2bnd, f2v);
dbc_val = 0*dbc_idx;

% Solve linear elasticity
xeval = [linspace(xlims(1), xlims(2), 100); mean(ylims)*ones(1, 100)];
[U, ux, ~, ~, info] = solve_linelast(etype, porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                                     eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, xeval);

if pltit
    figure;
    plot(xeval(1, :), ux(2, :), 'k-', 'linewidth', 2);
end

end
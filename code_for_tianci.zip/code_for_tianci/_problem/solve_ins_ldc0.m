function [U, info] = solve_ins_ldc0(rho, nu, L, etype, nelem, porder, pltit, U0)
%SOLVE_INS_LDC0 Solve the lid-driven cavity problem where the fluid is
%modeled by the incompressible Navier-Stokes equations using FEM on a mesh
%of ETYPE elements of polynomial completeness PORDER.
%
% Input arguments
% ---------------
%   RHO, NU : number : Density and viscosity of the fluid
%
%   L : number : Length of square domain
%
%   NELEM : Array (2,) : Number of elements in each direction
%
%   ETYPE, PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
%   U0 : Array (NDOF,) : Initial guess for solution (if no initial guess
%     available, use [])
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

ndim = 2;

% Create finite element mesh
[xcg, e2vcg, e2bnd] = create_mesh_hcube([0, L; 0, L], nelem, porder, 1:4);
[~, e2vcg2, ~] = create_mesh_hcube([0, L; 0, L], nelem, porder-1, 1:4);
if strcmpi(etype, 'simp')
    [e2vcg2, ~] = split_quad_mesh_into_tri_mesh(e2vcg2, e2bnd);
    [e2vcg, e2bnd] = split_quad_mesh_into_tri_mesh(e2vcg, e2bnd);
end
ldof2gdof = create_map_ldof_to_gdof_mixed(ndim, e2vcg, 1, e2vcg2);

% Setup equation parameters and natural boundary conditions
nbc_val_fcn = @(x, bnd) 0;
eqn_pars_fcn = @(x) [rho; nu];

% Extract indices and set values of dirichlet boundary conditions
ndofU = ndim*size(xcg, 2);
dbc_idx1 = find(xcg(1, :)'<1.0e-12 | xcg(2, :)'<1.0e-12 | xcg(1, :)'>L-1.0e-12);
dbc_idx2 = find(xcg(2, :)'>L-1.0e-12);
dbc_idx3 = find(xcg(1, :)'<1.0e-12 & xcg(2, :)'<1.0e-12);
dbc_idx = [2*(dbc_idx1-1)+1; 2*dbc_idx1; ...
           2*(dbc_idx2-1)+1; 2*dbc_idx2; ndofU+dbc_idx3];

dbc_val1 = 0*dbc_idx1;
dbc_val2 = 1 + 0*dbc_idx2;
dbc_val3 = 0*dbc_idx3;
dbc_val = [dbc_val1; dbc_val1; dbc_val2; 0*dbc_val2; dbc_val3];

[dbc_idx, I, ~] = unique(dbc_idx);
dbc_val = dbc_val(I);

% Solve incompressible Navier-Stokes equations
xeval = [linspace(0, L, 100); 0.75*L*ones(1, 100)];
[U, ux, ~, info] = solve_ins(etype, porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                             eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, U0, ...
                             xeval);

if pltit
    figure;
    plot(xeval(1, :), ux(1, :), 'k-', 'linewidth', 2); hold on;
    plot(xeval(1, :), ux(2, :), 'r-', 'linewidth', 2);
end

end
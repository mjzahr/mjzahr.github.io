function [U, info] = solve_poi_cube0(nelem, porder, pltit)
%SOLVE_POI_CUBE0 Solve Poisson equation on unit cube.
%
% Input arguments
% ---------------
%   NELEM : Array (3,) : Number of elements in each direction
%
%   PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

nvar = 1; ndim = 3;

% Create finite element mesh
[xcg, e2vcg, e2bnd] = create_mesh_hcube([0, 1; 0, 1; 0, 1], nelem, porder, 1:6);
ldof2gdof = create_map_ldof_to_gdof(nvar, e2vcg);

% Setup equation parameters and natural boundary conditions
K = diag([10, 1, 100]);
eqn_pars_fcn = @(x) [K(:); 1];
nbc_val_fcn = @(x, bnd) (x(1)+x(2)+x(3))*(bnd==1||bnd==2||bnd==4||bnd==5);

% Extract indices and set values of dirichlet boundary conditions
[~, f2v, ~] = create_nodes_bndy_refdom_hcube(ndim, porder);

dbc_idx3 = get_gdof_from_bndtag(1, 3, 1, ldof2gdof, e2bnd, f2v);
dbc_val3 = 0*dbc_idx3;

dbc_idx6 = get_gdof_from_bndtag(1, 6, 1, ldof2gdof, e2bnd, f2v);
dbc_val6 = sin(2*pi*xcg(1, dbc_idx6)').*cos(2*pi*xcg(2, dbc_idx6)');

dbc_idx = [dbc_idx3; dbc_idx6];
dbc_val = [dbc_val3; dbc_val6];

% Solve Poisson equation
%xeval = [linspace(0, 1, 100); 0.5*ones(1, 100); 0.5*ones(1, 100)];
[Yeval, Xeval] = meshgrid(linspace(0, 1, 100));
xeval = [Xeval(:), Yeval(:), 0.5+0*Xeval(:)]';
[U, ux, ~, ~, info] = solve_poi('hcube', porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                                eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, xeval);

if pltit
    figure;
    %plot(xeval(1, :), ux, 'k-', 'linewidth', 2);
    surf(Xeval, Yeval, reshape(ux, 100, 100));
end

end
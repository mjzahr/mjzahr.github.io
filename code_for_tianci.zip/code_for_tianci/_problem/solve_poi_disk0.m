function [U, e, info] = solve_poi_disk0(etype, nelem, porder, pltit)
%SOLVE_POI_DISK0 Solve Poisson equation on unit disk.
%
% Input arguments
% ---------------
%   NELEM : Array (2,) : Number of elements in each direction
%
%   ETYPE, PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   E : number : L2 error using mass matrix
%
%   INFO : See NEWTRAPH

nvar = 1;

% Create finite element mesh
[xcg, e2vcg, e2bnd] = create_mesh_hsphere([0; 0], 1, nelem, porder);
if strcmpi(etype, 'simp')
    [e2vcg, e2bnd] = split_quad_mesh_into_tri_mesh(e2vcg, e2bnd);
end
ldof2gdof = create_map_ldof_to_gdof(nvar, e2vcg);

% Setup equation parameters and natural boundary conditions
K = eye(2);
eqn_pars_fcn = @(x) [K(:); 1];
nbc_val_fcn = @(x, bnd) 0;

% Extract indices and set values of dirichlet boundary conditions
dbc_idx = find(xcg(1, :)'.^2+xcg(2, :)'.^2>1-1.0e-12);
dbc_val = 0*dbc_idx;

% Evaluate exact solution on mesh
Ue = (1-xcg(1, :).^2-xcg(2, :).^2)/4; Ue = Ue(:);

% Solve Poisson equation
xeval = [linspace(-1, 1, 100); 0*ones(1, 100)];
[U, ux, ~, e, info] = solve_poi(etype, porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                                eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, ...
                                xeval, Ue);
                     
if pltit
    figure;
    plot(xeval(1, :), ux, 'k-', 'linewidth', 2);
end

end
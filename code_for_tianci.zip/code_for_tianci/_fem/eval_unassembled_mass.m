function [Me] = eval_unassembled_mass(elem, mesh_data)
%EVAL_UNASSEMBLED_MASS Evaluate/store element mass matrices for each
%element. 
%
% Input arguments
% ---------------
%   ELEM, MESH_DATA : See notation.m. MESH_DATA in this function
%     is a *single* entry of the MESH_DATA structure array, i.e.,
%     MESH_DATA(e) where e is the element number.
%
% Output arguments
% ----------------
%   ME : Array (NDOF_PER_ELEM, NDOF_PER_ELEM, NELEM): Element matrix for
%     all elements in mesh

% Extract relevant variables from element
nelem = numel(mesh_data);
ndof_per_elem = elem.ndof_per_elem;

% Preallocate and assemble
Me = zeros(ndof_per_elem, ndof_per_elem, nelem);
for e = 1:nelem
    Me(:, :, e) = eval_elem_mass_isoparam(elem, mesh_data(e));
end

end
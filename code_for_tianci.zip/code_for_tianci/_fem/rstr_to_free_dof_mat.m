function  [Mr] = rstr_to_free_dof_mat(M, dbc_idx)
%RSTR_TO_FREE_DOF_MAT Restrict matrix defined over all global degrees of
%freedom to only the free degrees of freedom (without prescribed primary
%variable), i.e., remove all rows/cols corresponding to indices in DBC_IDX.
%
%Input arguments
%---------------
%   M : Array (NDOF, NDOF) : Matrix defined over all global degrees of
%     freedom 
%
%   DBC_IDX : See notation.m
%
%Output arguments
%----------------
%   MR : Array (NDOF-NDBC, NDOF-NDBC) : M with rows/columns restricted to
%     free degrees of freedom 

% Define indices of force BCs from indices of Dirichlet BCs
ndof = size(M, 1);
free_idx = setdiff(1:ndof, dbc_idx);

% Partition stiffness/force into fix/free dofs
Mr = M(free_idx, free_idx);

end
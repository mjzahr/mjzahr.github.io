function [U, info] = solve_fem_static(elem, mesh_data, dbc_idx, dbc_val, ldof2gdof, cooidx, lmat2gmat, Uf0, tol, maxit)
%SOLVE_FEM_STATIC Solve nonlinear finite element problem given complete
%description of mesh, PDE, and boundary conditions.
%
% Input arguments
% ---------------
%   ELEM, MESH_DATA, DBC_IDX, DBC_VAL: See notation.m
%
%   LDOF2GDOF, COOIDX, LMAT2GMAT : See notation.m
%
%   UF0 : Array (NDOF-NDBC,) : Initial guess for vector of primary
%     variables at free indices (where essential boundary condition not
%     given).
%
%   TOL, MAXIT : See SOLVE_NEWTRAPH
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Approximate solution of PDE (primary variables) for
%     all global degrees of freedom (assembled).
%
%   INFO : See SOLVE_NEWTRAPH

% Default arguments for u0, tol, maxit
ndof = max(ldof2gdof(:));
if nargin < 8, Uf0 = zeros(ndof-numel(dbc_idx), 1); end
if nargin < 9, tol = 1.0e-8; end
if nargin < 10, maxit = 10; end

% Create finite element residual/Jacobian function
fcn = @(u_) create_fem_resjac(u_, elem, mesh_data, dbc_idx, dbc_val, ldof2gdof, cooidx, lmat2gmat);

% Solve nonlinear system using Newton-Raphson
[Uf, info] = solve_newtraph(fcn, Uf0, tol, maxit);

% Assemble complete solution vector
U = zeros(ndof, 1);
U(dbc_idx) = dbc_val;
U(setdiff(1:ndof, dbc_idx)) = Uf;

end
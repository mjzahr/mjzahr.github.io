function [Rf, dRf] = create_fem_resjac(Uf, elem, mesh_data, dbc_idx, dbc_val, ldof2gdof, cooidx, lmat2gmat)
%CREATE_FEM_RESJAC Create the finite element residual and Jacobian,
%restricted to the free degrees of freedom. When combined with a nonlinear
%solver, this will approximate the solution of a PDE (described in ELEM,
%MESH_DATA) on the mesh (defined by ELEM, MESH_DATA).
%
% Input arguments
% ---------------
%   UF : Array (NDOF-NDBC,) : Global (assembled) solution vector,
%     restricted to the free degrees of freedom (via static condensation).
%
%   ELEM, MESH_DATA, DBC_IDX, DBC_VAL : See notation.m
%
%   LDOF2GDOF, COOIDX, LMAT2GMAT : See notation.m
%
% Output arguments
% -----------------
%   RF : Array (NDOF-NDBC,) : Finite element residual, restricted to free
%     degrees of freedom
%
%   DRF : Sparse matrix (NDOF-NDBC, NDOF-NDBC) : Finite element Jacobian
%     restricted to free degrees of freedom

% Create solution vector over all global degrees of freedom (combine UF and
% DBC_VAL) since entire vector needed for elementwise residual/Jacobian
% evaluation and subsequent assembly.
ndof = max(ldof2gdof(:));
free_idx = setdiff((1:ndof)', dbc_idx);
U = zeros(ndof, 1);
U(dbc_idx) = dbc_val;
U(free_idx) = Uf;

% Evaluate unassembled (elementwise) residual/Jacobian
%tic;
[Re, dRe] = eval_unassembled_resjac(U, elem, mesh_data, ldof2gdof);
%t1 = toc;
%disp(sprintf('Element evaluation = %e seconds', t1));

% Assemble residual/Jacobian
%tic;
R = assemble_nobc_vec(Re, ldof2gdof);
dR = assemble_nobc_mat(dRe, cooidx, lmat2gmat, ldof2gdof);
%t2 = toc;
%disp(sprintf('Assembly = %e seconds', t2));

% Restrict residual/Jacobian to free degrees of freedom
%tic;
Rf = rstr_to_free_dof_vec(R, dbc_idx);
dRf = rstr_to_free_dof_mat(dR, dbc_idx);
%t3 = toc;
%disp(sprintf('Apply DBC = %e seconds', t3));

end
function [Re, dRe] = eval_elem_resjac_isoparam(Ue, elem, mesh_data)
%EVAL_ELEM_RESJAC_ISOPARAM Evaluate element residual and Jacobian for
%isoparametric elements.
%
% Input arguments
% ---------------
%   UE : Array (NDOF_PER_ELEM,) : Element solution (primary variables)
%
%   ELEM, MESH_DATA : See notation.m
%
% Output arguments
% ----------------
%   RE : Array (NDOF_PER_ELEM,) : Element residual
%
%   DRE : Array (NDOF_PER_ELEM, NDOF_PER_ELEM) : Element Jacobian

% Extract information from input : sizes
ndim = elem.ndim;
neqn = elem.nvar;
nvar = elem.nvar;
nq = numel(elem.wq);
nqf = numel(elem.wqf);
nf = size(elem.ldof2fdof, 2);
ndof_per_elem = elem.ndof_per_elem;

% Extract information from input : quadrature
wq = elem.wq;
wqf = elem.wqf;

% Extract information from input : isoparametric
detG = mesh_data.detG;
sigf = mesh_data.sigf;

% Extract information from input : boundary
ldof2fdof = elem.ldof2fdof;
e2bnd = mesh_data.e2bnd;

% Extract information from input : basis
T = reshape(elem.T, [ndof_per_elem, nvar*nq]);
dTdx = reshape(mesh_data.dTdx, [ndof_per_elem, nvar*ndim*nq]);

% Preallocate element residual and Jacobian
Re = zeros(ndof_per_elem, 1);
dRe = zeros(ndof_per_elem, ndof_per_elem);

% Move primary variables from nodes to quadrature nodes
Uq = reshape(T'*Ue, [nvar, nq]);
dUq = reshape(dTdx'*Ue, [nvar, ndim, nq]);

% Integrate volume term
w = wq.*detG;
for k = 1:nq
    % Solution basis functions and a derivative at quadrature point
    T = elem.T(:, :, k);
    dTdx = reshape(mesh_data.dTdx(:, :, :, k), [ndof_per_elem, nvar*ndim]);
    
    % Evaluate pointwise quantities (flux, source) and reshape
    nu = mesh_data.eqn_pars(:, k);
    [F, dFdu, dFdq, S, dSdu, dSdq] = elem.eval_pntws_contrib(Uq(:, k), dUq(:, :, k), nu);

    F = reshape(F, [nvar*ndim, 1]);
    dFdu = reshape(dFdu, [neqn*ndim, nvar]);
    dFdq = reshape(dFdq, [neqn*ndim, nvar*ndim]);
    dSdq = reshape(dSdq, [neqn, nvar*ndim]);

    % Add contribution to element residual and Jacobian
    Re = Re + w(k)*(T*S-dTdx*F(:));
    dRe = dRe + w(k)*(T*(dSdu*T'+dSdq*dTdx')-dTdx*(dFdu*T'+dFdq*dTdx'));
end

% Integrate boundary term
wf = bsxfun(@(a, b) a.*b, wqf(:), sigf);
for f = 1:nf
    if isnan(e2bnd(f)), continue; end
    idx = ldof2fdof(:, f);
    for k = 1:nqf
        Tf = elem.Tf(:, :, k);
        qbar = mesh_data.nbc_val(:, k, f);
        Re(idx) = Re(idx) + wf(k, f)*(Tf*qbar);
    end
end

end
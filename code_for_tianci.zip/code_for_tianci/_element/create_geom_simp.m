function [geom] = create_geom_simp(ndim, porder, nquad_per_dim)
%CREATE_GEOM_SIMP Create structure defining the simplex element.
%
%Input arguments
%---------------
%   NDIM, PORDER : See notation.m
%
%   NQUAD_PER_DIM : number : Number of quadrature nodes per dimension
%
%Output arguments
%----------------
%   GEOM : See notation.m

% Create geometry
[zk, f2v, N] = create_nodes_bndy_refdom_simp(ndim, porder);
[rk, ~, ~] = create_nodes_bndy_refdom_simp(ndim-1, porder);

% Extract relevant information
%nf = size(f2v, 2);
%nnode_per_elem = size(zk, 2);

% Quadrature nodes, volume and faces
[w0, z0] = create_quad_onedim_gaussleg(nquad_per_dim);

[w_hcube, z_hcube] = create_quad_hcube_from_onedim(ndim, w0, z0);
[wq, zq] = create_quad_simp_from_hcube(w_hcube, z_hcube);

[wf_hcube, r_hcube] = create_quad_hcube_from_onedim(ndim-1, w0, z0);
[wqf, rq] = create_quad_simp_from_hcube(wf_hcube, r_hcube);

% Basis functions, volume and faces
[Q, dQdz] = eval_interp_simp_lagrange(zk, zq);
[Qf, dQfdr] = eval_interp_simp_lagrange(rk, rq);

% Create element structures
geom = struct('etype', 'simp', 'porder', porder, ...
              'zk', zk, 'rk', rk, 'f2v', f2v, 'N', N, ...
              'wq', wq, 'zq', zq, 'Q', Q, 'dQdz', dQdz, ...
              'wqf', wqf, 'rq', rq, 'Qf', Qf, 'dQfdr', dQfdr, ...
              'eval_basis', @(z_) eval_interp_simp_lagrange(zk, z_));

end
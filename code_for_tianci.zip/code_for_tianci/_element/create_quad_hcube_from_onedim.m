function [w, z] = create_quad_hcube_from_onedim(ndim, w0, z0)
%QUAD_ONEDIM_GAUSSLEG Compute N^d-point Gauss-Legendre quadrature rule in
%d-dimension, i.e., tensor product of one-dimensional Gaussian quadrature
%rules corresponding to Legendre orthogonal polynomials.
%
%Input arguments
%---------------
%   NDIM : Number of spatial dimensions
%
%   N : Number of points in quadrature rule
%
%Output arguments
%----------------
%   W : Array (NQ,) : Quadrature weights
%
%   Z : Array (NDIM, NQ) : Quadrature points

% Treat 0-dimensional case (single point) as special case
if ndim == 0
    w = 1; z = [];
    return;
end

% General case using tensor products
w = tensprod_scalar_from_onedim_unif(w0, ndim);
z = tensprod_vector_from_onedim_unif(z0, ndim);

end
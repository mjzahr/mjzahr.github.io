function [Q, dQ] = eval_interp_hcube_lagrange(xk0, x)
%EVAL_INTERP_HCUBE_LAGRANGE Evaluate interpolation functions from
%interpolation nodes in one-dimension (interpolation nodes of hypercube is
%the tensor product of these nodes).
%
%Input arguments
%---------------
%   XK0 : Array (NV0,) : Nodes at which Lagrange polynomials interpolate
%    values (nodes defining Lagrange polynomials) in each dimension.
%
%   X : Array (NDIM, NX) : Points at which Lagrange polynomials are
%     evaluated. 
%
%Output arguments
%----------------
%   Q : Array (NV, NX) : Interpolation functions for the hypercube element
%     evaluated at each point in X.
%
%   DQ : Array (NV, NDIM, NX) : Derivative of interpolation
%     functions evaluated at each point in X.

% Extract information from input
[ndim, nx] = size(x);
nv0 = numel(xk0);
nv = nv0^ndim;

% Construct 1d basis functions at each point (all dimensions)
[xr, ~, Ixr] = unique(x(:));
[Q0, dQ0] = eval_interp_onedim_lagrange(xk0, xr);
Q0 = reshape(Q0(:, Ixr), [nv0, ndim, nx]);
dQ0 = reshape(dQ0(:, Ixr), [nv0, ndim, nx]);

% Preallocate
Q = zeros(nv, nx);
dQ = zeros(nv, ndim, nx);

% Tensor product of 1D basis functions
for k = 1:nx
    Q0_ = num2cell(Q0(:, :, k), 1);
    Q_ = tensprod_scalar_from_onedim(Q0_);
    Q(:, k) = Q_(:);
    for j = 1:ndim
        dQ0_ = Q0_;
        dQ0_{j} = dQ0(:, j, k);
        dQ_ = tensprod_scalar_from_onedim(dQ0_);
        dQ(:, j, k) = dQ_(:);
    end
end

end
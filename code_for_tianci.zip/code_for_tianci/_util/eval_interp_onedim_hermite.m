function [Q, dQ] = eval_interp_onedim_hermite(xk, x)
%EVAL_INTERP_ONEDIM_HERMITE Evaluate Hermite interpolation functions on
%interval (-1, 1) associated with nodes XK (number of nodes = NV) at points
%X (number of points = NX).
%
%Input arguments
%---------------
%   XK : Array (NV,) : Nodes at which Hermite polynomials interpolate
%    values and derivatives (nodes defining Hermite polynomials).
%
%   X : Array (NX,) : Points at which Hermite polynomials are evaluated.
%
%Output arguments
%----------------
%   Q : Array (2*NV, NX) : Hermite interpolation functions (2*NV)
%     evaluated at each point in X.
%
%   DQ : Array (2*NV, NX) : Derivative of Hermite interpolation
%     functions (2*NV) evaluated at each point in X.

% Extract information from input, ensure xk and x appropriately shaped
nv = numel(xk);
nx = numel(x);
xk = xk(:); x = x(:);

% Evaluate Lagrange polynomials and polynomial that is zero at xk
[Ql, dQl] = eval_lagrange_interp_1d(xk, x);
[lp, lpp] = eval_poly_zeros_derivs(xk, xk);

% Evaluate Hermite polynomials
% Reference: http://mathworld.wolfram.com/HermitesInterpolatingPolynomial.html
Q = ones(2, nv, nx);
dQ = zeros(2, nv, nx);
for k=1:nx
    for i=1:nv
        Q(1, i, k) = (1-lpp(i)/lp(i)*(x(k)-xk(i)))*Ql(i, k)^2;
        dQ(1, i, k) = Ql(i, k)*(2*(1-lpp(i)/lp(i))*(x(k)-xk(i))*dQl(i, k)-Ql(i, k)*lpp(i)/lp(i));
        Q(2, i, k) = (x(k)-xk(i))*Ql(i, k)^2;
        dQ(2, i, k) = Ql(i, k)*(Ql(i, k) + 2*(x(k)-xk(i))*dQl(i, k));
    end
end
Q = reshape(Q, [2*nv, nx]);
dQ = reshape(dQ, [2*nv, nx]);

end

function [l] = eval_poly_zeros_vals(xk, x)
%EVAL_POLY_ZEROS_VALS Evaluate the polynomial at the points in X that
%attains a zero at the nodes in XK.
%
%Input arguments
%---------------
%   xk, x : See description in EVAL_HERMITE_INTERP_1D
%
%Output arguments
%----------------
%   l : Array (NX,) : Values of polynomial at points in X

nx = numel(x);
nv = numel(xk);

l = ones(nx, 1);
for i=1:nv, l = l.*(x-xk(i)); end

end

function [lp, lpp] = eval_poly_zeros_derivs(xk, x)
%EVAL_POLY_ZEROS_DERIVS Evaluate the derivatives of the polynomial at the
%points in X that attains a zero at the nodes in XK.
%
%Input arguments
%---------------
%   XK, X : See description in EVAL_HERMITE_INTERP_1D
%
%Output arguments
%----------------
%   lp : Array (NX,) : Derivative of polynomial at points in X
%   lpp : Array (NX,) : 2nd derivative of polynomial at points in X

nv = numel(xk);
nx = numel(x);

lp = zeros(nx, 1);
lpp = zeros(nx, 1);

for i=1:nv
    xik = setdiff(xk, xk(i));
    lp = lp + eval_poly_zeros_vals(xik, x);
    for j=1:nv
        if i==j, continue; end;
        xijk = setdiff(xik, xk(j));
        lpp = lpp + eval_poly_zeros_vals(xijk, x);
    end
end

end
function [Q, dQ] = eval_interp_onedim_lagrange(xk, x)
%EVAL_INTERP_ONEDIM_LAGRANGE Evaluate Lagrange interpolation functions on
%interval (XK(1), XK(end)) associated with nodes XK (number of nodes = nv)
%at points X (number of points = NX).
%
%Input arguments
%---------------
%   XK : Array (NV,) : Nodes at which Lagrange polynomials interpolate
%    values (nodes defining Lagrange polynomials).
%
%   X : Array (NX,) : Points at which Lagrange polynomials are evaluated.
%
%Output arguments
%----------------
%   Q : Array (NV, NX) : Lagrange interpolation functions (NV) evaluated
%     at each point in X. 
%
%   DQ : Array (NV, NX) : Derivative of Lagrange interpolation functions
%     (NV) evaluated at each point in X.

% Extract information from input, ensure xk and x appropriately shaped
nv = numel(xk);
nx = numel(x);
xk = xk(:); x = x(:);

% Evaluate Lagrange polynomials
Q = ones(nv, nx);
dQ = zeros(nv, nx);
for k=1:nx
    for j=1:nv
        for i=1:nv
            if i==j, continue; end
            Q(j, k) = Q(j, k) * (x(k)-xk(i))/(xk(j)-xk(i));

            tmp = 1.0;
            for m=1:nv
                if (m==j||m==i), continue; end
                tmp = tmp * (x(k)-xk(m))/(xk(j)-xk(m));
            end
            dQ(j, k) = dQ(j, k) + tmp/(xk(j)-xk(i));
        end
    end
end

end
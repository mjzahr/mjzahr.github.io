function [u_np1, info] = advance_soln_bdf1_nonlin(u_n, dt, M, F_dF, tol, maxit)
%ADVANCE_SOLN_BDF1_NONLIN Advance a nonlinear system of ODEs defined by
%
%                      M * \dot{u} + f(u) = 0
%
% from time n to n+1 (step size = dt) using Backward Euler (BDF1).
%
%Input arguments
%---------------
%  U_N : Array (m,) : Solution vector at step n
%
%  DT : number : Time step
%
%  M : Array (m, m) : Mass matrix of ODE system
%
%  F_dF : function : Function defining the nonlinear force vector of ODE
%    system (f: Array (m,)) and its derivative with respect to u (dfdu:
%    Array (m, m)). The input to the function is the ODE state vector u.
%
%  TOL, MAXIT : See SOLV_NEWTRAPH
%
%Output arguments
%----------------
%  U_NP1 : Array (m,) : Solution vector at step n+1
%
%  INFO : See SOLV_NEWTRAPH

% Create a residual and Jacobian for the current time step
fcn = @(u_) resjac_bdf1_1step(u_, M, F_dF, dt);

% Solve nonlinear system using Newton-Raphson, use previous time step as
% initial guess
[u_np1, info] = solve_newtraph(fcn, u_n, tol, maxit);

end

function [R, dR] = resjac_bdf1_1step(u, M, F_dF, dt)
%RESJAC_BDF1_1STEP Residual and Jacobian of BDF1 nonlinear system (single
%time step) corresponding to ODE described in ADVANCE_SOLN_BDF1_NONLIN
%
%                 R = M*(u-u_n)/dt - f
%                dR = M/dt - df
%
%Input arguments
%----------------
%  u : Array (m,) : ODE solution (candidate) vector
%
%  M, F_DF, DT : See ADVANCE_SOLN_BDF1_NONLIN
%
%Output arguments
%----------------
%  R : Array (m,): BDF1 residual (single time step)
%
%  dR : Array (m, m): BDF1 Jacobian (dR/du)

[f, df] = F_dF(u);
R = M*(u-u_n)*(1/dt) + f;
dR = M*(1/dt) + df;

end

function [u_np1] = advance_soln_fe_lin(u_n, dt, M, K, F)
%ADVANCE_SOLN_FE_LIN Advance a linear system of ODEs defined by
%
%                  M * \dot{u} + K * u + F = 0
%
% from time n to n+1 (step size = dt) using Forward Euler.
%
%Input arguments
%---------------
%  u_n : Array (m,) : Solution vector at step n
%
%  dt : number : Time step
%
%  M : Array (m, m) : Mass matrix of ODE system
%
%  K : Array (m, m) : Stiffness matrix of ODE system
%
%  F : Array (m,) : Right-hand side (force vector) of ODE system
%
%Output arguments
%----------------
%  u_np1 : Array (m,) : Solution vector at step n+1

% Update solution
u_np1 = u_n - dt*(M\(K*u_n+F));

end
function [V, dV] = vander_simp(porder, x)
%VANDER_SIMP Compute NDIM-dimensional Vandermonde matrix of order PORDER
%for a  simplex and its derivative (NDIM determined from shape of X). The
%Vandermonde matrix, V, is the NX x M matrix  of multinomial terms and its
%derivative, dV, is the NX x M x NDIM matrix of the partial derivatives of
%multinomial terms, where M is the number of multinomial terms required for
%polynomial completeness (all combinations such that the sum of the
%exponents is <= porder), and X are the evaluation points.
%
%Input arguments
%---------------
%   PORDER : Polynomial degree of completeness
%
%   X : Array (NDIM, NX) : Points at which to evaluate multinomials in
%     definition of Vandermonde matrix 
%
%Output arguments
%----------------
%   V : Array (NX, M) : Vandermonde matrix
%
%   dV : Array (NX, M, NDIM) : Derivative of Vandermonde matrix

% Extract information from input
[ndim, nx] = size(x);

% Form exponents for entries of Vandermonde matrix
expnts = tensprod_vector_from_onedim_unif(0:porder, ndim);
expnts = expnts(:, sum(expnts, 1)<=porder);
N = size(expnts, 2);

% Form Vandermonde matrix
V = zeros(N, nx);
dV = zeros(N, ndim, nx);
for k = 1:nx
    for i = 1:N
        v = x(:, k).^expnts(:, i);
        V(i, k) = prod(v);
        for j = 1:ndim
            if expnts(j, i) == 0, dV(i, j, k) = 0; continue; end
            idx = setdiff(1:ndim, j);
            s = expnts(j, i);
            dV(i, j, k) = prod(v(idx))*s*x(j, k)^(s-1);
        end
    end
end
V = V';
dV = permute(dV, [3, 1, 2]);

end
function [u_np1] = advance_soln_bdf1_lin(u_n, dt, M, K, F)
%ADVANCE_SOLN_BDF1_LIN Advance a linear system of ODEs defined by
%
%                  M * \dot{u} + K * u + F = 0
%
% from time n to n+1 (step size = dt) using Backward Euler (BDF1).
%
%Input arguments
%---------------
%  u_n : Array (m,) : Solution vector at step n
%
%  dt : number : Time step
%
%  M : Array (m, m) : Mass matrix of ODE system
%
%  K : Array (m, m) : Stiffness matrix of ODE system
%
%  F : Array (m,) : Right-hand side (force vector) of ODE system
%
%Output arguments
%----------------
%  u_np1 : Array (m,) : Solution vector at step n+1

% Define time step system matrix and right-hand side using Backward Euler
A = (1/dt)*M + K;
b = -F + (1/dt)*(M*u_n);

% Solve system of equations for solution at time n+1
u_np1 = A\b;

end
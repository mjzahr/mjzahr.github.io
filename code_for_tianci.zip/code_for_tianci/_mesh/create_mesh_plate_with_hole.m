function [xcg, e2vcg, e2bnd] = create_mesh_plate_with_hole(xlims, ylims, c, r, ref, porder)
%CREATE_MESH_PLATE_WITH_HOLE Create a mesh of a plate with a hole using
%distmesh and save XCG, E2VCG, E2BND to a MAT file.
%
%Input arguments
%---------------
%  REF : number : Refinement level
%
%  PORDER : Array (M,) : All desired polynomial degrees of completeness.
%    The function will create one mesh for each PORDER.
%
%Output arguments
%----------------
%  XCG, E2VCG, E2BND : See notation.m

% Create signed distance function and use DISTMESH to create mesh
fd=@(p) ddiff(drectangle(p,xlims(1),xlims(2),ylims(1),ylims(2)), dcircle(p,c(1),c(2),r));
fh=@(p) 0.05+0.3*dcircle(p,c(1),c(2),r);
[p0,t0]=distmesh2d(fd,fh,0.05/(2^ref),[xlims(1),ylims(1); xlims(2),ylims(2)], ...
                   [xlims(1), ylims(1); xlims(1), ylims(2); xlims(2), ylims(1); xlims(2), ylims(2); xlims(1), mean(ylims)], ...
                   200);

% Compute mesh statistics
nelem = size(t0, 1);
xlims = [min(p0(:, 1)), max(p0(:, 1))];
ylims = [min(p0(:, 2)), max(p0(:, 2))];

% Extract boundary edges (sort to facilitate search later)
ed0=sort(boundedges(p0, t0)', 1);

% Convert mesh into our format and create linear, simplex element in 2D
p0 = p0'; t0 = t0';
geom0 = create_geom_simp(2, 1, 1);

% Label boundaries, include plot to ensure boundary tagging succeeds
figure; simpplot(p0', t0'); hold on;
e2bnd = nan(3, nelem);
for e = 1:nelem
    for f = 1:3
        ed = sort(t0(geom0.f2v(:, f), e), 1);
        if ~ismember(ed', ed0', 'rows'), continue; end 
        x = p0(:, t0(geom0.f2v(:, f), e));
        if all(x(1,:)<xlims(1)+1.0e-4)
            e2bnd(f, e) = 1;
        elseif all(x(2,:)<ylims(1)+1.0e-4)
            e2bnd(f, e) = 2;
        elseif all(x(1,:)>xlims(2)-1.0e-4)
            e2bnd(f, e) = 3;
        elseif all(x(2,:)>ylims(2)-1.0e-4)
            e2bnd(f, e) = 4;
        else
            e2bnd(f, e) = 5;
        end
    end
end

% Create mesh for each PORDER required and save to MAT file
for p=porder
    [xcg, e2vcg] = refine_simp_mesh_porder(p0, t0, geom0.porder, p);
    save(['_mesh/_meshes/plate-with-hole-ref',num2str(ref),'-simp-p', num2str(p)], 'xcg', 'e2vcg', 'e2bnd');
end

end
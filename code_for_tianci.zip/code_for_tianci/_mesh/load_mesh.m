function [xcg, e2vcg, e2bnd] = load_mesh(mshnm, etype, porder, dire)
%LOAD_MESH Load mesh from database.
%
% Input arguments
% ---------------
%   MSHNM : string : Prefix of mesh file
%
%   ETYPE, PORDER : See notation.m
%
%   DIRE: string : Path to _meshes directory. Default is .\_mesh\_meshes\
%     (if PC) and ./_mesh/_meshes/ (otherwise).
%
% Output arguments
% ----------------
%   XCG, E2VCG, E2BND : See notation.m

delim = '/';
if ispc, delim='\'; end
if nargin<4, dire=sprintf('_mesh%s_meshes%s', delim, delim); end

fname = sprintf('%s%s-%s-p%d.mat', dire, mshnm, etype, porder);
msh = load(fname);
xcg = msh.xcg; e2vcg = msh.e2vcg; e2bnd = msh.e2bnd;

end
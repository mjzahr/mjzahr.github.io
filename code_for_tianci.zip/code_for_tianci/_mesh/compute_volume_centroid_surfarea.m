function [V, C, S] = compute_volume_centroid_surfarea(geom, mesh_data)
%COMPUTE_VOLUME_CENTROID_SURFAREA Compute the volume, centroid, and surface
%area of a domain (approximated) by the mesh described by GEOM, MESH_DATA.
%
%Input arguments
%---------------
%  GEOM, MESH_DATA : See notation.m
%
%Output arguments
%----------------
%  V : number : Volume of domain
%
%  C : Array (NDIM,) : Centroid of domain
%
%  S : number : Surface area of domain

% Extract relevant quantities
ndim = size(geom.zk, 1);
nf = size(geom.f2v, 2);
nelem = numel(mesh_data);

% Initialize volume, centroid, surface area
C = zeros(ndim, 1);
V = 0.0; S = 0.0;

% Quadrature over each element
for e = 1:nelem
    V = V + geom.wq'*mesh_data(e).detG;
    C = C + mesh_data(e).xq*(geom.wq.*mesh_data(e).detG);
    for f = 1:nf
        if isnan(mesh_data(e).e2bnd(f)), continue; end
        S = S + geom.wqf'*mesh_data(e).sigf(:, f);
    end
end
C = C/V;

end
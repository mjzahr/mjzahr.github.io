function [xq, detG, Gi, xqf, sigf] = eval_isoparam_quant(xe, Q, dQdz, Qf, dQfdr, f2v)
%EVAL_ISOPARAM_QUANT Evaluate isoparametric quantities for a single element
%given the nodal coordinates of the element in physical space (XE) and the
%basis functions (and their derivatives) over the element and its faces.
%
%Input arguments
%---------------
%  XE, Q, DQDZ, QF, DQFDR, F2V : See notation.m
%
%Output arguments
%----------------
%  XQ, DETG, GI, XQF, SIGF : See notation.m

% Extract information from input
ndim = size(xe, 1);
nf = size(f2v, 2);
nx = size(Q, 2);
nxf = size(Qf, 2);

% Preallocate arrays
xq = zeros(ndim, nx);
detG = zeros(nx, 1);
Gi = zeros(ndim, ndim, nx);

xqf = zeros(ndim, nxf, nf);
sigf = zeros(nxf, nf);

% Compute isoparametric volume terms
for k = 1:nx
    xq(:, k) = xe*Q(:, k);
    G = xe*dQdz(:, :, k);
    detG(k) = det(G);
    Gi(:, :, k) = inv(G);
end

% Compute isoparametric face terms
for f = 1:nf
    xef = xe(:, f2v(:, f));
    for k = 1:nxf
        xqf(:, k, f) = xef*Qf(:, k);
        if ndim == 1, sigf(k, :) = [-1, 1]; continue; end
        Gf = xef*dQfdr(:, :, k);
        sigf(k, f) = sqrt(det(Gf'*Gf));
    end
end

end
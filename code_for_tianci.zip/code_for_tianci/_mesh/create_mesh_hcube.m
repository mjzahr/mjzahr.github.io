function [xcg, e2vcg, e2bnd] = create_mesh_hcube(lims, nel, porder, bndtag)
%CREATE_MESH_HCUBE Create a mesh of a hypercube in NDIM-dimensions
%using hypercube elements.
%
%Input arguments
%---------------
%   LIMS : Array (NDIM, 2) : Extents of domain in each direction
%
%   NEL : Array (NDIM,) : Number of elements in mesh in each direction
%
%   PORDER : See notation.m
%
%   BNDTAG : Array (2*NDIM,) : Boundary tag for each of the 2*NDIM
%     boundaries to be used in the construction of E2BND. Boundaries
%     i=1:NDIM are the boundaries where the outward unit normal vector is
%     -ei (ei is the canonical unit vector: all zeros except for a 1 in the
%     ith entry) and boundaries i=NDIM+1:2*NDIM are the boundaries where
%     the outward unit normal vector is +ej (j=i-NDIM). For example, if
%     NDIM = 2 and BNDTAG = [1, 1, 2, 3], if face f of element e touches:
%     the left or bottom boundaries E2BND(f, e) = 1,  the right boundary
%     E2BND(f, e) = 2, the top boundary E2BND(f, e) = 3. Default is
%     BNDTAG = 1:2*NDIM.
%
%Output arguments
%----------------
%   XCG, E2VCG, E2BND : See notation.m

% Extract information from input and set default BNTAG
nel = nel(:)';
ndim = numel(nel);
nf = 2*ndim;
nelem = prod(nel);
if nargin<4, bndtag=zeros(1, 2*ndim); end

% Create nodes (XCG) via a tensor product
v = cell(1, ndim);
for k=1:ndim
    v{k} = linspace(lims(k, 1), lims(k, 2), nel(k)*porder+1);
end
xcg = tensprod_vector_from_onedim(v);

% Create ndim array of all node numbers and indices into it that will help
% extract node numbers for each element
if ndim == 1
    M = 1:nel*porder+1;
else
    M = reshape(1:prod(nel*porder+1), [nel*porder+1]);
end
idx_start = cell(1, ndim);
idx_offset = cell(1, ndim);
for k = 1:ndim
    idx_start{k} = 1:porder:nel(k)*porder;
    idx_offset{k} = 1:porder+1;
end
strt = M(idx_start{:}); strt = strt(:);
off = M(idx_offset{:}); off = off(:)-1;

% Create connectivity matrix
e2vcg = zeros((porder+1)^ndim, nelem);
for e=1:nelem
    e2vcg(:, e) = strt(e) + off;
end

% Set boundary tags
e2bnd = nan(2*ndim, nelem);
[~, f2v, ~] = create_nodes_bndy_refdom_hcube(ndim, porder);
for e=1:nelem
    for f=1:nf
        face_nodes = xcg(:, e2vcg(f2v(:, f), e));
        for d=1:ndim
            if all(face_nodes(d, :) == lims(d, 1))
                e2bnd(f, e) = bndtag(d);
            elseif all(face_nodes(d, :) == lims(d, 2))
                e2bnd(f, e) = bndtag(ndim+d);
            end
        end
    end
end

end
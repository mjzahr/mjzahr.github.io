function [F, dFdu, dFdq, S, dSdu, dSdq] = eval_pntws_contrib_linelast(u, q, eqn_pars)
%EVAL_PNTWS_CONTRIB_LINELAST Evaluate the flux function and source term
%(and their derivatives) that define the linear elasticity equation. 
%
% Input arguments
% ---------------
%   U : Array (NC,) : Primary variables
%
%   Q : Array (NC, NDIM) : Gradient of primary variables
%
%   EQN_PARS : Array (M,) : Parameters to flux function and source term
%
% Output arguments
% ----------------
%   F, DFDU, DFDQ, S, DSDU, DSDQ : See notation.m

% Extract information from input
ndim = size(q, 1);

% Define information regarding size of the system
neqn = ndim; ncomp = ndim;

% Extract parameters
lam = eqn_pars(1);
mu = eqn_pars(2);
f = eqn_pars(3:3+neqn-1);

% Define flux function and partial derivatives
F = lam*trace(q)*eye(ndim) + mu*(q+q');
dFdu = zeros(neqn, ndim, ncomp);
dFdq = zeros(neqn, ndim, ncomp, ndim);
for i=1:ndim
    for j=1:ndim
        dFdq(i, i, j, j) = dFdq(i, i, j, j) + lam;
        dFdq(i, j, i, j) = dFdq(i, j, i, j) + mu;
        dFdq(i, j, j, i) = dFdq(i, j, j, i) + mu;
    end
end

% Define source term and partial derivatives
S = f;
dSdu = zeros(neqn, ncomp);
dSdq = zeros(neqn, ncomp, ndim);

end
function [T, dTdz, Tf, ldof2fdof] = create_soln_basis_ldof2fdof_linelast(Q, dQdz, Qf, f2v)
%CREATE_SOLN_BASIS_LDOF2FDOF_POI Create solution basis (element and face)
%and its derivative w.r.t. reference coordinates and the face-to-element
%degree of freedom mapping for linear elasticity.
%
% Input arguments
% ---------------
%   Q, DQDZ, QF, F2V : See notation.m
%
% Output arguments
% ----------------
%   T, DTDZ, TF, LDOF2FDOF : See notation.m

% Extract information from input
ndim = size(dQdz, 2);
[nv, nq] = size(Q);
[nvf, nqf] = size(Qf);
nf = size(f2v, 2);

% Mapping from element dof to face dof
ldof2fdof = zeros(nvf*ndim, nf);
for d=1:ndim
    ldof2fdof(d:ndim:end, :) = ndim*(f2v-1)+d;
end

% Solution basis
nvar = ndim;
T = zeros(nv*nvar, nvar, nq);
Tf = zeros(nvf*nvar, nvar, nqf);
dTdz = zeros(nv*nvar, nvar, ndim, nq);
for d = 1:ndim
    T(d:ndim:end, d, :) = Q;
    Tf(d:ndim:end, d, :) = Qf;
    dTdz(d:ndim:end, d, :, :) = dQdz;
end

end
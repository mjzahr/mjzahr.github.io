function [mesh_data] = update_mesh_data_pars(mesh_data, mass_par_fcn, eqn_pars_fcn, nbc_val_fcn)
%UPDATE_MESH_DATA_PARS Update mesh_data structure with parameters stored at
%quadrature nodes of volume and face.
%
% Input arguments
% ---------------
%   MESH_DATA : See notation.m
%
%   MASS_PAR_FCN : function : Function that evaluates mass matrix
%     parameter, given spatial position. Input : x (Array (NDIM,)) :
%     spatial position. Default value is the 1 function (if MASS_PAR_FCN =
%     []).
%
%   EQN_PARS_FCN : function : Function that evaluates flux/source term
%     parameters, given spatial position. Input : x (Array (NDIM,)) :
%     spatial position. Default value is the 0 function (if EQN_PARS_FCN =
%     []).
%
%   NBC_VAL_FCN : function : Function that evaluates natural boundary
%     condition function, given spatial position and boundary tag.
%     Input : x (Array (NDIM,)) : spatial position
%             bnd (number) : Boundary tag of element face under
%             consideration.
%     Default value is the 0 function (if NBC_VAL_FCN = []).
%
% Output arguments
% ----------------
%   MESH_DATA : Updated version of input that includes MASS_PAR, EQN_PARS,
%     NBC_VAL fields from evaluating the function MASS_PAR_FCN and
%     EQN_PARS_FCN at all volume quadrature nodes of each element and
%     NBC_VAL_FCN at all face quadrature nodes of each element.

% Extract information from input
nc = size(mesh_data(1).dTdx, 2);
nelem = numel(mesh_data);
[ndim, nq] = size(mesh_data(1).xq);
[~, nqf, nf] = size(mesh_data(1).xqf);

% Default arguments
if nargin < 2 || isempty(mass_par_fcn), mass_par_fcn = @(x) 1; end
if nargin < 3 || isempty(eqn_pars_fcn), eqn_pars_fcn = @(x) 0; end
if nargin < 4 || isempty(nbc_val_fcn) , nbc_val_fcn  = @(x, bnd) 0; end

% Parameters: mass matrix, equations, natural boundary conditions
m = numel(eqn_pars_fcn(zeros(ndim, 1))); % Evaluate function to get size
for e = 1:nelem
    % Pre-allocate
    mesh_data(e).mass_par = zeros(nq, 1);
    mesh_data(e).eqn_pars = zeros(m, nq);
    mesh_data(e).nbc_val = nan(nc, nqf, nf);

    % Volume quadrature nodes
    xq = mesh_data(e).xq;
    for k = 1:nq
        mesh_data(e).mass_par(k) = mass_par_fcn(xq(:, k));
        mesh_data(e).eqn_pars(:, k) = eqn_pars_fcn(xq(:, k));
    end

    % Face quadrature nodes
    for f = 1:nf
        bnd = mesh_data(e).e2bnd(f);
        if isnan(bnd), continue; end
        xqf = mesh_data(e).xqf(:, :, f);
        for k = 1:nqf
            mesh_data(e).nbc_val(:, k, f) = nbc_val_fcn(xqf(:, k), bnd);
        end
    end
end

end
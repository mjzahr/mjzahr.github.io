function [F, dFdu, dFdq, S, dSdu, dSdq] = eval_pntws_contrib_poi(u, q, eqn_pars)
%EVAL_PNTWS_CONTRIB_POI Evaluate the flux function and source term (and
%their derivatives) that define the Poisson equation. 
%
% Input arguments
% ---------------
%   U : Array (NC,) : Primary variables
%
%   Q : Array (NC, NDIM) : Gradient of primary variables
%
%   EQN_PARS : Array (M,) : Parameters to flux function and source term
%
% Output arguments
% ----------------
%   F, DFDU, DFDQ, S, DSDU, DSDQ : See notation.m

% Define information regarding size of the system
neqn = 1; ncomp = 1;

% Extract information from input
ndim = size(q, 2);
k = reshape(eqn_pars(1:ndim^2), [ndim, ndim]);
f = eqn_pars(ndim^2+1:end);

% Define flux function and partial derivatives
F = -k*q(:);
dFdu = zeros(neqn, ndim, ncomp);
dFdq = reshape(-k, [neqn, ndim, ncomp, ndim]);

% Define source term and partial derivatives
S = -f;
dSdu = zeros(neqn, ncomp);
dSdq = zeros(neqn, ncomp, ndim);

end
function [Sout] = compute_stress_linelast(stype, U, geom, xcg, e2vcg, ldof2gdof, eqn_pars_fcn)
%COMPUTE_STRESS_LINELAST Compute stress from linear elasticity FEM
%solution.
%
% Input arguments
% ---------------
%   STYPE : string ('mises', 'princ') : Which type of stress to return;
%     'mises' is von Mises stress, 'princ' is principle stresses.
%
%   U, GEOM, XCG, E2VCG, LDOF2GDOF, EQN_PARS_FCN : See notation.m
%
% Output arguments
% ----------------
%   SOUT : Array (..., NNODE) : Array containing the requested stress at
%     each node of the mesh. The size of the array depends on the requested
%     output: if STYPE=='mises', SOUT is (NNODE,) containing von Mises
%     stress at each noe, if STYPE=='princ', SOUT is (NDIM, NNODE)
%     containing the principle stresses at each node.

% Extract information from input
[ndim, nnode] = size(xcg);
[nv, nelem] = size(e2vcg);

% Create basis function evaluated at element nodes
if strcmpi(geom.etype, 'simp')
    [~, dQdz] = eval_interp_simp_lagrange(geom.zk, geom.zk);
elseif strcmpi(geom.etype, 'hcube')
    zk0 = unique(geom.zk(1, :));
    [Q0, dQ0] = eval_interp_onedim_lagrange(zk0, zk0);
    [~, dQdz] = eval_interp_hcube_from_onedim(ndim, Q0, dQ0);
else
    error('Element not supported.');
end

% Compute stress at each node of each element
Se = zeros(ndim, ndim, nv);
S = zeros(ndim, ndim, nnode);
for e = 1:nelem
    % Extract element degrees of freedom
    xe = xcg(:, e2vcg(:, e));
    Ue = reshape(U(ldof2gdof(:, e)), [ndim, nv]);
    
    for k = 1:nv
        % Compute derivative of basis function w.r.t. physical coordinates
        G = xe*dQdz(:, :, k);
        dQdx = (G'\dQdz(:, :, k)')';
        
        % Extract element degrees of freedom
        du = Ue*dQdx;
        
        % Stress (flux of linear elasticity equations)
        x = xe(:, k);
        eqn_pars = eqn_pars_fcn(x);
        [Se(:, :, k), ~, ~, ~, ~, ~] = eval_pntws_contrib_linelast([], du, eqn_pars);
    end
    
    % Assemble (by summing) into global stress array
    idx = e2vcg(:, e);
    S(:, :, idx) = S(:, :, idx) + Se; 
end

% Since assembly is a purely a summation, need to divide by the number
% of instances of each node in the mesh to get the average stress at each
% node
tbl = tabulate(e2vcg(:));
nrep_node = reshape(tbl(:, 2), [1, 1, nnode]);
S = S./repmat(nrep_node, [ndim, ndim, 1]);

% Compute specific stress type
if strcmpi(stype, 'mises')
    % Compute von Mises stress (plane strain if 1d, 2d)
    sig = zeros(3, 3, nnode);
    sig(1:ndim, 1:ndim, :) = S;
    t1 = (sig(1, 1, :)-sig(2, 2, :)).^2;
    t2 = (sig(2, 2, :)-sig(3, 3, :)).^2;
    t3 = (sig(3, 3, :)-sig(1, 1, :)).^2;
    t4 = sig(1, 2, :).^2+sig(2, 3, :).^2+sig(1, 3, :).^2;
    Sout = sqrt(0.5*(t1+t2+t3+6.0*t4));
    Sout = squeeze(Sout);
elseif strcmpi(stype, 'princ')
    % Compute principle stresses
    Sout = zeros(ndim, nnode);
    for k = 1:nnode
        Sout(:, k) = eig(S(:, :, k));
    end
end

end
function [T, dTdz, Tf, ldof2fdof] = create_soln_basis_ldof2fdof_ins(Q1, dQ1dz, Q1f, f2v1, ...
                                                                    Q2, dQ2dz, Q2f, f2v2)
%CREATE_SOLN_BASIS_LDOF2FDOF_INS Create solution basis (element and face)
%and its derivative w.r.t. reference coordinates and the face-to-element
%degree of freedom mapping for the incompressible Navier-Stokes equations.
%
% Input arguments
% ---------------
%   Q1, DQ1DZ, Q1F, F2V1 : Q, DQDZ, QF, F2V (see notation.m) for the
%     velocity element.
%
%   Q2, DQ2DZ, Q2F, F2V2 : Q, DQDZ, QF, F2V (see notation.m) for the
%     pressure element.
%
% Output arguments
% ----------------
%   T, DTDZ, TF, LDOF2FDOF : See notation.m

% Extract information from input
ndim = size(dQ1dz, 2);
nf = size(f2v1, 2);
[nv1, nq] = size(Q1);
[nvf1, nqf] = size(Q1f);
[nv2, ~] = size(Q2);
[nvf2, ~] = size(Q2f);

% Mapping from element dof to face dof
ldof2fdof = zeros(nvf1*ndim+nvf2*1, nf);
for d=1:ndim
    ldof2fdof(d:ndim:nvf1*ndim, :) = ndim*(f2v1-1)+d;
end
ldof2fdof(nvf1*ndim+1:end, :) = f2v2+nv1*ndim;

% Solution basis
nvar = ndim+1;
ndof_per_elem = nv1*ndim+nv2*1;
ndof_per_face = nvf1*ndim+nvf2*1;
T = zeros(ndof_per_elem, nvar, nq);
Tf = zeros(ndof_per_face, nvar, nqf);
dTdz = zeros(ndof_per_elem, nvar, ndim, nq);
for d = 1:ndim
    T(d:ndim:nv1*ndim, d, :) = Q1;
    Tf(d:ndim:nvf1*ndim, d, :) = Q1f;
    dTdz(d:ndim:nv1*ndim, d, :, :) = dQ1dz;
end
T(nv1*ndim+1:end, end, :) = Q2;
Tf(nvf1*ndim+1:end, end, :) = Q2f;
dTdz(nv1*ndim+1:end, end, :, :) = dQ2dz;

end
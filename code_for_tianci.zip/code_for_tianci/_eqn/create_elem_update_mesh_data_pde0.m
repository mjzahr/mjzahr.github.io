function [elem, mesh_data] = create_elem_update_mesh_data_pde0(geom, mesh_data)
%CREATE_ELEM_UPDATE_MESH_DATA_PDE0 Create ELEM structure for PDE0 and
%and update MESH_DATA structure with equation-specific information.
%
% Input arguments
% ---------------
%   GEOM, MESH_DATA : See notation.m
%
% Output arguments
% ----------------
%   ELEM, MESH_DATA : See notation.m. MESH_DATA updated to include
%     PDE-specific information, namely, dTdx (derivative of solution basis
%     w.r.t. physical coordinates).

% Evaluate eqn-specific information (solution basis, face-to-element dof)
[T, dTdz, Tf, ldof2fdof] = create_soln_basis_ldof2fdof_pde0(geom.Q, geom.dQdz, geom.Qf, geom.f2v);

% Update mesh_data with derivative of solution basis w.r.t. physical coords
mesh_data = update_mesh_data_soln_basis_deriv(dTdz, mesh_data);

% Create element structure
[ndof_per_elem, nvar, ndim, ~] = size(dTdz);
elem = struct('ndim', ndim, 'etype', geom.etype, 'porder', geom.porder, ...
              'nvar', nvar, 'ndof_per_elem', ndof_per_elem, ...
              'ldof2fdof', ldof2fdof, 'f2v', geom.f2v, ...
              'eval_pntws_contrib', @eval_pntws_contrib_pde0, ...
              'eval_soln_basis_pde0', @(z) eval_soln_basis_pde0(z, geom), ...
              'wq', geom.wq, 'wqf', geom.wqf, 'T', T, 'Tf', Tf);

end

function [T, dTdz] = eval_soln_basis_pde0(z, geom)
%EVAL_SOLN_BASIS_LINELAST Evaluate the solution basis given an arbitrary
%reference point (may not be quadrature node) for PDE0.
%
% Input arguments
% ---------------
%   Z : Array (NDIM,) : Point at which to evaluate solution basis
%
%   GEOM : See main function
%
% Output arguments
% ----------------
%   T, DTDZ : See notation.m. Solution basis and derivative evaluated at Z.

% Extract information from input
nvf = size(geom.Qf, 1);
nz = size(z, 2);

% Evaluate geometry basis
[Q, dQdz] = geom.eval_basis(z);
dum = zeros(nvf, nz);

% Evaluate solution basis
[T, dTdz, ~, ~] = create_soln_basis_ldof2fdof_pde0(Q, dQdz, dum, geom.f2v);

end
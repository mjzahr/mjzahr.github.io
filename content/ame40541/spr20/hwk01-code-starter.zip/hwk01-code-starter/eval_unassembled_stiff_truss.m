function [Ke] = eval_unassembled_stiff_truss(transf_data, EA)
%EVAL_UNASSEMBLED_STIFF_TRUSS Evaluate/sotre stiffness matrix for each
%element.
%
% Input arguments
% ---------------
%   TRANSF_DATA, EA : See notation.m
%
% Output arguments
% -----------------
%   KE : Array (ndim*nnode_per_elem, ndim*nnode_per_elem, nelem):
%     unassembled element stiffness matrices (KE(:, :, e) is the stiffness
%     matrix of element e).

% Extract information from input
ndim = size(transf_data(1).Q, 1);
ndof_per_elem = 2*ndim;
nelem = numel(EA);

% TODO: Finish me!

end
function [M] = assemble_nobc_mat_dense(Me, ldof2gdof)
%ASSEMBLE_NOBC_MAT Assemble element matrices into a global matrix without
%applying Dirichlet/essential boundary conditions.
%
%Input arguments
%---------------
%  ME : Array (NDOF_PER_ELEM, NDOF_PER_ELEM, NELEM): Element matrix for
%    all elements in mesh
%
%  LDOF2GDOF : See notation.m
%
%Output arguments
%----------------
%   M : Array (NDOF, NDOF) : Assembled matrix PRIOR to static condensation

% Extract quantities
N = max(ldof2gdof(:));
nelem = size(Me, 3);

% Preallocate M
M = zeros(N, N);

% TODO: Finish me!

end

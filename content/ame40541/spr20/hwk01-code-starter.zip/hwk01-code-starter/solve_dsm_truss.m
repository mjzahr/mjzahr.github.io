function [u, f] = solve_dsm_truss(msh, femsp, fbc_val)
%SOLVE_DSM_TRUSS Solve for the nodal displacements and reaction forces of a
%truss structure.
%
% Input arguments
% ---------------
%   MSH, FEMSP, FBC_VAL : See notation.m
%
% Output arguments
% -----------------
%   U, F : See notation.m

% TODO: Finish me!

end
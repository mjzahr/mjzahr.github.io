function u = viz_vel_ins2d(ax, qoi, msh, U, X, dU, skip_quiver)
%VIZ_VEL_INS2D Visualize solution or sensitivity of 2D incompressible
%Navier-Stokes equations.
%
%Quantities of interest
%----------------------
% qoi = 'vx' : x-velocity
% qoi = 'vy' : y-velocity
% qoi = 'vabs' : velocity magnitude
% qoi = 'vx_sens' : x-velocity sensitivity
% qoi = 'vy_sens' : y-velocity sensitivity
% qoi = 'vabs_sens' : velocity magnitude sensitivity

if nargin < 6 || isempty(dU), dU = 0*U; end
if nargin < 7, skip_quiver=false; end

% Extract information from input
[ndim, nv] = size(msh.xcg);

% Compute velocity-based quantity of interest
uv = reshape(U(1:ndim*nv), [ndim, nv]);
uv_sens = reshape(dU(1:ndim*nv), [ndim, nv]);
if strcmpi(qoi, 'vx')
    u = uv(1, :);
elseif strcmpi(qoi, 'vy')
    u = uv(2, :);
elseif strcmpi(qoi, 'vabs')
    u = sqrt(uv(1, :).^2 + uv(2, :).^2);
elseif strcmpi(qoi, 'vx_sens')
    u = uv_sens(1, :);
elseif strcmpi(qoi, 'vy_sens')
    u = uv_sens(2, :);
elseif strcmpi(qoi, 'vabs_sens')
    vabs = sqrt(uv(1, :).^2 + uv(2, :).^2);
    u = uv(1, :).*uv_sens(1, :) + uv(2, :).*uv_sens(2, :);
    u = u./vabs;
    u(isnan(u)) = 0;
else
    error('QoI not supported, only vx, vy, vabs');
end

% Plot heatmap of velocity magnitude
mshplt = create_mesh(msh.etype, reshape(X, size(msh.xcg)), msh.e2vcg, msh.e2bnd);
viz_fcnsp_msh_legacy(ax, mshplt, u(msh.e2vcg), struct('plot_elem', false));

% Quiver plot
if ~skip_quiver
    if contains(qoi, 'sens')
        quiver(X(1:2:end), X(2:2:end), uv_sens(1, :)', uv_sens(2, :)');
    else
        quiver(X(1:2:end), X(2:2:end), uv(1, :)', uv(2, :)');
    end
end

end
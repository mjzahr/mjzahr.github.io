function bvp = setup_bvp_ins2d_refmap_bypass0cfg0(vinlet, nu)
%SETUP_BVP_INS2D_REFMAP_BYPASS0CFG0 Setup boundary value problem
%corresponding to aortic bypass problem from Homework 3, problem 2.

ndim = 2;
claw = IncompressibleNavierStokes2dRefmapCore('cntrl');
bnd2nbc = [1, 1, 2, 1]; rho = 1;
f = zeros(ndim+1, 1); Qb = zeros(3, 1);
Ub = @(x, n, bnd, el, fc) [1; 0; 0]*((vinlet/0.15^2)*x(2,:).*(0.3-x(2,:)).*(bnd==2));
is_dbnd_fcn = @(x, n, bnd, el, fc) [bnd~=3; bnd~=3; norm(x-[3;-0.6])<1e-3];
dbc_val_fcn = @(x, n, bnd, el, fc) Ub(x, n, bnd, el, fc);
bvp = create_bndval_prob(claw, bnd2nbc, is_dbnd_fcn, dbc_val_fcn, f, Ub, Qb, rho, nu);

end
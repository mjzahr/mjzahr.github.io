function fem = setup_fem_bypass0cfg0(msh, bvp)
%SETUP_FEM_BYPASS0CFG0 Setup finite element structure for aortic bypass
%problem from Homework 3, problem 2.

ndim = size(msh.xcg, 1);
porder_soln = [msh.porder; msh.porder-1];
fem = create_fem_disc('cg', bvp, msh, [ndim, 1], porder_soln, ...
    porder_soln, ndim, msh.porder);

end
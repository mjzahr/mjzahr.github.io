function [fv, varargout] = eval_vortnrm2_bypass0cfg0(U, X, fem, welem)
%Integrate |\omega|^2 over all elements in specified in welem and partial
%derivatives w.r.t. U (second output) and X (third output).

% Setup QoI
qoivol = @(UQ, YZ, pars, x) fem.bvp.eqn.qoivolintg('vortnrm2', UQ, YZ, pars, x, zeros(1,size(x,2)));

% Integrate over all elements in welem
varargout = cell(1, max([0, nargout-1]));
[fv, varargout{:}] = compute_assembled_qoivol(qoivol, U, X, fem.bvp, fem.femsp, fem.qrule, welem);

end

vinlet = 10; % Inlet velocity
nu = 2e-2; % Viscosity
nref = 0; % Mesh refinement level
porder = 2;  % FE polynomial degree (solution and mesh)

%% Setup FEM discretization %%
msh = load_mesh('bypass0cfg0', 'simp', nref, porder, [], './');
bvp = setup_bvp_ins2d_refmap_bypass0cfg0(vinlet, nu);
fem = setup_fem_bypass0cfg0(msh, bvp);
viz_fcnsp_msh_legacy([], msh); % plot mesh

%%  Setup RBFs and run simulation %%
% Note: will not run until RBF implemented
R = 0.6; Xcntrl = [1; 0]; W = -0.3;
phi = compute_dist_eval_rbf_kern(msh.xcg, Xcntrl, R);
[F, dF, X, U, dUdW] = solve_prim_sens_eval_funcl_bypass_shapeopt(W, msh, fem, phi);
viz_vel_ins2d([], 'vabs', msh, U, msh.xcg(:), dUdW); colorbar;
viz_vel_ins2d([], 'vabs_sens', msh, U, msh.xcg(:), dUdW); colorbar;
function [F, varargout] = solve_prim_dual_eval_funcl_contaminv(U0, M, K, dt, nstep, Uhat, alpha, U0ref)
%SOLVE_PRIM_DUAL_EVAL_FUNCL_CONTAMINV Solve primal and adjoint equations
%(fully discrete) for contaminant problem, evaluate objective functional
%and its total derivative.

if nargin < 6, Uhat = 0*U0; end
if nargin < 7, alpha = 1; end
if nargin < 8, U0ref = 0*U0; end

% Setup variable output
varargout = cell(1, max([nargout-1, 0]));

% Run primal simulation
U = U0; % t=0
for k = 1:nstep
    U = advance_ode_lin_bdf1(U, dt, M, K);
end

% Evaluate functional
dU = U-Uhat;
dU0 = U0-U0ref;
F = 0.5*(dU'*(M*dU)) + 0.5*alpha*(dU0'*(M*dU0));
if nargout == 1, return; end

% Run adjoint simulation to compute adjoint variables (L)
% Code me!

% Gradient of objective (dF)
% Code me!

% Variable output
if nargout > 1, varargout{1} = dF; end
if nargout > 2, varargout{2} = U; end
if nargout > 3, varargout{3} = L; end

end

%% Setup FEM discretization %%
etype = 'hcube'; nelem = [10, 10]; porder = 2;
[msh, fem, M, K] = setup_convdiff_disc(etype, nelem, porder);

%% Create/visualize FE state %%
c = [0.0, 0.0]; w = sqrt(0.1);
U0 = solve_l2proj(@(x) exp(-((x(1,:)-c(1)).^2+(x(2,:)-c(2)).^2)/w^2), [], fem);
viz_fcnsp_msh_legacy([], msh, U0(fem.femsp.ldof2gdof_trial)); colorbar;

%% Run time-dependent simulation %%
% Note: will not run until implementation finished!
dt = 1e-2; nstep = 100;
Uhat = U0; U0ref = U0; alpha = 1; % Just made up values to demonstrate code!
[F, dF, U, L] = solve_prim_dual_eval_funcl_contaminv(U0, M, K, dt, nstep, Uhat, alpha, U0ref);
function [F, varargout] = solve_prim_sens_eval_funcl_bypass_shapeopt(W, msh, fem, phi, alpha)
%SOLVE_PRIM_SENS_EVAL_FUNCL_BYPASS_SHAPEOPT Solve primal and sensitivity
%equations (discrete) for bypass shape optimization problem, evaluate
%objective functional and its total derivative.

if nargin < 5, alpha = 0; end

% Setup variable output
varargout = cell(1, max([nargout-1, 0]));

% Identify elements over which vorticity to be integrated
xdg = reshape(msh.xcg(:, msh.e2vcg), [2, size(msh.e2vcg)]);
welem = squeeze(all(xdg(1, :, :)<=1.5 & xdg(1, :, :)>=0.15 & xdg(2, :, :)<=inf, 2));

% Compute mesh motion
X0 = msh.xcg(:);
dXdW0 = {}; if nargout > 1, dXdW0 = cell(1, 1); end
W0 = [0*W(:)'; W(:)']; W0 = W0(:);
[X, dXdW0{:}] = compute_meshmot_rbf(W0, X0, phi);
if numel(dXdW0) > 0
    dXdW{1} = dXdW0{1}(:, 2:2:end);
end

% Solve primal and integrate vorticity squared
U = solve_weak_newtraph(X, fem);

dfv = {}; if nargout > 1, dfv = cell(1, 2); end
[fv, dfv{:}] = eval_vortnrm2_bypass0cfg0(U, X, fem, welem);

% Evaluate objection function
F = fv + 0.5*alpha*(W(:)'*W(:));
if nargout == 1, return; end

% Setup partial derivatives for sensitivity computation
Uu = U(fem.dbc.free_idx);
[~, dRudU, dRdX] = compute_assembled_weak_statcond(Uu, X, fem);
dRdW = dRdX*dXdW{1};
dFdU = dfv{1};
dFdW = dfv{2}*dXdW{1}+alpha*W';

% Sensitivity equations
dUdW = zeros(numel(U), numel(W));
dUdW(fem.dbc.free_idx, :) = -(dRudU\dRdW);

% Compute gradient of objective
dF = dFdW+dFdU*dUdW;

% Variable output
if nargout > 1, varargout{1} = dF; end
if nargout > 2, varargout{2} = X; end
if nargout > 3, varargout{3} = U; end
if nargout > 4, varargout{4} = dUdW; end

end
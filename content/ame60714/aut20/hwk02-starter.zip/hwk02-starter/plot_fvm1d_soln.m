function ax = plot_fvm1d_soln(ax, x, Q, pltsty)
%PLOT_FVM1D_SOLN Plot finite volume (1d) solution

% Defaults
if isempty(ax)
    figure; ax = axes;
end
if nargin < 4 || isempty(pltsty)
    pltsty = {'k-'};
end

% Plot
set(ax, 'NextPlot', 'add');
for k = 1:numel(x)-1
    plot(x(k:k+1), Q(k)*ones(1, 2), pltsty{:});
end

end
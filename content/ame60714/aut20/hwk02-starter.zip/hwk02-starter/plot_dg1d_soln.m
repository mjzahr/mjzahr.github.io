function ax = plot_dg1d_soln(ax, xdg, Q, pltsty)
%PLOT_DG1D_SOLN Plot DG (1d) solution

% Defaults
if isempty(ax)
    figure; ax = axes;
end
if nargin < 4 || isempty(pltsty)
    pltsty = {'k-'};
end

% Plot
nelem = size(xdg, 3);
porder = numel(Q)/nelem-1;
Q = reshape(Q, porder+1, nelem);
N = 2; if porder>1, N=20; end
set(ax, 'NextPlot', 'add');
for e = 1:nelem
    p = polyfit(xdg(1, :, e), Q(:, e), porder);
    x0 = linspace(xdg(1, 1, e), xdg(1, end, e), N);
    plot(ax, x0, polyval(p, x0), pltsty{:});
end

end
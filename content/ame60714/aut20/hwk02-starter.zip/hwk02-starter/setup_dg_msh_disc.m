function [xdg, wq, T, Mi] = setup_dg_msh_disc(xlims, nelem, porder, nvar)
%SETUP_DG_MSH_DISC Setup DG mesh and discretization
%
%Input arguments
%---------------
%  XLIMS : Array (2,) : Domain limits
%
%  NELEM : number : Number of elements
%
%  PORDER : number : Polynomial degree
%
%  NVAR : number : Number of variables in conservation law
%
%Output arguments
%----------------
%  XDG : Array (1, NVPE, NELEM) : Nodal position for each element, i.e.,
%    XDG(:, :, e) = nodal positions for element e.
%
%  WQ : Array (NQ,) : Weights for quadrature rule
%
%  T : Array (NDOF_PER_ELEM, NVAR*(NDIM+1), NQ, NELEM) : Basis function and
%    their derivative for each element evaluated at each quadrature node,
%    i.e., T(:, 1:NVAR, j, e) = basis functions at quadrature node j of
%    element e and T(:, NVAR+1:end, j, e) = derivative of basis function at
%    quadrature node j of element e 
%
%  Mi : Array (NDOF_PER_ELEM, NDOF_PER_ELEM, NELEM) : Mass matrix inverse
%    for each element.

% Create mesh and quadrature rule
[xcg, e2vcg, ~] = create_smesh_hcube('hcube', xlims, nelem, max(1, porder));
xdg = reshape(xcg(:, e2vcg), [1, porder+1, nelem]);
dx = (max(xcg(:))-min(xcg(:)))/nelem;

% Create quadrature rule
[w, z] = define_quad_onedim_gaussleg(3*porder);
wq = w*0.5*dx;

% Evaluate basis and mass matrix inverse
ndim = 1;
nquad = numel(wq);
ndof_per_elem = nvar*(porder+1);
T = zeros(ndof_per_elem, nvar*(ndim+1), nquad, nelem);
Mi = zeros(ndof_per_elem, ndof_per_elem, nelem);
for e = 1:nelem
    xe = xcg(1, e2vcg(:, e));
    xq = xe(1)+0.5*(z+1)*(xe(end)-xe(1));
    xq = xq(:)';
    phi = eval_interp_onedim_lagrange(xe, xq);
    T(:, :, :, e) = extend_basis_sclr2vec(nvar, phi);
    Mi(:, :, e) = inv(intg_elem_mass(T(:, 1:nvar, :, e), wq));
end

end
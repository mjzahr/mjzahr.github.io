function [q, fs] = solve_riemann_prob_psys(ql, qr, x, t)
%SOLVE_RIEMANN_PROB_PSYS Solve Riemann problem for p-system and compute
%numerical flux (f(q(x, t)) given left (ql) and right (qr) states and
%evaluation points in space (x, Array (nx,)) and time (t, Array (nt,)).
%Output: q, Array (2, nx, nt) (Riemann solution); fs, Array (2, nx, nt)
%(numerical flux).

% Extract information from input
vl = ql(1); ul = ql(2);
vr = qr(1); ur = qr(2);
xt = x(:)*(1./t(:)');
xt = xt(:)';
q = zeros(2, numel(xt));

if vl == vr
    % Case 1: vl = vr : 1- and 2-rarefaction
    vm = 2*log((ur-ul+2*(exp(vl/2)+exp(vr/2)))/4);
    um = ur+2*exp(vr/2)-2*exp(vm/2);
    qm = [vm; um];
    s1_rar_lft = -exp(vl/2);
    s1_rar_rgt = -exp(vm/2);
    s2_rar_lft =  exp(vm/2);
    s2_rar_rgt =  exp(vr/2);
    
    idxl = find(xt<=s1_rar_lft);
    idxc1 = find(xt<=s1_rar_rgt&xt>s1_rar_lft);
    idxc2 = find(xt>s1_rar_rgt&xt<=s2_rar_lft);
    idxc3 = find(xt>s2_rar_lft&xt<=s2_rar_rgt);
    idxr = find(xt>s2_rar_rgt);
    
    xi1 = xt(idxc1);
    qrar1 = [2*log(-xi1); ul-2*exp(vl/2)-2*xi1];
    
    xi2 = xt(idxc3);
    qrar2 = [2*log(xi2); ur+2*exp(vr/2)-2*xi2];
    
    q(:, idxl) = repmat(ql, [1, numel(idxl)]);
    q(:, idxc1) = qrar1;
    q(:, idxc2) = repmat(qm, [1, numel(idxc2)]);
    q(:, idxc3) = qrar2;
    q(:, idxr) = repmat(qr, [1, numel(idxr)]);
    
elseif vl < vr
    % Case 2: vl < vr : 1-shock, 2-rarefaction
    fcn = @(vm) (ur-ul)-2*(exp(vm/2)-exp(vr/2))-sqrt((exp(vm)-exp(vl))/(vm-vl))*(vm-vl);
    vm = fsolve(fcn, 0.5*(vl+vr));
    um = ur+2*(exp(vr/2)-exp(vm/2));
    qm = [vm; um];
    s_shk = (um-ul)/(vl-vm);
    s_rar_lft = exp(vm/2);
    s_rar_rgt = exp(vr/2);
    
    idxl = find(xt<=s_shk);
    idxc1 = find(xt<=s_rar_lft&xt>s_shk);
    idxc2 = find(xt>s_rar_lft&xt<=s_rar_rgt);
    idxr = find(xt>s_rar_rgt);
    
    xi = xt(idxc2);
    qrar = [2*log(xi); ur+2*exp(vr/2)-2*xi];
    
    q(:, idxl) = repmat(ql, [1, numel(idxl)]);
    q(:, idxc1) = repmat(qm, [1, numel(idxc1)]);
    q(:, idxc2) = qrar;
    q(:, idxr) = repmat(qr, [1, numel(idxr)]);
    
elseif vl > vr
    % Case 3: vl > vr : 1-rarefaction, 2-shock
    fcn = @(vm) (ul-ur)+2*(exp(vm/2)-exp(vl/2))+sqrt((exp(vm)-exp(vr))/(vm-vr))*(vm-vr);
    vm = fsolve(fcn, 0.5*(vl+vr));
    um = ul-2*(exp(vl/2)-exp(vm/2));
    qm = [vm; um];
    s_shk = (um-ur)/(vr-vm);
    s_rar_lft = -exp(vl/2);
    s_rar_rgt = -exp(vm/2);
    
    idxl = find(xt<=s_rar_lft);
    idxc1 = find(xt<=s_rar_rgt&xt>s_rar_lft);
    idxc2 = find(xt>s_rar_rgt&xt<=s_shk);
    idxr = find(xt>s_shk);
    
    xi = xt(idxc1);
    qrar = [2*log(-xi); ul-2*exp(vl/2)-2*xi];
    
    q(:, idxl) = repmat(ql, [1, numel(idxl)]);
    q(:, idxc1) = qrar;
    q(:, idxc2) = repmat(qm, [1, numel(idxc2)]);
    q(:, idxr) = repmat(qr, [1, numel(idxr)]);
end
q = reshape(q, [2, numel(x), numel(t)]);
fs = [-q(2, :); -exp(q(1, :))];

end
function [msh, fem, K0, K1, K2, F] = setup_convdiff1_disc(etype, nelem_per_dim, porder)
%SETUP_CONVDIFF1_DISC Setup DG discretization of convection-diffusion for
%problem 4 of Homework 4.

% Define geometry and mesh %
msh = create_smesh_hsphere0(etype, [0; 0], sqrt(2), nelem_per_dim*[1, 1], porder);

% Setup boundary value problem %
claw = AdvectionDiffusion1v2dNomapRonquist0('upwind');
bnd2nbc = 0;
is_dbnd_fcn = @(x, n, bnd, el, fc) true;
dbc_val_fcn = @(x, n, bnd, el, fc) 0;
bvp = create_bndval_prob(claw, bnd2nbc, is_dbnd_fcn, dbc_val_fcn, [0; 0], 10);

% Create finite element space
fem = create_fem_disc_noaux('cg', bvp, msh, 1, porder);
ndof = max(fem.femsp.ldof2gdof_trial(:))-numel(fem.dbc.dbc_idx);

% Evaluate mass/stiffness matrix
U0 = zeros(ndof, 1);
fem.bvp.pars.gpars(1:2) = [0; 0];
[F, K0] = compute_assembled_weak_statcond(U0, [], fem);

fem.bvp.pars.gpars(1:2) = [0; 1];
[~, K1] = compute_assembled_weak_statcond(U0, [], fem);
K1 = K1-K0;

fem.bvp.pars.gpars(1:2) = [pi/2; 1];
[~, K2] = compute_assembled_weak_statcond(U0, [], fem);
K2 = K2-K0;

end
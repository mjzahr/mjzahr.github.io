%% Setup FEM discretization %%
etype = 'hcube'; nelem = [10, 10]; porder = 2;
[msh, fem, M, K] = setup_convdiff0_disc(etype, nelem, porder);

%% Seteup temporal discretization %%
T = 4; dt = 1e-2; nstep = T*100;

%% Run HDM simulation %%
U0 = solve_l2proj(@(x) 5*exp(-(x(1,:).^2+x(2,:).^2)/0.1), [], fem);
U = zeros(numel(U0), nstep+1);
U(:, 1) = U0;
for k = 1:nstep
    U(:, k+1) = advance_ode_lin_bdf1(U(:, k), dt, M, K);
end
viz_fcnsp_msh_legacy([], msh, U(fem.femsp.ldof2gdof_trial, end)); colorbar;
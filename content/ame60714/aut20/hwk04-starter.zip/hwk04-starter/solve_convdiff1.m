function U = solve_convdiff1(mu, K0, K1, K2, F)
%SOLVE_CONVDIFF1 Solve convection-diffusion equation from system matrices
%
g1 = mu(2)*cos(mu(1));
g2 = mu(2)*sin(mu(1));
K=K0+g1*K1+g2*K2;
U=-(K\F);
end
function [msh, fem, M, K] = setup_convdiff0_disc(etype, nelem, porder)
%SETUP_CONVDIFF_DISC Setup DG discretization of convection-diffusion for
%problem 3 of Homework 4.

% Define geometry and mesh %
msh = create_smesh_hcube(etype, [-1, 1; -1, 1], nelem, porder);

% Setup boundary value problem %
claw = AdvectionDiffusion1v2dNomapCore('upwind');
bnd2nbc = [3, 2, 3, 3];
f = 0; Qb = 0; Ub = 0; diffcoeff = 0.001*eye(2);
beta = @(x, el) [sin(pi*x(1,:)).*cos(pi*x(2,:)); -cos(pi*x(1,:)).*sin(pi*x(2,:))];
bvp = create_bndval_prob(claw, bnd2nbc, [], [], f, Ub, Qb, beta, diffcoeff(:), 0);

% Create finite element space
fem = create_fem_disc_noaux('dg', bvp, msh, 1, porder, [], [], 1, 1);
ndof = max(fem.femsp.ldof2gdof_trial(:));

% Evaluate mass/stiffness matrix
M = compute_assembled_mass(fem.femsp, fem.qrule);
[~, K] = compute_assembled_weak(zeros(ndof, 1), [], fem.bvp, fem.femsp, fem.qrule);

end
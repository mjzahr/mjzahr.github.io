function viz_convdiff1(msh, Uu, fem)
%VIZ_CONVDIFF1 Visualize convection-diffusion solution
ndof = max(fem.femsp.ldof2gdof_trial(:));
U = zeros(ndof, 1);
U(fem.dbc.free_idx) = Uu;
viz_fcnsp_msh_legacy([], msh, U(fem.femsp.ldof2gdof_trial));
end
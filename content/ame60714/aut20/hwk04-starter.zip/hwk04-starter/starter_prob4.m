%% Setup FEM discretization %%
etype = 'hcube'; nel_per_dim = 6; porder = 2;
[msh, fem, K0, K1, K2, F] = setup_convdiff1_disc(etype, nel_per_dim, porder);
ndof = numel(F);

%% Define test parameters, solve HDM %%
nsamp0 = [2, 2];
mu_unif = tensprod_vector_from_onedim(...
    {linspace(0, pi/2, nsamp0(1)), linspace(0, 10, nsamp0(2))}); % uniform sampling

U = zeros(ndof, prod(nsamp0));
for k=1:prod(nsamp0)
    U(:, k) = solve_convdiff1(mu_unif(:, k), K0, K1, K2, F);
end
viz_convdiff1(msh, U(:, 1), fem);
viz_convdiff1(msh, U(:, 2), fem);
viz_convdiff1(msh, U(:, 3), fem);
viz_convdiff1(msh, U(:, 4), fem);
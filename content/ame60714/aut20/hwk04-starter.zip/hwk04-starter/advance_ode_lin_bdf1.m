function u_np1 = advance_ode_lin_bdf1(u_n, dt, M, K)
%ADVANCE_ODE_LIN_BDF1 Advance a linear system of ODEs defined by
%
%                  M * \dot{u} + K * u = 0
%
% from time n to n+1 (step size = dt) using Backward Euler (BDF1).
%
%Input arguments
%---------------
%  u_n : Array (m,) : Solution vector at step n
%
%  dt : number : Time step
%
%  M : Array (m, m) : Mass matrix of ODE system
%
%  K : Array (m, m) : Stiffness matrix of ODE system
%
%Output arguments
%----------------
%  u_np1 : Array (m,) : Solution vector at step n+1

% Define time step system matrix and right-hand side using Backward Euler
A = (1/dt)*M + K;
b = (1/dt)*(M*u_n);

% Solve system of equations for solution at time n+1
u_np1 = A\b;

end
function [u, f] = solve_truss_dsm(xcg, e2vcg, EA, dbc_idx, dbc_val, fbc_val)
%SOLVE_TRUSS_DSM Solve for the nodal displacements and reaction forces of a
%truss structure.
%
% Input arguments
% ---------------
%   XCG : 2D array (ndim, nnode) : The position of the nodes in the truss
%   prior to deformation under the external loads. The (i, j)-entry is the
%   position of node j in the ith dimension. The global node numbers are
%   defined by the columns of this matrix, e.g., the node at
%   xcg(:, j) is the jth node of the truss.
%
%   E2VCG : 2D array (nnode_per_elem, nelem): The connectivity of the
%   truss. The (:, e)-entries are the global node numbers of the nodes that
%   comprise element e. The local node numbers of each element are defined
%   by the columns of this matrix, e.g., e2vcg(i, e) is the global node
%   number of the ith local node of element e.
%
%   EA : Array (nelem,) : Young's modulus times cross-sectional area for
%   each element.
%
%   DBC_IDX : Array (ndbc,) : Indices into array defined over global dofs
%   (size = ndim*nnode) that indicates those with prescribed displacements
%   (Dirichlet BCs).
%
%   DBC_VAL : Array (ndbc,) : Value of the prescribed displacements such
%   that U(DBC_IDX) = DBC_VAL (see definition of U below).
%
%   FBC_VAL : Array (nfbc,) : Value of the prescribed forces at all global
%   dofs without a prescribed displacement (nfbc = ndim*nnode-ndbc). Let
%   FBC_IDX = setdiff(1:NDIM*NNODE, DBC_IDX), then F(FBC_IDX) = FBC_VAL
%   (see definition of F below).
%
% Output arguments
% -----------------
%   U : Array (ndim*nnode,) : The displacement of each node in the truss
%   with components U = [Ux_1; Uy_1; ... ; Ux_nnode; Uy_nnode], where Ux_i,
%   Uy_i are the x- and y- displacements at node i.
%
%   F : Array (ndim*nnode,) : The force acting on each node of the truss
%   with components F = [Fx_1; Fy_1; ... ; Fx_nnode; Fy_nnode], where Fx_i,
%   Fy_i are the x- and y-forces at node i.
%
% Note: The ordering of one-dimensional vectors over all/some of the
% degrees of freedom will ALWAYS be ordered first by the dofs at a fixed
% node and then across all nodes. For example, let U be the vector of size
% ndim*nnode containing the displacements at all nodes, then its components
% are U = [Ux_1; Uy_1; ... ; Ux_nnode; Uy_nnode], where Ux_i, Uy_i are the
% x- and y- displacements at node i.

% Code me

end
function  [Ke] = eval_stiff_unassembled(elem, elem_data)
%EVAL_STIFF_UNASSEMBLED Evaluate/store element stiffness matrix for each
%element.
%
%Input arguments
%---------------
%   ELEM, ELEM_DATA : See description in CREATE_ELEM_STRUCTS_TRUSS
%
%Output arguments
%----------------
%   Ke : 3D array (ndim*nnode_per_elem, ndim*nnode_per_elem, nelem) :
%   unassembled element stiffness matrices (Ke(:, :, e) is the stiffness
%   matrix of element e).

% Code me %

end

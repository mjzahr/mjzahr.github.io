function  [u, f] = apply_bc_solve(K, dbc_idx, dbc_val, fbc_val)
%APPLY_BC_SOLVE Apply boundary conditions via static condensation and
%solve for unknown displacements and reaction forces.
%
%Input arguments
%---------------
%   K : 2D array (ndim*nnode, ndim*nnode) : assembled stiffness matrix
%   (output of ASSEMBLE_STIFF_NOBC; see complete description in that
%   function).
%
%   DBC_IDX, DBC_VAL, FBC_VAL : See defintion in SOLVE_TRUSS_DSM
%
%Output arguments
%----------------
%   U, F : See defintion in SOLVE_TRUSS_DSM

% CODE ME %

end

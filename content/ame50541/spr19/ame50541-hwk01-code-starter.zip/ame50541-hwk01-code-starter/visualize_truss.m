function  [] = visualize_truss(u, xcg, e2vcg, EA, scale, f, dbc_idx)
%VISUALIZE_TRUSS Plot truss - undeformed truss (black), deformed truss
%(blue), and displacement and force boundary conditions (optional).
%
%Input arguments
%---------------
%   U, XCG, E2VCG, EA, F, DBC_IDX : See definition in SOLVE_TRUSS_DSM
%   SCALE : Factor by which to scale displacements

% Extract sizes from input
ndim = size(xcg, 1);
nnode = size(xcg, 2);
nelem = length(EA);

% Compute displaced nodes
u = reshape(u, [ndim, nnode]);
x = xcg + scale*u;

% Plot reference and displaced nodes
plot(xcg(1, :), xcg(2, :), 'ks'); hold on;
plot(x(1, :), x(2, :),'bs');

% Plot reference and displaced elements
for e = 1:nelem
    n1 = e2vcg(1, e);
    n2 = e2vcg(2, e);
    h(1) = plot(xcg(1, [n1; n2]), xcg(2, [n1; n2]), 'k-');
    h(2) = plot(x(1, [n1; n2]), x(2, [n1; n2]), 'b--');
    set(h, 'linewidth', 2*EA(e)/max(EA));
end
axis equal;

% Limits
xmin = min([x(1, :), xcg(1, :)], [], 2); ymin = min([x(2, :), xcg(2, :)], [], 2);
xmax = max([x(1, :), xcg(1, :)], [], 2); ymax = max([x(2, :), xcg(2, :)], [], 2);
dx = xmax-xmin; dy = ymax-ymin;
max_del = max([dx, dy]);
set(gca, 'xlim', [xmin-0.1*max_del, xmax+0.1*max_del], ...
         'ylim', [ymin-0.1*max_del, ymax+0.1*max_del]);

if nargin == 7
    % Plots external forces
    fp = f; fp(dbc_idx) = 0;
    Fp = reshape(fp, ndim, nnode);
    Fp = 2*Fp/max(sqrt(sum(Fp.^2, 1)));
    for i = 1:nnode
        quiver(xcg(1, i), xcg(2, i), Fp(1, i), Fp(2, i), 0.5);
    end

    % Plot Dirichlet boundary conditions
    l = 0.01*max_del;
    ubc = false(ndim*nnode, 1); ubc(dbc_idx) = true;
    ubc = reshape(ubc, ndim, nnode);
    for i = 1:nnode
        if ubc(1, i) && ubc(2, i) % Pin
            plot_triangle_below(gca, xcg(:, i), 2*l);
        elseif ubc(1, i) % Left roller
            plot_circle_at(gca, xcg(:, i)-[l; 0], l);
        elseif ubc(2, i)
            plot_circle_at(gca, xcg(:, i)-[0; l], l);
        end
    end
end

end

function [] = plot_triangle_below(ax, x, l)

fill(ax, [x(1), x(1)-0.5*sqrt(3)*l, x(1)+0.5*sqrt(3)*l, x(1)], ...
         [x(2), x(2)-l, x(2)-l, x(2)],'k');

end

function [] = plot_circle_at(ax, x, l)

th=linspace(0, 2*pi, 100);
fill(ax, l*sin(th)+x(1), l*cos(th)+x(2), 'k');

end

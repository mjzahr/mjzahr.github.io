function [xcg, e2vcg, EA, dbc_idx, dbc_val, fbc_val] = define_truss0(plotit)

if nargin<1, plotit = false; end

%Definitions
%-----------
%ndim : Number of spatial dimensions (planar truss: ndim = 2)
%nnode : Number of nodes in the truss
%nelem : Number of elements in the truss
%nnode_per_elem : Number of nodes per element (truss: nnode_per_elem = 2)
%ndbc : Number of degrees of freedom with Dirichlet boundary conditions
%ndof_per_node: Number of degrees of freedom per node
%               (truss: ndof_per_node = ndim)
%ndof : Number of global degrees of freedom (ndof = ndof_per_node*nnode)

%XCG : 2D array (ndim, nnode) : The position of the nodes in the truss
%prior to deformation under the external loads. The (i, j)-entry is the
%position of node j in the ith dimension. The global node numbers are
%defined by the columns of this matrix, e.g., the node at
%xcg(:, j) is the jth node of the truss.
xcg = [0.0, 1.0, 0.0, 1.0; ...
       0.0, 0.0, 1.0, 1.0];

%E2VCG : 2D array (nnode_per_elem, nelem): The connectivity of the
%truss. The (:, e)-entries are the global node numbers of the nodes that
%comprise element e. The local node numbers of each element are defined
%by the columns of this matrix, e.g., e2vcg(i, e) is the global node
%number of the ith local node of element e.
e2vcg = [1, 1, 2, 3, 1; ...
         2, 3, 4, 4, 4];
     
%EA : Array (nelem,) : Young's modulus times cross-sectional area for
%each element.
EA = [1.0; 2.0; 3.0; 4.0; 5.0];

%DBC_IDX : Array (ndbc,) : Indices into array defined over global dofs
%(size = ndim*nnode) that indicates those with prescribed displacements
%(Dirichlet BCs).
dbc_idx = [1; 2; 4];

%DBC_VAL : Array (ndbc,) : Value of the prescribed displacements such
%that U(DBC_IDX) = DBC_VAL, where U is an array of size ndim*nnode that
%contains the displacement of each node in the truss with components
%U = [Ux_1; Uy_1; ... ; Ux_nnode; Uy_nnode], where Ux_i, Uy_i are the x-
% and y- displacements at node i.
dbc_val = [0.0; 0.0; 0.0];

%FBC_VAL : Array (nfbc,) : Value of the prescribed forces at all global
%dofs without a prescribed displacement (nfbc = ndim*nnode-ndbc). Let
%FBC_IDX = setdiff(1:NDIM*NNODE, DBC_IDX), then F(FBC_IDX) = FBC_VAL,
%where F is an array of size ndim*nnode that contains the force at each
%node in the truss with components F = [Fx_1; Fy_1; ... ; Fx_nnode; Fy_nnode],
%where Fx_i, Fy_i are the x- and y- forces at node i.
fbc_val = [0.0; 0.0; 0.0; 0.1; 0.0];

% Plot truss
if plotit
    [ndim, nnode] = size(xcg);
    f = zeros(ndim*nnode, 1);
    fbc_idx = setdiff(1:ndim*nnode, dbc_idx);
    f(fbc_idx) = fbc_val;
    visualize_truss(zeros(ndim*nnode,1), xcg, e2vcg, EA, 1, f, dbc_idx);
end

end
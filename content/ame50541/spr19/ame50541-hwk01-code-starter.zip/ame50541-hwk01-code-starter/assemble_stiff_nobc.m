function [K] = assemble_stiff_nobc(ndof, Ke, ldof2gdof)
%ASSEMBLE_STIFF_NOBC Assemble element stiffness matrices into the global
%stiffness matrix without applying Dirichlet boundary conditions.
%
%Input arguments
%---------------
%   NDOF : Number of global degrees of freedom (= ndof_per_node*nnode)
%   KE : See defintion in EVAL_STIFF_UNASSEMBLED
%   LDOF2GDOF : See definition in CREATE_MAP_LDOF_TO_GDOF
%
%Output arguments
%----------------
%   K : 2D array (ndim*nnode, ndim*nnode) : assembled stiffness matrix
%   PRIOR to static condensation.

% Code me %

end

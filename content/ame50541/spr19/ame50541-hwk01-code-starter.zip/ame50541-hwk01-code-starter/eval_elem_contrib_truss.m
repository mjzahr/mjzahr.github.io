function [Ke] = eval_elem_contrib_truss(elem_data)
%EVAL_ELEM_CONTRIB_TRUSS Evaluate the stiffness matrix for a truss element.
%
%Input arguments
%---------------
%   ELEM_DATA : Single entry ELEM_DATA described in
%   CREATE_ELEM_STRUCTS_TRUSS
%
%Output arguments
%----------------
%   KE : 2D matrix (ndof_per_node*nnode_per_elem,
%                   ndof_per_node*nnode_per_elem)
%      : Truss element stiffness matrix

% Extract EA/L and cosine, sine of angle bar makes with horizontal
cth = elem_data.cth;
sth = elem_data.sth;
EA_over_L = elem_data.EA_over_L;

% Code me %

end
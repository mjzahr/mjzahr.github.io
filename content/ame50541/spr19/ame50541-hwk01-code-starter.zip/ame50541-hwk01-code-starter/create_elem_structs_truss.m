function [elem, elem_data] = create_elem_structs_truss(xcg, e2vcg, EA)
%CRETE_ELEM_STRUCTS Create structures defining the truss element and its
%data.
%
%Input arguments
%---------------
%   XCG, E2VCG, EA : See description in SOLVE_TRUSS_DSM
%
%Output arguments
%----------------
%   ELEM : structure with fields NDOF_PER_NODE, NNODE_PER_ELEM, STIFF
%     ELEM.NDOF_PER_NODE : number : Number of degrees of freedom per node
%     ELEM.NNODE_PER_ELEM : number : Number of nodes per element
%     ELEM.STIFF : function : Function that takes a single entry of the
%     ELEM_DATA structure array as input and returns the element stiffness
%     matrix.
%
%   ELEM_DATA : structure array (nelem,) with element-specific fields
%   (for truss: EA_OVER_L, STH, CTH)
%      ELEM_DATA(e).EA_OVER_L : number : EA/L for element e
%      ELEM_DATA(e).STH : number : sine of the angle element e makes with
%      the horizontal 
%      ELEM_DATA(e).CTH : number : cosine of the angle element e makes with
%      the horizontal

% Extract number of elements 
nel = length(EA);

% Compute the length of elements and sin/cos of angles w.r.t. horizontal
L = zeros(nel, 1);
cth = zeros(nel, 1);
sth = zeros(nel, 1);
for e = 1:nel
    L(e) = % Code me
    cth(e) = % Code me
    sth(e) = % Code me
end

% Create element structures
elem = struct('ndof_per_node', 2, 'nnode_per_elem', 2, ...
              'stiff', @eval_elem_contrib_truss);
elem_data = struct('EA_over_L', num2cell(EA./L), ...
                   'cth', num2cell(cth), 'sth', num2cell(sth));

end
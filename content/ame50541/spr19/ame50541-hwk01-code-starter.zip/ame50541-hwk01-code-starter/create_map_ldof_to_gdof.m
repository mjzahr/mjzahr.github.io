function [ldof2gdof] = create_map_ldof_to_gdof(ndof_per_node, e2vcg)
%CREATE_MAP_LDOF_TO_GDOF Create a matrix that maps local degrees of freedom
%for each element to global degrees of freedom (ignoring boundary
%conditions).
%
%Input arguments
%---------------
%   NDOF_PER_NODE : Number of degrees of freedom per node
%
%   E2VCG : See description in SOLVE_TRUSS_DSM
%
%Output arguments
%----------------
%    LDOF2GDOF : 2D array (ndof_per_node*nnode_per_elem, nelem) : Maps
%    local degrees of freedom for each element to global degrees of
%    freedom, ignoring boundary conditions. LDOF2GDOF(i, e) is the global
%    degree of freedom corresponding to the ith local degree of freedom of
%    element e.

% Preallocate map from local to global degrees of freedom
[nnode_per_elem, nelem] = size(e2vcg);
ldof2gdof = zeros(ndof_per_node*nnode_per_elem, nelem);

% Code me %
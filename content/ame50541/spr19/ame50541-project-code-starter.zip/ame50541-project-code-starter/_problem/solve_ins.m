function [U, ux, dux, info] = solve_ins(etype, porder, xcg, e2vcg, e2bnd, ldof2gdof, eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, U0, xeval)
%SOLVE_ins Solve incompressible Navier-Stokes equations given mesh and
%definition of boundary conditions and coefficients.
%
% Input arguments
% ---------------
%   ETYPE, PORDER, XCG, E2VCG, LDOF2GDOF : See notation.m
%
%   EQN_PARS_FCN, NBC_VAL_FCN, DBC_IDX, DBC_VAL : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
%   XEVAL : Array (NDIM, NX) : Points at which to evaluate the PDE solution
%     and its gradient.
%
%   U0 : Array (NDOF,) : Initial guess for solution (if no initial guess
%     available, use [])
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   UX : Array (NC, NX) : PDE solution evaluated at each point in XEVAL
%
%   DUX : Array (NC, NDIM, NX) : Gradient of PDE solution evaluated at each
%     point in XEVAL.
%
%   E : number : L2 error using mass matrix (if exact solution provided)
%
%   INFO : See NEWTRAPH

% Default if no exact solution provided
if nargin < 12, U0 = []; end
if nargin < 13, xeval = []; end

% Create finite element geometry
[ndim, nnode] = size(xcg);
qex = 3*porder; nquad = ceil(0.5*(qex+1));
if strcmpi(etype, 'simp')
    geom1 = create_geom_simp(ndim, porder, nquad);
    geom2 = create_geom_simp(ndim, porder-1, nquad);
elseif strcmpi(etype, 'hcube')
    geom1 = create_geom_hcube(ndim, porder, nquad);
    geom2 = create_geom_hcube(ndim, porder-1, nquad);
else
    error('Element not supported.')
end

% Create isoparametric data
mesh_data = create_mesh_data(geom1, xcg, e2vcg, e2bnd);

% Update elem, elem_data for particular application
[elem, mesh_data] = create_elem_update_mesh_data_ins(geom1, geom2, mesh_data);
mesh_data = update_mesh_data_pars(mesh_data, [], eqn_pars_fcn, nbc_val_fcn);

% Create sparsity structure
[cooidx, lmat2gmat] = create_sparsity_struct(ldof2gdof);

% Solve finite element
ndof = max(ldof2gdof(:));
tol = 1.0e-8; maxit = 15;
if isempty(U0), U0 = zeros(ndof, 1); end
fbc_idx = setdiff(1:ndof, dbc_idx)';
Uf0 = U0(fbc_idx);
[U, info] = solve_fem_static(elem, mesh_data, dbc_idx, dbc_val, ldof2gdof, cooidx, lmat2gmat, Uf0, tol, maxit);

% Evaluate FEM solution at points
[bbox, bbox2e] = construct_bounding_boxes(xcg, e2vcg, 20);
[ux, dux] = eval_fem_soln(U, xeval, geom1, elem, mesh_data, ldof2gdof, bbox, bbox2e);

% Visualize FEM solution
if pltit
    uv = reshape(U(1:ndim*nnode), [ndim, nnode]);
    uabs = sqrt(uv(1, :).^2 + uv(2, :).^2);
    vort = compute_vort_ins(U, geom1, xcg, e2vcg, ldof2gdof);
    
    % Evaluate FEM at points for quiver plot
    xlims = [min(xcg(1, :)), max(xcg(1, :))];
    ylims = [min(xcg(2, :)), max(xcg(2, :))];
    [X, Y] = meshgrid(linspace(xlims(1), xlims(2), 30), ...
                      linspace(ylims(1), ylims(2), 30));
    xy = [X(:), Y(:)]';
    [uv_xy, ~] = eval_fem_soln(U, xy, geom1, elem, mesh_data, ldof2gdof, bbox, bbox2e);

    % Plot velocity magnitude
    visualize_fem(uabs, xcg, e2vcg, e2bnd, geom1, false, false);
    title('FEM, velocity magnitude'); colorbar;
    set(gca, 'clim', [0, max(abs(uabs(:)))]);
    quiver(xy(1, :), xy(2, :), uv_xy(1, :), uv_xy(2, :), 'Color', 'k');
    
    % Plot vorticity
    visualize_fem(vort, xcg, e2vcg, e2bnd, geom1, false, false);
    title('FEM, vorticity'); colorbar;
    set(gca, 'clim', [-max(abs(vort(:))), max(abs(vort(:)))]);
    quiver(xy(1, :), xy(2, :), uv_xy(1, :), uv_xy(2, :), 'Color', 'k');
end

end
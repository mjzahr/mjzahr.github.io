function [U, info] = solve_ins_nd0(rho, nu, porder, pltit, U0)
%SOLVE_INS_ND0 Solve for flow through the ND logo problem where the fluid
%is modeled by the incompressible Navier-Stokes equations using FEM on a
%simplicial mesh of polynomial completeness PORDER. 
%
% Input arguments
% ---------------
%   RHO, NU : number : Density and viscosity of the fluid
%
%   PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
%   U0 : Array (NDOF,) : Initial guess for solution (if no initial guess
%     available, use [])
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

ndim = 2;

% Create finite element mesh
[xcg, e2vcg, e2bnd] = load_mesh('nd', 'simp', porder);
[~, e2vcg2, ~] = load_mesh('nd', 'simp', porder-1);
ldof2gdof = create_map_ldof_to_gdof_mixed(ndim, e2vcg, 1, e2vcg2);

% Code me!

% Solve incompressible Navier-Stokes equations
[U, ux, ~, info] = solve_ins('simp', porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                             eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, U0, ...
                             xeval);
end
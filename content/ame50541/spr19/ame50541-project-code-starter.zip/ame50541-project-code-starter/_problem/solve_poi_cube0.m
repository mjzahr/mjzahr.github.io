function [U, info] = solve_poi_cube0(nelem, porder, pltit)
%SOLVE_POI_CUBE0 Solve Poisson equation on unit cube.
%
% Input arguments
% ---------------
%   NELEM : Array (3,) : Number of elements in each direction
%
%   PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

nvar = 1; ndim = 3;

% Create finite element mesh
[xcg, e2vcg, e2bnd] = create_mesh_hcube([0, 1; 0, 1; 0, 1], nelem, porder, 1:6);
ldof2gdof = create_map_ldof_to_gdof(nvar, e2vcg);

% Code me!

% Solve Poisson equation
[U, ux, ~, ~, info] = solve_poi('hcube', porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                                eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, xeval);

end
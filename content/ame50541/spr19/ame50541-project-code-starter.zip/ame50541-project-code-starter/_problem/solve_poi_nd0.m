function [U, info] = solve_poi_nd0(porder, pltit)
%SOLVE_POI_ND0 Solve Poisson equation on ND logo mesh using FEM with
%simplex elements of polynomial completeness PORDER
%
% Input arguments
% ---------------
%   PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

ndim = 2;
nvar = 1;

% Load finite element mesh
[xcg, e2vcg, e2bnd] = load_mesh('nd', 'simp', porder);
ldof2gdof = create_map_ldof_to_gdof(nvar, e2vcg);

% Code me!

% Solve Poisson equation
[U, ux, ~, ~, info] = solve_poi('simp', porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                                eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, ...
                                pltit, xeval);

end
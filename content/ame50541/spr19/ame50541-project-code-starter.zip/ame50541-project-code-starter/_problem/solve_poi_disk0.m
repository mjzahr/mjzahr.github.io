function [U, e, info] = solve_poi_disk0(etype, nelem, porder, pltit)
%SOLVE_POI_DISK0 Solve Poisson equation on unit disk.
%
% Input arguments
% ---------------
%   NELEM : Array (2,) : Number of elements in each direction
%
%   ETYPE, PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   E : number : L2 error using mass matrix
%
%   INFO : See NEWTRAPH

nvar = 1;

% Create finite element mesh
[xcg, e2vcg, e2bnd] = create_mesh_hsphere([0; 0], 1, nelem, porder);
if strcmpi(etype, 'simp')
    [e2vcg, e2bnd] = split_quad_mesh_into_tri_mesh(e2vcg, e2bnd);
end
ldof2gdof = create_map_ldof_to_gdof(nvar, e2vcg);

% Evaluate exact solution on mesh
Ue = (1-xcg(1, :).^2-xcg(2, :).^2)/4; Ue = Ue(:);

% Code me!

% Solve Poisson equation
[U, ux, ~, e, info] = solve_poi(etype, porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                                eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, ...
                                xeval, Ue);
                     
end
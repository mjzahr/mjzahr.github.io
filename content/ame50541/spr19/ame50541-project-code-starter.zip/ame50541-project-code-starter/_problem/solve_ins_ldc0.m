function [U, info] = solve_ins_ldc0(rho, nu, L, etype, nelem, porder, pltit, U0)
%SOLVE_INS_LDC0 Solve the lid-driven cavity problem where the fluid is
%modeled by the incompressible Navier-Stokes equations using FEM on a mesh
%of ETYPE elements of polynomial completeness PORDER.
%
% Input arguments
% ---------------
%   RHO, NU : number : Density and viscosity of the fluid
%
%   L : number : Length of square domain
%
%   NELEM : Array (2,) : Number of elements in each direction
%
%   ETYPE, PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
%   U0 : Array (NDOF,) : Initial guess for solution (if no initial guess
%     available, use [])
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

ndim = 2;

% Create finite element mesh
[xcg, e2vcg, e2bnd] = create_mesh_hcube([0, L; 0, L], nelem, porder, 1:4);
[~, e2vcg2, ~] = create_mesh_hcube([0, L; 0, L], nelem, porder-1, 1:4);
if strcmpi(etype, 'simp')
    [e2vcg2, ~] = split_quad_mesh_into_tri_mesh(e2vcg2, e2bnd);
    [e2vcg, e2bnd] = split_quad_mesh_into_tri_mesh(e2vcg, e2bnd);
end
ldof2gdof = create_map_ldof_to_gdof_mixed(ndim, e2vcg, 1, e2vcg2);

% Code me!

% Solve incompressible Navier-Stokes equations
[U, ux, ~, info] = solve_ins(etype, porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                             eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, U0, ...
                             xeval);

end
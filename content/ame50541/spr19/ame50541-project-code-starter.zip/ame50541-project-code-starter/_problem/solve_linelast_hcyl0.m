function [U, info] = solve_linelast_hcyl0(c, r1, r2, h, nelem, porder, pltit)
%SOLVE_LINELAST_HCYL0 Solve linear elasticity equation on hollow cylinder
%using FEM with simplex elements of polynomial completeness PORDER.
%
% Input arguments
% ---------------
%   XLIMS, YLIMS, ZLIMS : Array (2,) : Domain limits
%
%   NEL : Array (NDIM,) : Number of elements in mesh in each direction
%     (must be a multiple of 5 in z-direction for layered plate).
%
%   PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

ndim = 3; nvar = ndim;

% Create finite element mesh
[xcg, e2vcg, e2bnd] = create_mesh_hollow_cylinder(c, r1, r2, h, nelem, porder, 1:4);
ldof2gdof = create_map_ldof_to_gdof(nvar, e2vcg);

% Code me!

% Solve linear elasticity
[U, ux, ~, ~, info] = solve_linelast('hcube', porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                                     eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, xeval);

end
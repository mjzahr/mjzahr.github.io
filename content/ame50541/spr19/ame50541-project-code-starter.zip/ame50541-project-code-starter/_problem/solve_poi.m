function [U, ux, dux, e, info] = solve_poi(etype, porder, xcg, e2vcg, e2bnd, ldof2gdof, eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, xeval, Ue)
%SOLVE_POI Solve Poisson equation given mesh and definition of boundary
%conditions and coefficients.
%
% Input arguments
% ---------------
%   ETYPE, PORDER, XCG, E2VCG, LDOF2GDOF : See notation.m
%
%   EQN_PARS_FCN, NBC_VAL_FCN, DBC_IDX, DBC_VAL : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
%   XEVAL : Array (NDIM, NX) : Points at which to evaluate the PDE solution
%     and its gradient.
%
%   UE : Array (NDOF,) : Exact solution evaluated at nodes of mesh (if no
%     exact solution available, use [])
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   UX : Array (NC, NX) : PDE solution evaluated at each point in XEVAL
%
%   DUX : Array (NC, NDIM, NX) : Gradient of PDE solution evaluated at each
%     point in XEVAL.
%
%   E : number : L2 error using mass matrix (if exact solution provided)
%
%   INFO : See NEWTRAPH

% Default if no exact solution provided
if nargin < 12, xeval = []; end
if nargin < 13, Ue = []; end

% Create finite element geometry
[ndim, nnode] = size(xcg);
qex = 3*porder; nquad = ceil(0.5*(qex+1));
if strcmpi(etype, 'simp')
    geom = create_geom_simp(ndim, porder, nquad);
elseif strcmpi(etype, 'hcube')
    geom = create_geom_hcube(ndim, porder, nquad);
else
    error('Element not supported.')
end

% Create isoparametric data
mesh_data = create_mesh_data(geom, xcg, e2vcg, e2bnd);

% Update elem, elem_data for particular application
[elem, mesh_data] = create_elem_update_mesh_data_poi(geom, mesh_data);
mesh_data = update_mesh_data_pars(mesh_data, [], eqn_pars_fcn, nbc_val_fcn);

% Create sparsity structure
[cooidx, lmat2gmat] = create_sparsity_struct(ldof2gdof);

% Solve finite element
tol = 1.0e-8; maxit = 10;
Uf0 = zeros(elem.nvar*nnode-numel(dbc_idx), 1);
[U, info] = solve_fem_static(elem, mesh_data, dbc_idx, dbc_val, ldof2gdof, cooidx, lmat2gmat, Uf0, tol, maxit);

% Visualize FEM solution
if pltit, visualize_fem(U, xcg, e2vcg, e2bnd, geom, false, true); title('FEM'); colorbar; end

% Evaluate FEM solution at points
[bbox, bbox2e] = construct_bounding_boxes(xcg, e2vcg, 20);
[ux, dux] = eval_fem_soln(U, xeval, geom, elem, mesh_data, ldof2gdof, bbox, bbox2e);

% Compute L2 error (if exact solution available)
e = nan;
if ~isempty(Ue)
    Me = eval_unassembled_mass(elem, mesh_data);
    M = assemble_nobc_mat(Me, cooidx, lmat2gmat, ldof2gdof);
    
    E = U-Ue; e = sqrt(E'*M*E);
    if pltit, visualize_fem(Ue, xcg, e2vcg, e2bnd, geom, false, true); title('Exact'); colorbar; end
end

end
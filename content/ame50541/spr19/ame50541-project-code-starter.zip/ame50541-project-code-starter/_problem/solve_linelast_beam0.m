function [U, info] = solve_linelast_beam0(xlims, ylims, nelem, etype, porder, pltit)
%SOLVE_LINELAST_BEAM0 Solve linear elasticity equation around
%multimaterial beam using FEM with simplex elements of polynomial
%completeness PORDER.
%
% Input arguments
% ---------------
%   XLIMS, YLIMS : Array (2,) : Domain limits
%
%   NEL : Array (NDIM,) : Number of elements in mesh in each direction
%     (must be even in x-direction for multimaterial beam).
%
%   ETYPE, PORDER : See notation.m
%
%   PLTIT : bool : Whether to plot solution
%
% Output arguments
% ----------------
%   U : Array (NDOF,) : Global (assembled) finite element solution
%
%   INFO : See NEWTRAPH

ndim = 2; nvar = ndim;

% Check input
if rem(nelem(1), 2)~=0, error('nelem(1) must be multiple of 2'); end

% Create finite element mesh
[xcg, e2vcg, e2bnd] = create_mesh_hcube([xlims(:)'; ylims(:)'], nelem, porder, 1:4);
if strcmpi(etype, 'simp')
    [e2vcg, e2bnd] = split_quad_mesh_into_tri_mesh(e2vcg, e2bnd);
    [~, f2v, ~] = create_nodes_bndy_refdom_simp(ndim, porder);
elseif strcmpi(etype, 'hcube')
    [~, f2v, ~] = create_nodes_bndy_refdom_hcube(ndim, porder);
end
ldof2gdof = create_map_ldof_to_gdof(nvar, e2vcg);

% Code me!

% Solve linear elasticity
[U, ux, ~, ~, info] = solve_linelast(etype, porder, xcg, e2vcg, e2bnd, ldof2gdof, ...
                                     eqn_pars_fcn, nbc_val_fcn, dbc_idx, dbc_val, pltit, xeval);

end
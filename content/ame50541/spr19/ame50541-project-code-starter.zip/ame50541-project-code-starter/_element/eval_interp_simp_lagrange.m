function [Q, dQ] = eval_interp_simp_lagrange(xk, x)
%EVAL_INTERP_SIMP_LAGRANGE Evaluate interpolation functions for simplex
%using Lagrange polynomials (number of spatial dimensions and polynomial
%degree of completeness determined from the nodes of the element XK).
%
%Input arguments
%---------------
%   XK : Array (NDIM, NV): Nodes of simplex element.
%
%   X : Array (NDIM, NX) : Points at which to evaluate interpolation
%     function.
%
%Output arguments
%----------------
%   Q : Array (NV, NX) : Interpolation functions for the
%     simplex element evaluated at each point in X, i.e.,
%     Q(i, k) = phi_i(X(:, k) where phi_i(x) is the ith basis fucntion.
%
%   DQ : Array (NV, NDIM, NX) : Derivative of interpolation
%     functions evaluated at each point in X, i.e.,
%     dQ(i, j, k) = (d(phi_i)/d(x_j))(X(:, k)

% Extract information from input
[ndim, nv] = size(xk);
nx = size(x, 2);

% Handle case where ndim == 0 as special case, assuming nv = nx = 1
if ndim == 0
    Q = 1; dQ = zeros(1, 0, 1);
    return;
end

% Code me!

end
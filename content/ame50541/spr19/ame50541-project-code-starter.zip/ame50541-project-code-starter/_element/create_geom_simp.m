function [geom] = create_geom_simp(ndim, porder, nquad_per_dim)
%CREATE_GEOM_SIMP Create structure defining the simplex element.
%
%Input arguments
%---------------
%   NDIM, PORDER : See notation.m
%
%   NQUAD_PER_DIM : number : Number of quadrature nodes per dimension
%
%Output arguments
%----------------
%   GEOM : See notation.m

% Code me!

% Create element structures
geom = struct('etype', 'simp', 'porder', porder, ...
              'zk', zk, 'rk', rk, 'f2v', f2v, 'N', N, ...
              'wq', wq, 'zq', zq, 'Q', Q, 'dQdz', dQdz, ...
              'wqf', wqf, 'rq', rq, 'Qf', Qf, 'dQfdr', dQfdr, ...
              'eval_basis', @(z_) eval_interp_simp_lagrange(zk, z_));

end
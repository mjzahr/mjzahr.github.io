function [geom] = create_geom_hcube(ndim, porder, nquad_per_dim)
%CREATE_GEOM_HCUBE Create structure defining the hypercube element.
%
%Input arguments
%---------------
%   NDIM, PORDER : See notation.m
%
%   NQUAD_PER_DIM : number : Number of quadrature nodes per dimension
%
%Output arguments
%----------------
%   GEOM : See notation.m

% Create geometry
[zk, f2v, N] = create_nodes_bndy_refdom_hcube(ndim, porder);
[rk, ~, ~] = create_nodes_bndy_refdom_hcube(ndim-1, porder);
zk0 = unique(zk(1, :));

% Quadrature nodes, volume and faces
[w0, z0] = create_quad_onedim_gaussleg(nquad_per_dim);

[wq, zq] = create_quad_hcube_from_onedim(ndim, w0, z0);
[wqf, rq] = create_quad_hcube_from_onedim(ndim-1, w0, z0);

% Basis functions, volume and faces
[Q0, dQ0] = eval_interp_onedim_lagrange(zk0, z0);
[Q, dQdz] = eval_interp_hcube_from_onedim(ndim, Q0, dQ0);
[Qf, dQfdr] = eval_interp_hcube_from_onedim(ndim-1, Q0, dQ0);

% Create element structures
geom = struct('etype', 'hcube', 'porder', porder, ...
              'zk', zk, 'rk', rk, 'f2v', f2v, 'N', N, ...
              'wq', wq, 'zq', zq, 'Q', Q, 'dQdz', dQdz, ...
              'wqf', wqf, 'rq', rq, 'Qf', Qf, 'dQfdr', dQfdr, ...
              'eval_basis', @(z_) eval_interp_hcube_lagrange(zk0, z_));

end
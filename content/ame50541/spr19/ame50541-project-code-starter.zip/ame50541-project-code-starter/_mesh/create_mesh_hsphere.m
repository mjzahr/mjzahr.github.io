function [xcg, e2vcg, e2bnd] = create_mesh_hsphere(c, r, nel, porder)
%CREATE_MESH_HSPHERE Create a mesh of the hypersphere using hypercube
%elements (mapping from hypercube). Only implemented for NDIM = 2, 3.
%
%Input arguments
%---------------
%   C : Array (NDIM,) : Center of disk
%
%   R : number : Radius of disk
%
%   NEL : Array (NDIM,) : Number of elements in mesh in each direction
%
%   PORDER : See notation.m
%
%Output arguments
%----------------
%   XCG, E2VCG, E2BND : See notation.m

% Create mesh of biunit hypercube
ndim = numel(c);
dlims = [-ones(ndim, 1), ones(ndim, 1)];
[xcg0, e2vcg, e2bnd] = create_mesh_hcube(dlims, nel, porder, ones(1, 2*ndim));

% Map to circle
if ndim == 2
    xcg = [xcg0(1, :).*sqrt(1-xcg0(2, :).^2/2); xcg0(2, :).*sqrt(1-xcg0(1, :).^2/2)];
elseif ndim == 3
    xcg = [xcg0(1, :).*sqrt(1-xcg0(2, :).^2/2-xcg0(3, :).^2/2+xcg0(2, :).^2.*xcg0(3, :).^2/3); ...
           xcg0(2, :).*sqrt(1-xcg0(1, :).^2/2-xcg0(3, :).^2/2+xcg0(1, :).^2.*xcg0(3, :).^2/3); ...
           xcg0(3, :).*sqrt(1-xcg0(1, :).^2/2-xcg0(2, :).^2/2+xcg0(1, :).^2.*xcg0(2, :).^2/3)];
else
    error('Dimension not supported.');
end

% Scale/translate circle
xcg = xcg*r;
xcg = bsxfun(@plus, xcg, c(:));

end
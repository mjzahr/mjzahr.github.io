function [cooidx, lmat2gmat] = create_sparsity_struct(ldof2gdof)
%CREATE_SPARSITY_STRUCT Create sparsity structure of stiffness (Jacobian)
%matrix corresponding to the connectivity defined in LDOF2GDOF.
%
%Input arguments
%---------------
%   LDOF2GDOF : See notation.m
%
%Output arguments
%----------------
%   COOIDX, LMAT2GMAT : See notation.m

% Extract sizes and preallocate matrix to store coordinate sparsity
% structure (with repeats)
[nldof, nelem] = size(ldof2gdof);
cooidx_rep = zeros(nldof*nldof*nelem, 2);

% Fill the COO sparsity structure with repeats from ldof2gdof data
% structure 
for e = 1:nelem
    idx = ldof2gdof(:, e);
    [jcol0, irow0] = meshgrid(idx, idx);
    cooidx_rep(nldof*nldof*(e-1)+1:nldof*nldof*e, 1) = irow0(:);
    cooidx_rep(nldof*nldof*(e-1)+1:nldof*nldof*e, 2) = jcol0(:);
end

% Eliminate repeats in COO sparsity structure to determine number of
% nonzeros and extract final/optimal sparsity structure
[cooidx, ~, lmat2gmat] = unique(cooidx_rep, 'rows', 'stable');
lmat2gmat = reshape(lmat2gmat, nldof, nldof, nelem);

end
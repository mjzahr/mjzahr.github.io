function [V, C, S] = compute_volume_centroid_surfarea(geom, mesh_data)
%COMPUTE_VOLUME_CENTROID_SURFAREA Compute the volume, centroid, and surface
%area of a domain (approximated) by the mesh described by GEOM, MESH_DATA.
%
%Input arguments
%---------------
%  GEOM, MESH_DATA : See notation.m
%
%Output arguments
%----------------
%  V : number : Volume of domain
%
%  C : Array (NDIM,) : Centroid of domain
%
%  S : number : Surface area of domain

% Extract relevant quantities
ndim = size(geom.zk, 1);
nf = size(geom.f2v, 2);
nelem = numel(mesh_data);

% Code me!

end
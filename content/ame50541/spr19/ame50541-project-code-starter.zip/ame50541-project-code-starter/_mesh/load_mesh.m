function [xcg, e2vcg, e2bnd] = load_mesh(mshnm, etype, porder)
%LOAD_MESH Load mesh from database.
%
% Input arguments
% ---------------
%   MSHNM : string : Prefix of mesh file
%
%   ETYPE, PORDER : See notation.m
%
% Output arguments
% ----------------
%   XCG, E2VCG, E2BND : See notation.m

fname = sprintf('_mesh/_meshes/%s-%s-p%d.mat', mshnm, etype, porder);
msh = load(fname);
xcg = msh.xcg; e2vcg = msh.e2vcg; e2bnd = msh.e2bnd;

end
function [mesh_data] = create_mesh_data(geom, xcg, e2vcg, e2bnd)
%CREATE_MESH_DATA Compute isoparametric quantities (XE, XQ, XQF,
%DETG, SIGF, GI) from geometric definition (GEOM) and mesh (XCG, E2VCG,
%E2BND) and create MESH_DATA (see notation.m) structure array from these
%quantities.
%
%Input arguments
%---------------
%   GEOM, XCG, E2VCG, E2BND : See notation.m
%
%Output arguments
%----------------
%   MESH_DATA : See notation.m

% Extract relevant information
ndim = size(xcg, 1);
[nnode_per_elem, nelem] = size(e2vcg);
nq = size(geom.wq, 1);
nqf = size(geom.wqf, 1);
nf = size(geom.f2v, 2);

% Compute isoparametric quantities for each element
xe = zeros(ndim, nnode_per_elem, nelem);
xq = zeros(ndim, nq, nelem);
xqf = zeros(ndim, nqf, nf, nelem);
detG = zeros(nq, nelem);
sigf = zeros(nqf, nf, nelem);
Gi = zeros(ndim, ndim, nq, nelem);
for e = 1:nelem
    xe_ = xcg(:, e2vcg(:, e));
    [xq_, detG_, Gi_, xqf_, sigf_] = eval_isoparam_quant(xe_, geom.Q, geom.dQdz, ...
                                                           geom.Qf, geom.dQfdr, geom.f2v);
    xe(:, :, e) = xe_;
    xq(:, :, e) = xq_;
    detG(:, e) = detG_;
    Gi(:, :, :, e) = Gi_;
    xqf(:, :, :, e) = xqf_;
    sigf(:, :, e) = sigf_;
end

% Create elem_data structure array from numeric arrays
mesh_data = struct('e2bnd', squeeze(num2cell(e2bnd, 1))', ...
                   'xe', squeeze(num2cell(xe, [1, 2])), ...
                   'xq', squeeze(num2cell(xq, [1, 2])), ...
                   'xqf', squeeze(num2cell(xqf, [1, 2, 3])),...
                   'detG', squeeze(num2cell(detG, 1))', ...
                   'Gi', squeeze(num2cell(Gi, [1, 2, 3])), ...
                   'sigf', squeeze(num2cell(sigf, [1, 2])));

end
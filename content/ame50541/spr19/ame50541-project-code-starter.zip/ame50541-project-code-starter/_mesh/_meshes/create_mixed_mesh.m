function [xcg, e2vcg] = create_mixed_mesh(xcg1, e2vcg1, xcg2, e2vcg2)
%CREAT_MIXED_MESH Create mixed element mesh from two standard meshes.
%
% Input arguments
% ---------------
%   XCG1, E2VCG1 : See notation.m; mesh 1
%
%   XCG2, E2VCG2 : See notation.m; mesh 2
%
% Output arguments
% ----------------
%   XCG, E2VCG : See notation.m; mixed mesh: global nodes numbered first by
%     nodes in XCG1, then by nodes in XCG2, local nodes numbered first by
%     nodes in E2VCG1, then by nodes in E2VCG2.

% Extract information from input
nnode1 = size(xcg1, 2);
nelem1 = size(e2vcg1, 2);
nelem2 = size(e2vcg2, 2);

% Error checking
if nelem1~=nelem2
    error('Both meshes must have the same number of elements.');
end

% Nodes for mixed mesh comes from the union of nodes of both meshes
xcg = [xcg1, xcg2];

% Elements for mixed mesh come from the concatenation of all nodes for an
% element of each mesh
e2vcg = [e2vcg1; e2vcg2+nnode1];

end
function d=dunion(d1,d2), d=min(d1,d2);

%   Copyright (C) 2004-2012 Per-Olof Persson. See COPYRIGHT.TXT for details.

function [xcg, e2vcg, e2bnd] = create_mesh_disk(c, r, nel, porder)
%CREATE_MESH_UNIT_DISK Create a mesh of the unit disk (2D) using hypercube
%elements. 
%
%Input arguments
%---------------
%   C : Array (2,) : Center of disk
%
%   R : number : Radius of disk
%
%   NEL : Array (NDIM,) : Number of elements in mesh in each direction
%
%   PORDER : See notation.m
%
%Output arguments
%----------------
%   XCG, E2VCG, E2BND : See notation.m

% Create mesh of biunit square
dlims = [-1, 1; -1, 1];
[xcg0, e2vcg, e2bnd] = create_mesh_hcube(dlims, nel, porder, ones(1, 4));

% Map to circle
xcg = [xcg0(1, :).*sqrt(1-xcg0(2, :).^2/2); xcg0(2, :).*sqrt(1-xcg0(1, :).^2/2)];

% Scale/translate circle
xcg = xcg*r;
xcg(1, :) = xcg(1, :) + c(1);
xcg(2, :) = xcg(2, :) + c(2);

end
% DEFINITIONS
% -----------
% NDIM : number : Number of spatial dimensions
% NNODE : number : Number of nodes in mesh
% NELEM : number : Number of elements in mesh
% NDOF_PER_ELEM : number : Number of degrees of freedom per element
% NDOF_PER_FACE : number : Number of degrees of freedom per element face
% NNODE_PER_FACE : number : Number of nodes per face (also NVF)
% NNODE_PER_ELEM : number : Number of nodes per element (also NV) 
% PORDER : number : Degree of polynomial completeness
% NNZ : number : Number of nonzero entries in sparse matrix
% ETYPE : string : Element type ('hcube' or 'simp')
% NV : number : Number of nodes per element (also NNODE_PER_ELEM)
% NVF : number : Number of nodes per element face (also NNODE_PER_FACE)
% NVAR/NC : number : Number of solution components
% NQ : number : Number of quadrature nodes per element
% NQF : number : Number of quadrature nodes per element face

% EQUATION
% --------
% MASS_PAR : Array (NQ,) : Mass matrix parameter, evaluated at each
%   quadrature node.
%
% EQN_PARS :  Array (M, NQ) : Parameters for the flux function and
%   source term, evaluated at the quadrature nodes.
%
% NBC_VAL : Array (NC, NQF, NF) : Value of the natural boundary conditions,
%   evaluated at each quadrature node of each face.
%
% LDOF2FDOF : Array (NDOF_PER_FACE, NF) : Map from face degree of freedom
%   to element degree of freedom, i.e., idx = ldof2fdof(:, f) are the
%   element degrees of freedom corresponding to face f.
%
% EVAL_PNTWS_CONTRIB : function : Function that evaluates the flux function
%   and source term and their derivatives given the solution u and its
%   gradient q = dudx at a single point (usually a quadrature point).
%   Input: u(x) (PDE solution), q(x) = dudx(x) (gradient of PDE solution),
%   x (spatial position), and eqn_pars (flux/source parameters).
%
% F : Array (NC, NDIM) : Flux function defining the governing equations.
%   In general, it may depend on the (pointwise value) of: the primary
%   variable u (Array (NC,)), the gradient of the primary variable w.r.t.
%   physical coordiantes q = dudx (Array (NC, NDIM)), and parameters or
%   coefficients nu (Array (NP,)).
%
% DFDU : Array (NC, NDIM, NC) : Partial derivative of the flux function
%   w.r.t. the primary variables, i.e., DFDU(i, j, k) = dF(i, j)/du(k),
%   assuming the primary variable (u) and its gradient (q = dudx) are
%   independent.
%
% DFDQ : Array (NC, NDIM, NC, NDIM): Partial derivative of the flux
%   function w.r.t. the gradient of the primary variables, i.e.,
%   DFDQ(i, j, k, l) = dF(i, j)/dq(k, l), assuming the primary variable (u)
%   and its gradient (q = dudx) are independent.
%
% S : Array (NC,) : Source term defining the governing equations.
%   In general, it may depend on the (pointwise value) of: the primary
%   variable u (Array (NC,)), the gradient of the primary variable w.r.t.
%   physical coordiantes q = dudx (Array (NC, NDIM)), and parameters or
%   coefficients nu (Array (NP,)).
%
% DSDU : Array (NC, NC) : Partial derivative of the source term
%   w.r.t. the primary variables, i.e., DSDU(i, j) = dS(i)/du(j),
%   assuming the primary variable (u) and its gradient (q = dudx) are
%   independent.
%
% DSDQ : Array (NC, NC, NDIM): Partial derivative of the source term
%   w.r.t. the gradient of the primary variables, i.e.,
%   DSDQ(i, j, k) = dS(i)/dq(j, k), assuming the primary variable (u)
%   and its gradient (q = dudx) are independent.

% GEOMETRIC STRUCTURE
% -------------------
% GEOM : struct : Information regarding the geometry/nodes of each element.
%   Fields: (general)    ETYPE, PORDER
%           (geometry)   N, F2V
%           (quadrature) ZK, RK, WQ, ZQ, WQF, RQ
%           (basis)      Q, DQDZ, QF, DQFDR

% ELEMENT STRUCTURE
% -----------------
% ELEM : struct : Information common to every element in mesh.
%   Fields: (general)    NDIM, ETYPE, PORDER
%           (geometry)   F2V
%           (quadrature) WQ, WQF
%           (basis)      Q, DQDZ, QF, DQFDR
%           (eqn)        NVAR, NDOF_PER_ELEM, T, TF, LDOF2FDOF,
%                        EVAL_PNTWS_CONTRIB

% MESH DATA STRUCTURE
% -------------------
% MESH_DATA : Array of struct (NELEM,) : Information unique to each element
%    in the mesh. Fields: XE, XQ, XQF, DETG, SIGF, GI, DTDX, E2BND,
%                         MASS_PAR, EQN_PARS, NBC_VAL.

% ELEMENT GEOMETRY/NODES
% ----------------------
% NF : number : Number of faces
%
% N : Array (NDIM, NF) : Unit outward normal for the face of the reference
%    element. 
%
% F2V : Array (NVF, NF) : Index array that indicates the nodes that
%   comprise each face, i.e., F2V(:, k) are the local node numbers of the
%   nodes that lie on face k and, similarly, XK(:, F2V(:, k)) are the
%   nodal positions. nf is the number of faces the element contains
%   (nf=ndim+1) for simplex elements and nvf is the number of nodes on
%   each face of the element.

% ELEMENT QUADRATURE
% ------------------
% ZK : Array (NDIM, NV) : Element nodes in reference
%    domain \Omega_\square

% RK : Array (NDIM-1, NVF) : Element face nodes in reference
%    domain \Gamma_\square
%
% WQ : Array (NQ,) : Quadrature weights for integrals over \Omega_\square
%
% ZQ : Array (NDIM, NQ) : Quadrature nodes for integrals
%    over \Omega_\square
%
% WQF : Array (NQF,) : Quadrature weights for integrals over \Gamma_\square
%
% RQ : Array (NDIM-1, NQF) : Quadrature nodes for integrals
%    over \Gamma_\square

% ELEMENT ISOPARAMETRIC QUANTITIES
% --------------------------------
% XE : Array (NDIM, NNODE_PER_ELEM) : Element nodes in the physical
%    domain \Omega_e
%
% XQ : Array (NDIM, NQ) : Quadrature nodes for integrals over element
%    (ZQ), mapped to the physical domain physical domain
%
% XQF : Array (NDIM, NQF, NF) : Quadrature nodes for integrals over
%    element faces (ZQ), mapped to the physical domain physical domain.
%    XQF(:, :, f) is all quadrature nodes for the fth face of the element.
%
% DETG : Array (NQ,) : The determinant of the deformation gradient of the
%    isoparametric mapping, evaluated at each quadrature node, i.e.,
%    DETG(k) = det(G(ZQ(:, k)).
%
% GI : Array (NDIM, NDIM, NQ) : The inverse of the deformation
%    gradient of the isoparametric mapping, evaluated at each quadrature
%    node, i.e., GI(:, :, k) = inv(G(ZQ(:, k)).
%
% SIGF : Array (NQF, NF) : The surface element corresponding to the
%    isoparametric mapping restricted to each face of the element.
%    See formula in project handout.

% ELEMENT BASIS
% -------------
% Q : Array (NV, NQ) : Element basis function (defined over the reference
%   domain \Omega_\square) evaluated at the quadrature nodes ZQ, i.e., Q(i,
%   k) = ith basis function evaluated at ZQ(:, k).
%
% DQDZ : Array (NV, NDIM, NQ) : Derivative of element basis with respect to
%   reference coordinates (Z) evaluated at the quadrature nodes ZQ, i.e.,
%   DQDZ(i, j, k) = derivative of the ith basis function w.r.t. the jth
%   reference coordinate evaluated at ZQ(:, k).
%
% QF : Array (NVF, NQF) : Element face basis function (defined over
%   the reference domain \Gamma_\square) evaluated at the quadrature nodes
%   RQ, i.e., QF(i, k) = ith basis function evaluated at RQ(:, k).
%
% DQFDR : Array (NVF, NDIM-1, NQF) : Derivative of element face basis with
%   respect to reference coordinates (R) evaluated at the quadrature nodes
%   RQ, i.e., DQFDR(i, j, k) = derivative of the ith basis function w.r.t.
%   the jth reference coordinate evaluated at RQ(:, k).
%
% DQDX : Array (NV, NDIM, NQ) : Derivative of element basis with respect to
%   physical coordinates evaluated at the quadrature nodes ZQ, i.e.,
%   DQDX(i, j, k) = derivative of the ith basis function w.r.t. the jth
%   physical coordinate evaluated at ZQ(:, k).

% ELEMENT SOLUTION BASIS
% ----------------------
% T : Array (NDOF_PER_ELEM, NC, NQ) : Solution basis (and test function
%   basis since using the Galerkin method) over an element, evaluated at
%   each quadrature point in the reference domain (\Omega_\square), ZQ.
%   That is, the FEM solution (primary variable) U(i, k) = T(j, i, k)*UE(j)
%   (summation over j implied), where U(i, k) is the ith component of the
%   primary variable evaluated at quadrature node ZQ(:, k) (under action of
%   the inverse isoparametric mapping) and UE(j) is the jth degree of
%   freedom over the element.
%
% DTDX : Array (NDOF_PER_ELEM, NC, NDIM, NQ) : Derivative of the solution
%   basis w.r.t. the physical domain (\Omega_e) evaluated at the
%   quadrature points ZQ (under action of inverse isoparametric mapping),
%   i.e., DTDX(i, j, k, l) = dT(i, j, l)/dx(k). 
%
% TF : Array (NDOF_PER_FACE, NC, NQF, NF) : Solution basis (and test
%   function basis since using the Galerkin method) over an element face,
%   evaluated at each quadrature point in the reference domain
%   (\Gamma_\square), RQ. That is, the FEM solution (primary variable)
%   U(i, k, f) = TF(j, i, k, f)*UEF(j)
%   (summation over j implied), where U(i, k) is the ith component of the
%   primary variable evaluated at quadrature node RQ(:, k) (under action of
%   the inverse isoparametric mapping) on the fth face of the element and
%   UEF(j) is the jth degree of freedom over the element face.

% MESH
% ----
% XCG : Array (NDIM, NNODE) : The position of the nodes in the mesh.
%   The (i, j)-entry is the position of node j in the ith dimension. The
%   global node numbers are defined by the columns of this matrix, e.g.,
%   the node at XCG(:, j) is the jth node of the mesh.
%
% E2VCG : Array (NNODE_PER_ELEM, NELEM): The connectivity of the
%   mesh. The (:, e)-entries are the global node numbers of the nodes
%   that comprise element e. The local node numbers of each element are
%   defined by the columns of this matrix, e.g., E2VCG(i, e) is the
%   global node number of the ith local node of element e.
%
% E2BND : Array (NF, NELEM) : Boundary tags for each face of each
%   element of the mesh. The (f, e)-entry is the boundary tag of face f of
%   element e in the mesh. If the fth face of element e does not lie on the
%   domain boundary, E2BND(f, e) == NaN.
%
% LDOF2GDOF : Array (NDOF_PER_ELEM, NELEM) : Maps
%   local degrees of freedom for each element to global degrees of
%   freedom, ignoring boundary conditions. LDOF2GDOF(i, e) is the global
%   degree of freedom corresponding to the ith local degree of freedom
%   of element e.
%
% COOIDX : Array (NNZ, 2) : The rows/columns of the non-zero values of
%   the striffness/Jacobian matrix; cooidx(i, 1) is the row number of the
%   ith nonzero and cooidx(i, 2) is the column number of the ith nonzero.
%
% LMAT2GMAT : Array (NDOF_PER_ELEM, NDOF_PER_ELEM, NELEM) : Maps local
%   stiffness/Jacobian to sparse global stiffness/Jacobian.
%   LMAT2GMAT(i, j, e) is the non-zero number in the global
%   stiffness/Jacobian corresponding to the (i, j) entry of the
%   stiffness/Jacobian matrix of element e. This is the "matrix version"
%   of LDOF2GDOF. It is perfect for assembling a global stiffness matrix
%   in sparse format from element stiffness matrices.

% ESSENTIAL BOUNDARY CONDITIONS
% -----------------------------
% NDBC : number : Number of global degrees of freedom containing a
%   Dirichlet/essential boundary condition.
%
% DBC_IDX : Array (NDBC,) : Indices into array defined over global dofs
%   (size = NDOF_PER_NODE*NNODE) that indicates those with prescribed
%   primary variables (essential BCs).
%
% DBC_VAL : Array (NBC,) : Value of the prescribed primary variables such
%   that U(DBC_IDX) = DBC_VAL, where U is a (NDOF_PER_NODE*NNODE,) vector
%   that contains the primary variable (all dofs of all nodes).

% NOTE ABOUT ORDERING OF 1D ARRAYS
% --------------------------------
% The ordering of one-dimensional vectors over all/some of the
% degrees of freedom will ALWAYS be ordered first by the dofs at a fixed
% node and then across all nodes. For example, let U be the vector of size
% NDIM*NNODE containing the displacements at all nodes, then its components
% are U = [Ux_1; Uy_1; ... ; Ux_nnode; Uy_nnode], where Ux_i, Uy_i are the
% x- and y- displacements at node i.
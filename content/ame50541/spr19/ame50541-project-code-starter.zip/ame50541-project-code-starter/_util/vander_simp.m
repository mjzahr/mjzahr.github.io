function [V, dV] = vander_simp(porder, x)
%VANDER_SIMP Compute NDIM-dimensional Vandermonde matrix of order PORDER
%for a  simplex and its derivative (NDIM determined from shape of X). The
%Vandermonde matrix, V, is the NX x M matrix  of multinomial terms and its
%derivative, dV, is the NX x M x NDIM matrix of the partial derivatives of
%multinomial terms
%
%    V(i, k) = x(1, k)^I(1, i) * ... * x(NDIM, k)^I(NDIM, i),
%
%    dV(i, 1, k) = d(V(i,k))/dx1 = I(1, i)*x(1, k)^(I(1, i)-1) * x(2, k)^I(2, i) * ...
%
%where M is the number of multinomial terms required for polynomial
%completeness (all combinations such that the sum of the exponents is <=
%porder), X are the evaluation points, I is a matrix defining the 
%multinomial exponents (completeness requires sum(I, 1) <= porder).
%
%Input arguments
%---------------
%   PORDER : Polynomial degree of completeness
%
%   X : Array (NDIM, NX) : Points at which to evaluate multinomials in
%     definition of Vandermonde matrix 
%
%Output arguments
%----------------
%   V : Array (M, NX) : Vandermonde matrix
%
%   dV : Array (M, NDIM, NX) : Derivative of Vandermonde matrix

% Extract information from input
[ndim, nx] = size(x);

% Code me!

end
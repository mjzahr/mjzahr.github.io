function [Me] = eval_elem_mass_isoparam(elem, mesh_data)
%EVAL_ELEM_MASS_ISOPARAM Evaluate element mass matrix for isoparametric
%elements.
%
% Input arguments
% ---------------
%   ELEM, MESH_DATA : See notation.m
%
% Output arguments
% ----------------
%   ME : Array (NDOF_PER_ELEM, NDOF_PER_ELEM) : Element mass matrix

% Extract information from input
T = elem.T;
wq = elem.wq;
detG = mesh_data.detG;
coeff = mesh_data.mass_par;
ndof_per_elem = elem.ndof_per_elem;

% Code me!

end
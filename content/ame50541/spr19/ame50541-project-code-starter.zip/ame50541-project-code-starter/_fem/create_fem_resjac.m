function [Rf, dRf] = create_fem_resjac(Uf, elem, mesh_data, dbc_idx, dbc_val, ldof2gdof, cooidx, lmat2gmat)
%CREATE_FEM_RESJAC Create the finite element residual and Jacobian,
%restricted to the free degrees of freedom. When combined with a nonlinear
%solver, this will approximate the solution of a PDE (described in ELEM,
%MESH_DATA) on the mesh (defined by ELEM, MESH_DATA).
%
% Input arguments
% ---------------
%   UF : Array (NDOF-NDBC,) : Global (assembled) solution vector,
%     restricted to the free degrees of freedom (via static condensation).
%
%   ELEM, MESH_DATA, DBC_IDX, DBC_VAL : See notation.m
%
%   LDOF2GDOF, COOIDX, LMAT2GMAT : See notation.m
%
% Output arguments
% -----------------
%   RF : Array (NDOF-NDBC,) : Finite element residual, restricted to free
%     degrees of freedom
%
%   DRF : Sparse matrix (NDOF-NDBC, NDOF-NDBC) : Finite element Jacobian
%     restricted to free degrees of freedom

% Extract information from input
ndof = max(ldof2gdof(:));

end
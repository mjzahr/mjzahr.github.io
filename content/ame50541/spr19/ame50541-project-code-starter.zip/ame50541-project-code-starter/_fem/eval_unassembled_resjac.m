function  [Re, dRe] = eval_unassembled_resjac(U, elem, mesh_data, ldof2gdof)
%EVAL_UNASSEMBLED_RESJAC Evaluate/store element residual vector and
%Jacobian matrices for each element. 
%
% Input arguments
% ---------------
%   U : Array (NDOF,) : Global (assembled) solution vector
%
%   ELEM, MESH_DATA, LDOF2GDOF : See notation.m. MESH_DATA in this function
%     is a *single* entry of the MESH_DATA structure array, i.e.,
%     MESH_DATA(e) where e is the element number.
%
% Output arguments
% ----------------
%   RE : Array (NDOF_PER_ELEM, NELEM): Element residual vector for
%     all elements in mesh
%
%   DRE : Array (NDOF_PER_ELEM, NDOF_PER_ELEM, NELEM): Element Jacobian
%     matrix for all elements in mesh

% Extract relevant variables from element
nelem = numel(mesh_data);
ndof_per_elem = elem.ndof_per_elem;

% Cose me!

end
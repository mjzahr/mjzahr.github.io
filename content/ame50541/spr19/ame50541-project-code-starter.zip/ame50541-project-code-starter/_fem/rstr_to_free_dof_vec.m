function  [vr] = rstr_to_free_dof_vec(v, dbc_idx)
%RSTR_TO_FREE_DOF_VEC Restrict vector defined over all global degrees of
%freedom to only the free degrees of freedom (without prescribed primary
%variable), i.e., remove all entries corresponding to indices in DBC_IDX.
%
%Input arguments
%---------------
%   V : Array (NDOF,) : Vector defined over all global degrees of freedom
%
%   DBC_IDX : See notation.m
%
%Output arguments
%----------------
%   VR : Array (NDOF-NDBC,) : V restricted to free degrees of freedom

% Code me!

end
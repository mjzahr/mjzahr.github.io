function [ux, dux] = eval_fem_soln(U, x, geom, elem, mesh_data, ldof2gdof, bbox, bbox2e)
%EVAL_FEM_SOLN Evaluate finite element solution at point throughout the
%domain (not necessarily quadrature points or nodes).
%
% Input arguments
% ---------------
%   U, GEOM, ELEM, MESH_DATA, LDOF2GDOF : See notation.m
%
%   X : Array (NDIM, NX) : Points in domain at which to evaluate solution.
%
%   BBOX, BBOX2E : See CREATE_BOUNDING_BOXES
%
% Output arguments
% ----------------
%   UX : Array (NC, NX) : PDE variable evaluated at points in X (UX(:, k) =
%     NaN if X(:, k) does not lie in domain).
%
%   DUX : Array (NC, NDIM, NX) : PDE variable gradient evaluated at points
%     in X (DUX(:, :, k) = NaN if X(:, k) does not lie in domain).

% Extract information from input
nc = elem.nvar;
[ndim, nx] = size(x);

% Use average position of nodes as initial guess for Newton
z0 = mean(geom.zk, 2);
dudz = zeros(nc, ndim);

% Bounding box spacing
dx = zeros(ndim, 1);
for j = 1:ndim
    tmp = diff(unique(bbox(j, :)));
    dx(j) = tmp(1);
end

% Evaluate solution and gradient at requested points
ux = nan(nc, nx);
dux = nan(nc, ndim, nx);
for k = 1:nx
    % Find bounding box current point lies within
    wbbox = x(1,k)>=bbox(1,:)-1.0e-8&x(1, k)<=bbox(1,:)+dx(1)+1.0e-8;
    for j=1:ndim
        wbbox = wbbox & (x(j,k)>=bbox(j,:)-1.0e-8&x(j, k)<=bbox(j,:)+dx(j)+1.0e-8);
    end
    eset = vertcat(bbox2e{wbbox});
    if isempty(eset), continue; end
    for e = eset(:)'
        % Extract element information
        xe = mesh_data(e).xe;
        ue = U(ldof2gdof(:, e));
        
        % Evaluate the inverse isoparametric mapping (nonlinear system)
        [z, info] = solve_newtraph(@(z_) inv_isomap_resjac(z_, xe, x(:, k), geom.eval_basis), z0, 1.0e-8, 10);
        
        % Determine if point z lies within reference element, if not,
        % continue to next element.
        if strcmpi(geom.etype, 'hcube')
            is_inside = all(z<=1+1.0e-4&z>=-1-1.0e-4, 1);
        elseif strcmpi(geom.etype, 'simp')
            is_inside = sum(z,1)<=1+1.0e-4&all(z>-1.0e-4,1);
        else
            error('Element not supported.')
        end
        is_inside = is_inside && info.succ;
        if ~is_inside, continue; end;
        
        % Evaluate geometry and solution basis
        [~, dQdz] = geom.eval_basis(z);
        [T, dTdz] = elem.eval_soln_basis(z);
        
        % Evaluate derivative of solution basis in physical domain
        G = xe*dQdz;
        for j = 1:ndim
            dudz(:, j) = dTdz(:, :, j)'*ue;
        end
        %Tdx = (G'\dTdz')';
        
        % Evaluate the solution and derivative pointwise
        ux(:, k) = T'*ue;
        dux(:, :, k) = (G'\dudz')';
        break;
    end
end
end

function [R, dR] = inv_isomap_resjac(z, xe, xs, eval_geom_basis)
%INV_ISOMAP_RESJAC Evaluate the residual and Jacobian of the inverse
%isoparametric mapping.
%
% Input arguments
% ---------------
%   Z : Array (NDIM,) : Inverse isoparametric mapping evaluated at XS (or
%     candidate solution for this point).
%
%   XE : See notation.m
%
%   XS : Array (NDIM,) : Point at which to evaluate inverse isoparametric
%     mapping.
%
%   EVAL_GEOM_BASIS : function : Function that evaluates the geometry basis
%     and its derivative w.r.t. the reference domain.
%
% Output arguments
% ----------------
%   R : Array (NDIM,) : Residual of inverse isoparametric mapping
%
%   DR : Array (NDIM, NDIM) : Jacobian of inverse isoparametric mapping

% Evaluate geometry basis at z
[Q, dQdz] = eval_geom_basis(z);

% Use this to construct corresponding position in physical domain
x = xe*Q; dxdz = xe*dQdz;

% Form residual and Jacobian
R = x-xs;
dR = dxdz;

end
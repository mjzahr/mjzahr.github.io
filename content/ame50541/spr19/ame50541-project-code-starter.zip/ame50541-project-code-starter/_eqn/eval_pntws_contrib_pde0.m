function [F, dFdu, dFdq, S, dSdu, dSdq] = eval_pntws_contrib_pde0(u, q, eqn_pars)
%EVAL_PNTWS_CONTRIB_PDE0 Evaluate the flux function and source term (and
%their derivatives) that define PDE0. 
%
% Input arguments
% ---------------
%   U : Array (NC,) : Primary variables
%
%   Q : Array (NC, NDIM) : Gradient of primary variables
%
%   EQN_PARS : Array (M,) : Parameters to flux function and source term
%
% Output arguments
% ----------------
%   F, DFDU, DFDQ, S, DSDU, DSDQ : See notation.m

% Define information regarding size of the system
neqn = 1; ncomp = 1;

% Extract information from input
ndim = size(q, 1);
xsq = eqn_pars(1);

% Code me!

end
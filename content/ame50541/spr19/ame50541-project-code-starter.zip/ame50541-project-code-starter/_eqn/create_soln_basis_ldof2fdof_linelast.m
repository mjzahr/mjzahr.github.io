function [T, dTdz, Tf, ldof2fdof] = create_soln_basis_ldof2fdof_linelast(Q, dQdz, Qf, f2v)
%CREATE_SOLN_BASIS_LDOF2FDOF_POI Create solution basis (element and face)
%and its derivative w.r.t. reference coordinates and the face-to-element
%degree of freedom mapping for linear elasticity.
%
% Input arguments
% ---------------
%   Q, DQDZ, QF, F2V : See notation.m
%
% Output arguments
% ----------------
%   T, DTDZ, TF, LDOF2FDOF : See notation.m

% Extract information from input
ndim = size(dQdz, 2);
[nv, nq] = size(Q);
[nvf, nqf] = size(Qf);
nf = size(f2v, 2);

% Code me!

end
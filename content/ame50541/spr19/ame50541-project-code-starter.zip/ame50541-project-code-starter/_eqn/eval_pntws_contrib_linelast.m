function [F, dFdu, dFdq, S, dSdu, dSdq] = eval_pntws_contrib_linelast(u, q, eqn_pars)
%EVAL_PNTWS_CONTRIB_LINELAST Evaluate the flux function and source term
%(and their derivatives) that define the linear elasticity equation. 
%
% Input arguments
% ---------------
%   U : Array (NC,) : Primary variables
%
%   Q : Array (NC, NDIM) : Gradient of primary variables
%
%   EQN_PARS : Array (M,) : Parameters to flux function and source term
%
% Output arguments
% ----------------
%   F, DFDU, DFDQ, S, DSDU, DSDQ : See notation.m

% Extract information from input
ndim = size(q, 1);

% Define information regarding size of the system
neqn = ndim; ncomp = ndim;

% Extract parameters
lam = eqn_pars(1);
mu = eqn_pars(2);
f = eqn_pars(3:3+neqn-1);

% Code me!

end
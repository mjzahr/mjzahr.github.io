function [elem, mesh_data] = create_elem_update_mesh_data_ins(geom1, geom2, mesh_data)
%CREATE_ELEM_UPDATE_MESH_DATA_INS Create ELEM structure for the
%incompressible Navier-Stokes equation and update MESH_DATA structure with
%equation-specific information.
%
% Input arguments
% ---------------
%   GEOM1, GEOM2, MESH_DATA : See notation.m. (GEOM1 is the geometry for
%     the 'velocity' element and GEOM2 is the geometry for the 'pressure'
%     element.
%
% Output arguments
% ----------------
%   ELEM, MESH_DATA : See notation.m. MESH_DATA updated to include
%     PDE-specific information, namely, dTdx (derivative of solution basis
%     w.r.t. physical coordinates).

% Evaluate eqn-specific information (solution basis, face-to-element dof)
[T, dTdz, Tf, ldof2fdof] = create_soln_basis_ldof2fdof_ins(geom1.Q, geom1.dQdz, geom1.Qf, geom1.f2v, ...
                                                           geom2.Q, geom2.dQdz, geom2.Qf, geom2.f2v);

% Update mesh_data with derivative of solution basis w.r.t. physical coords
mesh_data = update_mesh_data_soln_basis_deriv(dTdz, mesh_data);

% Create element structure
[ndof_per_elem, nvar, ndim, ~] = size(dTdz);
elem = struct('ndim', ndim, 'etype', geom1.etype, 'porder', geom1.porder, ...
              'nvar', nvar, 'ndof_per_elem', ndof_per_elem, ...
              'ldof2fdof', ldof2fdof, 'f2v', geom1.f2v, ...
              'eval_pntws_contrib', @eval_pntws_contrib_ins, ...
              'eval_soln_basis', @(z) eval_soln_basis_ins(z, geom1, geom2), ...
              'wq', geom1.wq, 'wqf', geom1.wqf, 'T', T, 'Tf', Tf);

end

function [T, dTdz] = eval_soln_basis_ins(z, geom1, geom2)
%EVAL_SOLN_BASIS_INS Evaluate the solution basis given an arbitrary
%reference point (may not be quadrature node) for the incompressible
%Naiver-Stokes equations.
%
% Input arguments
% ---------------
%   Z : Array (NDIM,) : Point at which to evaluate solution basis
%
%   GEOM1, GEOM2 : See main function
%
% Output arguments
% ----------------
%   T, DTDZ : See notation.m. Solution basis and derivative evaluated at Z.

% Extract information from input
nvf1 = size(geom1.Qf, 1);
nvf2 = size(geom2.Qf, 1);
nz = size(z, 2);

% Evaluate geometry basis
[Q1, dQ1dz] = geom1.eval_basis(z);
[Q2, dQ2dz] = geom2.eval_basis(z);
dum1 = zeros(nvf1, nz);
dum2 = zeros(nvf2, nz);

% Evaluate solution basis
[T, dTdz, ~, ~] = create_soln_basis_ldof2fdof_ins(Q1, dQ1dz, dum1, geom1.f2v, ...
                                                  Q2, dQ2dz, dum2, geom2.f2v);

end
function [F, dFdu, dFdq, S, dSdu, dSdq] = eval_pntws_contrib_ins(u, q, eqn_pars)
%EVAL_PNTWS_CONTRIB_INS Evaluate the flux function and source term (and
%their derivatives) that define the incompressible Naiver-Stokes equation. 
%
% Input arguments
% ---------------
%   U : Array (NC,) : Prinary variables
%
%   Q : Array (NC, NDIM) : Gradient of primary variables
%
%   EQN_PARS : Array (M,) : Parameters to flux function and source term
%
% Output arguments
% ----------------
%   F, DFDU, DFDQ, S, DSDU, DSDQ : See notation.m

% Extract information from input
ndim = size(u, 1)-1;

% Define information regarding size of the system
neqn = ndim+1; ncomp = ndim+1;

% Extract parameters, primary variables, and gradient
rho = eqn_pars(1);
nu = eqn_pars(2);
v = u(1:ndim); p = u(end);
dv = q(1:ndim, :);

% Code me!

end
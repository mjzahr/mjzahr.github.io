function [mesh_data] = update_mesh_data_soln_basis_deriv(dTdz, mesh_data)
%UPDATE_MESH_DATA_SOLN_BASIS_DERIV Update MESH_DATA structure to include
%the derivative of the solution basis w.r.t. the physical coordinates.
%
% Input arguments
% ---------------
%   DTDZ, MESH_DATA : See notation.m
%
% Output arguments
% ----------------
%   MESH_DATA : See notation.m. MESH_DATA updated to include dTdx
%     (derivative of solution basis w.r.t. physical coordinates).

% Extract eqn-specific information and from input
[ndof_per_elem, nvar, ndim, nq] = size(dTdz);
nelem = numel(mesh_data);

% Compute derivative of solution basis w.r.t. physical coordinates
for e = 1:nelem
    mesh_data(e).dTdx = zeros(ndof_per_elem, nvar, ndim, nq);
    for k = 1:nq
        Gi = mesh_data(e).Gi(:, :, k);
        for j = 1:nvar
            mesh_data(e).dTdx(:, j, :, k) = squeeze(dTdz(:, j, :, k))*Gi;
        end
    end
end

end

function [W] = compute_vort_ins(U, geom, xcg, e2vcg, ldof2gdof)
%COMPUTE_VORT_INS Compute vorticity from incompressible Naiver-Stokes FEM
%solution.
%
% Input arguments
% ---------------
%   U, GEOM, XCG, E2VCG, LDOF2GDOF, EQN_PARS_FCN : See notation.m. Note:
%     GEOM corresponds to the geometry of the velocity element (not the
%     pressure element).
%
% Output arguments
% ----------------
%   W : Array (M, NNODE) : Array containing the vorticity at each node of
%     the mesh. If NDIM == 2, M = 1 (vorticity is parallel to z-axis) and
%     if NDIM == 3, M = 3.

% Extract information from input
[ndim, nnode] = size(xcg);
[nv, nelem] = size(e2vcg);

% Create basis function evaluated at element nodes
if strcmpi(geom.etype, 'simp')
    [~, dQdz] = eval_interp_simp_lagrange(geom.zk, geom.zk);
elseif strcmpi(geom.etype, 'hcube')
    zk0 = unique(geom.zk(1, :));
    [Q0, dQ0] = eval_interp_onedim_lagrange(zk0, zk0);
    [~, dQdz] = eval_interp_hcube_from_onedim(ndim, Q0, dQ0);
else
    error('Element not supported.');
end

% Compute vorticity at each node of each element
if ndim==2, nc=1; elseif ndim==3, nc=3; else error('Dimension not supported.'); end
We = zeros(nc, nv);
W = zeros(nc, nnode);
for e = 1:nelem
    % Extract element degrees of freedom
    xe = xcg(:, e2vcg(:, e));
    Ue = U(ldof2gdof(:, e));
    ve = reshape(Ue(1:ndim*nv), [ndim, nv]);
    for k = 1:nv
        % Compute derivative of basis function w.r.t. physical coordinates
        G = xe*dQdz(:, :, k);
        dQdx = (G'\dQdz(:, :, k)')';
        
        % Extract element degrees of freedom
        dv = ve*dQdx;
        
        % Vorticity
        if ndim == 2
            We(1, :) = dv(2, 1)-dv(1, 2);
        elseif ndim == 3
            We(1, :) = dv(3, 2)-dv(2, 3);
            We(2, :) = dv(1, 3)-dv(3, 1);
            We(3, :) = dv(2, 1)-dv(1, 2);
        end
    end
    
    % Assemble (by summing) into global stress array
    idx = e2vcg(:, e);
    W(:, idx) = W(:, idx) + We; 
end

% Since assembly is a purely a summation, need to divide by the number
% of instances of each node in the mesh to get the average stress at each
% node
tbl = tabulate(e2vcg(:));
nrep_node = reshape(tbl(:, 2), [1, nnode]);
W = W./repmat(nrep_node, [nc, 1]);

end
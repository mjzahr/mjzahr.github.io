%% Problem 2, part d

% Load finite element matrices and data structures
load fem_mat_for_hwk5prob2d

% Setup time step size and number of steps
which = 'be';
dt = 0.01;
nstep = 200;

% Pre-allocate array to store all time step, store initial condition in
% first column
Uf = zeros(numel(Uf0), nstep+1);
Uf(:, 1) = Uf0;

% Iterate over all time steps, advance solution each time using requested
% method
for n = 1:nstep
    if strcmpi(which, 'fe')
        Uf(:, n+1) = advance_soln_fe1_lin(Uf(:, n), dt, Mff, Kff, Ff);
    elseif strcmpi(which, 'be')
        Uf(:, n+1) = advance_soln_bdf1_lin(Uf(:, n), dt, Mff, Kff, Ff);
    else
        error('Not supported');
    end
end

% Re-assemble global FEM solution
ndof = size(xcg, 2);
free_idx = setdiff(1:ndof, dbc_idx);
U = zeros(ndof, nstep+1);
U(free_idx, :) = Uf;
U(dbc_idx, :) = repmat(dbc_val, [1, nstep+1]);

% Visualize
fh = figure;
for n = 1:nstep+1
    visualize_fem(U(:, n), xcg, e2vcg, e2bnd, geom, false, true, [], fh);
    drawnow;
end
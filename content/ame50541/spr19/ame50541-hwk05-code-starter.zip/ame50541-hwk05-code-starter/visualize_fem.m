function [fh] = visualize_fem(u, xcg, e2vcg, e2bnd, geom, plot_nodes, plot_elem, which_bnd, fh)
%VISUALIZE_FEM Visualize finite element mesh and solution (1d, 2d, 3d).
%
%Input arguments
%---------------
%   U : Array (NNODE,) : Scalar quantity defined over the nodes (XCG) to be
%     plotted (if [], only the mesh will be plotted).
%
%   XCG, E2VCG, E2BND, GEOM : See notation.m
%
%   PLOT_NODES : bool : Whether to plot nodes (default = false)
%
%   PLOT_ELEM : bool : Whether to plot elements (default = true)
%
%   WHICH_BND : Array : Boundary tags (values in E2BND) of surfaces to
%      plot (3d) or highlight (2d). Default in 1d/2d is [], default in 3d
%      is all boundary tags.
%
%   FH : double : Figure handle
%
% Output arguments
% ----------------
%   FH : See above

% Extract information from input
ndim = size(xcg, 1);
nelem = size(e2vcg, 2);
porder = geom.porder;

% Default values
if nargin < 6, plot_nodes = false; end
if nargin < 7, plot_elem = true; end
if nargin < 8
    if ndim < 3
        which_bnd = [];
    elseif ndim == 3
        which_bnd = unique(e2bnd(~isnan(e2bnd(:))));
    end
end
if nargin < 9, fh = []; end

% Create figure, axes (make sure to add onto axes, not overwrite)
if isempty(fh), fh = figure; end
colormap(fh, 'jet'); ax = axes('NextPlot', 'add');

if ndim == 1 % 1d
    % Plot nodes, if requested; nodes on boundary of elements plotted with
    % o and x, interior nodes plotted with only o.
    if plot_nodes
        plot(ax, xcg(1, e2vcg(1, 1)), 0, 'bo');
        for e = 1:nelem
            plot(ax, xcg(1, e2vcg(:, e)), 0*xcg(1, e2vcg(:, e)), 'bo');
            plot(ax, xcg(1, e2vcg(end, e)), 0, 'bx');
        end
    end
    
    % Plot elements, if requested
    if plot_elem
        for e = 1:nelem
            plot(ax, [xcg(1, e2vcg(1, e)), xcg(1, e2vcg(end, e))], [0, 0], 'k-', 'linew', 2);
        end
    end
    
    % If the solution is not empty, plot it
    if ~isempty(u)
        for e = 1:nelem
            plot(xcg(1, e2vcg(:, e)), u(e2vcg(:, e)), 'b-', 'linew', 2);
        end
    end
elseif ndim == 2 % 2d
    % Extract index that will extract only vertices of polygon
    M = reshape(1:(porder+1)^2, porder+1, porder+1);
    if strcmp(geom.etype, 'simp')
        n = (porder+1)*(porder+2)/2;
        idx = [M(1, 1), M(end, 1), n];
    elseif strcmp(geom.etype, 'hcube')
        idx = [M(1, 1), M(end, 1), M(end, end), M(1, end)];
    end
    
    % Plot solution and elements, as requested
    if plot_elem && ~isempty(u)
        patch(ax, 'Vertices', xcg', 'Faces', e2vcg(idx, :)', 'FaceVertexCData', u(:), 'FaceColor', 'interp');
    elseif plot_elem && isempty(u)
        patch(ax, 'Vertices', xcg', 'Faces', e2vcg(idx, :)', 'FaceColor', [0.8, 1.0, 0.8]);
    elseif ~plot_elem && ~isempty(u)
        patch(ax, 'Vertices', xcg', 'Faces', e2vcg(idx, :)', 'FaceVertexCData', u(:), 'FaceColor', 'interp', 'EdgeColor', 'none');
    end
    xlabel('x'); ylabel('y');
    
    % Plot boundaries
    f2v = geom.f2v;
    nf = size(f2v, 2);
    for e=1:nelem
        for f=1:nf
            if ~ismember(e2bnd(f, e), which_bnd), continue; end
            xy = xcg(:, e2vcg(f2v(:, f), e));
            plot(xy(1, :), xy(2, :), 'r-', 'linewidth', 2);
        end
    end
        
    % Plot nodes, if requested
    if plot_nodes, plot(ax, xcg(1, :), xcg(2, :), 'b.', 'markersize', 20); end
else
    % Extract index that will extract only vertices of polygon
    M = reshape(1:(porder+1)^2, porder+1, porder+1);
    if strcmp(geom.etype, 'simp')
        n = (porder+1)*(porder+2)/2;
        idx = [M(1, 1), M(end, 1), n];
    elseif strcmp(geom.etype, 'hcube')
        idx = [M(1, 1), M(end, 1), M(end, end), M(1, end)];
    end
    
    nelem_surf = 0;
    for k=1:numel(which_bnd)
        nelem_surf = nelem_surf + sum(e2bnd(:)==which_bnd(k));
    end
    
    f2v = geom.f2v;
    [nvf, nf] = size(f2v);
    e2vcg_face = zeros(nvf, nelem_surf);
    k = 0;
    for e=1:nelem
        for f=1:nf
            if ~ismember(e2bnd(f, e), which_bnd), continue; end
            k = k+1;
            e2vcg_face(:, k) = e2vcg(f2v(:, f), e);
        end
    end
    
    % Plot solution and elements, as requested
    if plot_elem && ~isempty(u)
        patch(ax, 'Vertices', xcg', 'Faces', e2vcg_face(idx, :)', 'FaceVertexCData', u(:), 'FaceColor', 'interp');
    elseif plot_elem && isempty(u)
        patch(ax, 'Vertices', xcg', 'Faces', e2vcg_face(idx, :)', 'FaceColor', [0.8, 1.0, 0.8]);
    end
    xlabel('x'); ylabel('y'); zlabel('z');
    
    % Plot nodes, if requested
    if plot_nodes
        xcg_surf = xcg(:, unique(e2vcg_face(:)));
        plot3(ax, xcg_surf(1, :), xcg_surf(2, :), xcg_surf(3, :), 'b.', 'markersize', 20);
    end
end
axis tight;
axis equal;

end
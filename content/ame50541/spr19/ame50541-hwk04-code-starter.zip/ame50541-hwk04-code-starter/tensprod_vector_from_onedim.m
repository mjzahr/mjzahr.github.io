function [v] = tensprod_vector_from_onedim(v1, N)
%TENSPROD_VECTOR_FROM_ONEDIM Compute a "vector" tensor product of a vector
%with itself N times, i.e., v(:, i, j, ...) = (v1(i), v1(j), ...).
%
%Input arguments
%---------------
%   V1 : Array (m,) : Vector to use in tensor product
%
%   N : int : Number of times to tensor product v1 with itself
%
%Output arguments
%----------------
%   V : Array (m, m*...*m) : Array resulting from tensor product

in = cell(1, N);
[in{:}] = deal(v1);

out = cell(1, N);
[out{:}] = ndgrid(in{:});
out = cellfun(@(M) M(:), out, 'UniformOutput', false);

v = [out{:}]';

end
function [cooidx, lmat2gmat] = create_sparsity_struct(ldof2gdof)
%CREATE_SPARSITY_STRUCT Create sparsity structure of stiffness (Jacobian)
%matrix corresponding to the connectivity defined in LDOF2GDOF.
%
%Input arguments
%---------------
%   LDOF2GDOF : See description in CREATE_MAP_LDOF_TO_GDOF
%
%Output arguments
%----------------
%   COOIDX : 2D array (nnz, 2) : The rows/columns of the non-zero values of
%     the striffness/Jacobian matrix; cooidx(i, 1) is the row number of the
%     ith nonzero and cooidx(i, 2) is the column number of the ith nonzero.
%
%   LMAT2GMAT : 3D matrix (nldof, nldof, nelem) : Maps local
%     stiffness/Jacobian to sparse global stiffness/Jacobian.
%     LMAT2GMAT(i, j, e) is the non-zero number in the global
%     stiffness/Jacobian corresponding to the (i, j) entry of the
%     stiffness/Jacobian matrix of element e. This is the "matrix version"
%     of LDOF2GDOF. It is perfect for assembling a global stiffness matrix
%     in sparse format from element stiffness matrices.

% Extract sizes and preallocate matrix to store coordinate sparsity
% structure (with repeats)
[nldof, nelem] = size(ldof2gdof);
cooidx_rep = zeros(nldof*nldof*nelem, 2);

% Fill the COO sparsity structure with repeats from ldof2gdof data
% structure 
for e = 1:nelem
    idx = ldof2gdof(:, e);
    [irow0, jcol0] = meshgrid(idx, idx);
    cooidx_rep(nldof*nldof*(e-1)+1:nldof*nldof*e, 1) = irow0(:);
    cooidx_rep(nldof*nldof*(e-1)+1:nldof*nldof*e, 2) = jcol0(:);
end

% Eliminate repeats in COO sparsity structure to determine number of
% nonzeros and extract final/optimal sparsity structure
[cooidx, ~, lmat2gmat] = unique(cooidx_rep, 'rows', 'sorted');
lmat2gmat = reshape(lmat2gmat, nldof, nldof, nelem);

end
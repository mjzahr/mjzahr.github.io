function [w, z] = quad_hcube_gaussleg(ndim, N)
%QUAD_ONEDIM_GAUSSLEG Compute N^d-point Gauss-Legendre quadrature rule in
%d-dimension, i.e., tensor product of one-dimensional Gaussian quadrature
%rules corresponding to Legendre orthogonal polynomials.
%
%Input arguments
%---------------
%   ndim : Number of spatial dimensions
%
%   N : Number of points in quadrature rule
%
%Output arguments
%----------------
%   W : Array (nq,) : Quadrature weights
%
%   Z : Array (nq,) : Quadrature points

[w0, z0] = quad_onedim_gaussleg(N);
w = tensprod_scalar_from_onedim(w0, ndim);
z = tensprod_vector_from_onedim(z0, ndim);

end
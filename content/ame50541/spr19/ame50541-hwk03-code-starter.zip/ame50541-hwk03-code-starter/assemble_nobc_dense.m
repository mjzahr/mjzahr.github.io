function [K, F] = assemble_nobc_dense(Ke, Fe, ldof2gdof)
%ASSEMBLE_NOBC_DENSE Assemble element stiffness matrices and force
%vector into the global quantities without applying Dirichlet boundary
%conditions.
%
%Input arguments
%---------------
%   KE, FE : See defintion in EVAL_UNASSEMBLED*
%
%   LDOF2GDOF : See definition in CREATE_MAP_LDOF_TO_GDOF
%
%Output arguments
%----------------
%   K : 2D array (ndof, ndof) : assembled stiffness matrix PRIOR to static
%     condensation. 
%
%   F : Array (ndof,): assembled force vector PRIOR to static condensation.

% Preallocate K, F
ndof = max(ldof2gdof(:));
nelem = size(ldof2gdof, 2);
F = zeros(ndof, 1);
K = zeros(ndof, ndof);

% Code me!

end

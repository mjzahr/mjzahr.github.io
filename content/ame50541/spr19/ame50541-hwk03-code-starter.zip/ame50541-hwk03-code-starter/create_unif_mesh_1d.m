function [xcg, e2vcg] = create_unif_mesh_1d(xlim, nelem, porder)
%CREATE_UNIF_MESH_1D Create a uniform mesh in 1 dimension.
%
%Input arguments
%---------------
%   XLIM : Array (2,) : Extents of domain
%
%   NELEM : int : Number of elements in mesh
%
%   PORDER : int : Polynomial order of elements in mesh
%
%Output arguments
%----------------
%   XCG, E2VCG : See description in SOLVE_FEM*

xcg = linspace(xlim(1), xlim(2), nelem*porder+1);
e2vcg = zeros(porder+1, nelem);
for e = 1:nelem
    e2vcg(:, e) = [1:porder+1]' + (e-1)*porder;
end

end
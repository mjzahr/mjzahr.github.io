function [Ke, Fe] = eval_elem_contrib_pde1(elem_data)
%EVAL_ELEM_CONTRIB_PDE1 Evaluate the stiffness matrix and force
%vector for PDE1 element in 1D using linear Lagrange basis.
%
%   PDE : -T_{,ii} = 0,  0 < x < 1, 0 < y < 1
%   BCs :  T(x=1, y) = T(x, y=1) = 0,
%          (dT*n)_{x, y=0} = 0, (dT*n)_{x=0, y} = 1
%
%   Basis: phi1 = (x2-x)(y2-y)/(x2-x1)/(y2-y1)
%          phi2 = (x-x1)(y2-y)/(x2-x1)/(y2-y1)
%          phi3 = (x2-x)(y-y1)/(x2-x1)/(y2-y1)
%          phi4 = (x-x1)(y-y1)/(x2-x1)/(y2-y1)
%
%Input arguments
%---------------
%   ELEM_DATA : structure : Element-specific fields
%      ELEM_DATA.x1, ELEM_DATA.x2 : number : x limits of element
%      ELEM_DATA.y1, ELEM_DATA.y2 : number : y limits of element
%
%Output arguments
%----------------
%   KE : 2D matrix (ndof_per_node*nnode_per_elem,
%                   ndof_per_node*nnode_per_elem)
%      : Element stiffness matrix
%
%   FE : Array (ndof_per_node*nnode_per_elem,) : Element force vector

% Extract information from input
x1 = elem_data.x1;
x2 = elem_data.x2;
y1 = elem_data.y1;
y2 = elem_data.y2;
dx = x2-x1; dy = y2-y1;

% Code me!

end

function [Ke, Fe] = eval_elem_contrib_pde0(elem_data)
%EVAL_ELEM_CONTRIB_PDE0 Evaluate the stiffness matrix and force
%vector for PDE0 element in 1D using linear Lagrange basis.
%
%   PDE : -u'' - u + x^2 = 0,  0 < x < 1
%   BCs :  u(0) = 0, u'(1) = 1
%
%   Basis: phi1 = (x2-x)/(x2-x1)
%          phi2 = (x-x1)/(x2-x1)
%
%Input arguments
%---------------
%   ELEM_DATA : structure : Element-specific fields
%      ELEM_DATA.x1 : number : position of local node 1
%      ELEM_DATA.x2 : number : position of local node 2
%
%Output arguments
%----------------
%   KE : 2D matrix (ndof_per_node*nnode_per_elem,
%                   ndof_per_node*nnode_per_elem)
%      : Element stiffness matrix
%
%   FE : Array (ndof_per_node*nnode_per_elem,) : Element force vector

% Extract information from input
x1 = elem_data.x1;
x2 = elem_data.x2;
he = x2-x1;

% Code me!

end

function [elem, elem_data] = create_elem_structs_pde0(xcg, e2vcg)
%CREATE_ELEM_STRUCTS_PDE0 Create structures defining the PDE0 element and
%its data assuming linear Lagrange basis functions used. See
%EVAL_ELEM_CONTRIB_PDE0 for description of PDE, BCs, and basis.
%
%Input arguments
%---------------
%   XCG, E2VCG : See description in SOLVE_FEM_*
%
%Output arguments
%----------------
%   ELEM : See description in SOLVE_FEM_*
%
%   ELEM_DATA : structure array (nelem,) : Element-specific fields
%      See description of single element in structure in
%      EVAL_ELEM_CONTRIB_PDE0

nelem = size(e2vcg, 2);
x1 = zeros(nelem, 1);
x2 = zeros(nelem, 1);
for e = 1:nelem
    x1(e) = xcg(1, e2vcg(1, e));
    x2(e) = xcg(1, e2vcg(2, e));
end

% Create element structures
elem = struct('ndim', 1, 'etype', 'hcube', 'porder', 1, ...
              'ndof_per_node', 1, 'nnode_per_elem', 2, ...
              'stiff_force', @eval_elem_contrib_pde0);
elem_data = struct('x1', num2cell(x1), 'x2', num2cell(x2));

end

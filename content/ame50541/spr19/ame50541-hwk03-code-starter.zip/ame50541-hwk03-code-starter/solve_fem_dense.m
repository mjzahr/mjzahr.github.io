function [u] = solve_fem_dense(e2vcg, elem, elem_data, dbc_idx, dbc_val)
%SOLVE_FEM_DENSE Approximate the solution of a PDE by solving for the nodal
%degrees of freedom on a mesh using the finite element method.
%
% Input arguments
% ---------------
%   XCG : 2D array (ndim, nnode) : The position of the nodes in the mesh.
%     The (i, j)-entry is the position of node j in the ith dimension. The
%     global node numbers are defined by the columns of this matrix, e.g.,
%     the node at xcg(:, j) is the jth node of the mesh.
%
%   E2VCG : 2D array (nnode_per_elem, nelem): The connectivity of the
%     mesh. The (:, e)-entries are the global node numbers of the nodes
%     that comprise element e. The local node numbers of each element are
%     defined by the columns of this matrix, e.g., e2vcg(i, e) is the
%     global node number of the ith local node of element e.
%
%   ELEM : structure : Element metadata
%     ELEM.NDIM : number : Number of dimensions
%     ELEM.ETYPE : string : Element type (usually 'simp' for simplex or
%       'hcube' for hypercube)
%     ELEM.PORDER : number : Polynomial order
%     ELEM.NDOF_PER_NODE : number : Number of degrees of freedom per node
%     ELEM.NNODE_PER_ELEM : number : Number of nodes per element
%     ELEM.STIFF_FORCE : function : Function that takes a single entry of
%       the ELEM_DATA structure array as input and returns the element
%       stiffness matrix and force vector.
%
%   ELEM_DATA : structure array (nelem,) : Element-specific fields
%
%   DBC_IDX : Array (ndbc,) : Indices into array defined over global dofs
%   (size = ndim*nnode) that indicates those with prescribed displacements
%   (Dirichlet BCs).
%
%   DBC_VAL : Array (ndbc,) : Value of the prescribed displacements such
%   that U(DBC_IDX) = DBC_VAL (see definition of U below).
%
% Output arguments
% -----------------
%   U : Array (ndof_per_node*nnode,) : The coefficients corresponding to
%   each DOF in the mesh.
%
% Note: The ordering of one-dimensional vectors over all/some of the
% degrees of freedom will ALWAYS be ordered first by the dofs at a fixed
% node and then across all nodes. For example, let U be the vector of size
% ndof_per_node*nnode containing the displacements at all nodes, then its
% components are U = [Ux_1; Uy_1; ... ; Ux_nnode; Uy_nnode], where Ux_i,
% Uy_i are the x- and y- displacements at node i.

% Code me!

end

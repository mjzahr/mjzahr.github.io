function  [Ke, Fe] = eval_unassembled(elem, elem_data)
%EVAL_UNASSEMBLED Evaluate/store element stiffness matrix and
%force vector for each element.
%
%Input arguments
%---------------
%   ELEM, ELEM_DATA : See description in CREATE_ELEM_STRUCTS_*
%
%Output arguments
%----------------
%   KE : 3D array (ndim*nnode_per_elem, ndim*nnode_per_elem, nelem) :
%     unassembled element stiffness matrices (Ke(:, :, e) is the stiffness
%     matrix of element e).
%
%   FE : 2D array (ndim*nnode_per_elem, nelem) : unassembled force vector
%     unassembled element stiffness matrices (Fe(:, e) is the force vector
%     of element e).

% Extract relevant variables from element
ndof_per_node = elem.ndof_per_node;
nnode_per_elem = elem.nnode_per_elem;
nelem = length(elem_data);

% Code me!

end

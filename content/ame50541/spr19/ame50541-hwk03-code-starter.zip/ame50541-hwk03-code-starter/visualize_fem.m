function [] = visualize_fem(u, xcg, e2vcg, elem, plot_nodes, plot_elem)
%VISUALIZE_FEM Visualize finite element mesh and solution (1d, 2d).
%
%Input arguments
%---------------
%   U : Array (ndof,) : FEM solution
%
%   XCG, E2VCG : See description in SOLVE_FEM*
%
%   ELEM : struct : Element structure (must contain porder and, if 2d,
%                   etype, which is either 'simp' or 'hcube')
%
%   PLOT_NODES : bool : Whether to plot nodes
%
%   PLOT_ELEM : bool : Whether to plot elements
%
%Output arguments
%----------------
%   None

if nargin < 5, plot_nodes = false; end
if nargin < 6, plot_elem = false; end

% Extract information from input
ndim = size(xcg, 1);
nelem = size(e2vcg, 2);
porder = elem.porder;

% Create figure, axes (make sure to add onto axes, not overwrite)
figure; ax = axes('NextPlot', 'add');

if ndim == 1 % 1d
    % Plot nodes, if requested; nodes on boundary of elements plotted with
    % o and x, interior nodes plotted with only o.
    if plot_nodes
        plot(ax, xcg(1, e2vcg(1, 1)), 0, 'bo');
        for e = 1:nelem
            plot(ax, xcg(1, e2vcg(:, e)), 0*xcg(1, e2vcg(:, e)), 'bo');
            plot(ax, xcg(1, e2vcg(end, e)), 0, 'bx');
        end
    end
    
    % Plot elements, if requested
    if plot_elem
        for e = 1:nelem
            plot(ax, [xcg(1, e2vcg(1, e)), xcg(1, e2vcg(end, e))], [0, 0], 'k-', 'linew', 2);
        end
    end
    
    % If the solution is not empty, plot it
    if ~isempty(u)
        for e = 1:nelem
            plot(xcg(1, e2vcg(:, e)), u(e2vcg(:, e)), 'b-', 'linew', 2);
        end
    end
elseif ndim == 2 % 2d
    % Extract index that will extract only vertices of polygon
    M = reshape(1:(porder+1)^2, porder+1, porder+1);
    if strcmp(elem.etype, 'simplex')
        n = (porder+1)*(porder+2)/2;
        idx = [M(1, 1), M(end, 1), n];
    elseif strcmp(elem.etype, 'hcube')
        idx = [M(1, 1), M(end, 1), M(end, end), M(1, end)];
    end
    
    % Plot solution and elements, as requested
    if plot_elem && ~isempty(u)
        patch(ax, 'Vertices', xcg', 'Faces', e2vcg(idx, :)', 'FaceVertexCData', u(:), 'FaceColor', 'interp');
    elseif plot_elem && isempty(u)
        patch(ax, 'Vertices', xcg', 'Faces', e2vcg(idx, :)', 'FaceColor', [0.8, 1.0, 0.8]);
    elseif ~plot_elem && ~isempty(u)
        patch(ax, 'Vertices', xcg', 'Faces', e2vcg(idx, :)', 'FaceVertexCData', u(:), 'FaceColor', 'interp', 'EdgeColor', 'none');
    end
    
    % Plot nodes, if requested
    if plot_nodes, plot(ax, xcg(1, :), xcg(2, :), 'bo'); end
else
    error('Dimension not supported');
end

end

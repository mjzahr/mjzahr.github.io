function [xcg, e2vcg] = create_unif_mesh_2d_rect(xlim, ylim, nelx, nely, porder)
%CREATE_UNIF_MESH_2D Create a uniform mesh in 2 dimensions.
%
%Input arguments
%---------------
%   XLIM, YLIM : Array (2,) : Extents of domain in x/y-direction
%
%   NELX, NELY : int : Number of elements in mesh in x/y-direction
%
%   PORDER : int : Polynomial order of elements in mesh
%
%Output arguments
%----------------
%   XCG, E2VCG : See description in SOLVE_FEM*

% Create nodes using meshgrid
x = linspace(xlim(1), xlim(2), nelx*porder+1);
y = linspace(ylim(1), ylim(2), nely*porder+1);
[Y, X] = meshgrid(y, x);
xcg = [X(:), Y(:)]';

% Create connectivity
nelem = nelx*nely;
e2vcg = zeros((porder+1)^2, nelem);
for ey = 1:nely
    for ex = 1:nelx
        gnode_offsets = repmat((1:porder+1)', 1, porder+1) + ...
                        repmat((nelx*porder+1)*(0:porder), porder+1, 1) - 1;
        gnode_bottom_left = 1 + (ex-1)*porder + (ey-1)*porder*(nelx*porder+1);
        e2vcg(:, ex+(ey-1)*nelx) = gnode_bottom_left+gnode_offsets(:);
    end
end

end
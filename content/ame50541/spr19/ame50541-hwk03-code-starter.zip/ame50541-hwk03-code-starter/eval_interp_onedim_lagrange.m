function [Q, dQ] = eval_interp_onedim_lagrange(xk, x)
%EVAL_INTERP_ONEDIM_LAGRANGE Evaluate Lagrange interpolation functions on
%interval (xk(1), xk(end)) associated with nodes xk (number of nodes = nv)
%at points x (number of points = nx).
%
%Input arguments
%---------------
%   XK : Array (nv,) : Nodes at which Lagrange polynomials interpolate
%    values.
%
%   X : Array (nx,) : Points at which Lagrange polynomials are evaluated.
%
%Output arguments
%----------------
%   Q : 2D array (nv, nx) : Lagrange interpolation functions (nv)
%    evaluated at each point in x. 
%
%   DQ : 2D array (nv, nx) : Derivative of Lagrange interpolation
%   functions (nv) evaluated at each point in x

% Extract information from input, ensure xk and x appropriately shaped
nv = numel(xk);
nx = numel(x);
xk = xk(:); x = x(:);

% Code me!

end
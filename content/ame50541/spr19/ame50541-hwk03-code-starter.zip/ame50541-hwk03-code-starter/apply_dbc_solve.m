function  [u] = apply_dbc_solve(K, F, dbc_idx, dbc_val)
%APPLY_DBC_SOLVE Apply Dirichlet boundary conditions via static
%condensation.
%
%Input arguments
%---------------
%   K : 2D array (ndof, ndof) : assembled stiffness matrix
%
%   F : Array (ndim*nnode,) : assembled force vector
%
%   DBC_IDX, DBC_VAL : See defintion in SOLVE_FEM_*
%
%Output arguments
%----------------
%   U : See defintion in SOLVE_FEM_*

% Code me!

end

function [Q, dQ] = eval_interp_hcube_from_onedim(ndim, Q1d, dQ1d)
%EVAL_INTERP_HCUBE_FROM_ONEDIM Evaluate interpolation functions for
%hypercube from interpolation functions in one-dimension. The nodes of
%the interpolation functions (and points at which they are evaluated) are
%inherited from the tensor product structure.
%
%Input arguments
%---------------
%   NDIM : number : Number of dimensions of hypercube
%
%   Q1D : 2D array (nv, nx) : One-dimensional interpolation functions (nv)
%     evaluated at each point in x,
%
%   DQ1D : 2D array (nv, nx) : Derivative of one-dimensional interpolation
%     functions (nv) evaluated at each point in x
%
%Output arguments
%----------------
%   Q : 2D array (nv^ndim, nx^ndim) : Interpolation functions for the
%     hypercube element evaluated at each point inherited from the 1D
%     element.
%
%   DQ : 2D array (nv^ndim, ndim, nx^ndim) : Derivative of interpolation
%     functions evaluated at each point inherited from the 1D element.

% Extract information from input
[nv, nx] = size(Q1d);

% Code me!
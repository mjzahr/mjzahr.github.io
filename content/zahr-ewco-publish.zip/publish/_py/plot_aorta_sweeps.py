import numpy as np
  
from pytikz.pltobj import Figure, Groupplot, Axes, Line, Graphics, Draw, Node
from pytikz.sys_core import write_tex, cleanup_compile
from pytikz.style import Linestyle

# Predefined styles
dot = Linestyle(mark='*', mark_size=1.5, mark_options='{solid, thin}')
dotoff = Linestyle(mark='circle', mark_size=1.5)
square = Linestyle(mark='square*', mark_size=1.5, mark_options='{solid, thin}')
squareoff = Linestyle(mark='square', mark_size=1.5)
pentagon = Linestyle(mark='pentagon*', mark_size=1.5, mark_options='{solid, thin}')
pentagonoff = Linestyle(mark='pentagon', mark_size=1.5)
triangle = Linestyle(mark='triangle*', mark_size=1.5, mark_options='{solid, thin}')
triangleoff = Linestyle(mark='triangle', mark_size=1.5)
diamond = Linestyle(mark='diamond*', mark_size=1.5, mark_options='{solid, thin}')
diamondoff = Linestyle(mark='diamond', mark_size=1.5)
dotsmall = Linestyle(mark='*', mark_size=0.5, mark_options='{solid,thin}')
squareoffsmall = Linestyle(mark='square*', mark_size=0.5)


# Load data
dataorta = np.load('../../simulations/_dat/full_aorta_data.npz')
# dataortamri = np.load('../../simulations/_dat/implicit_run_mrionly_june24.npz')
err_sbi = np.sqrt(dataorta['e_sbi'])*100
err_mri = np.sqrt(dataorta['e_mri'])*100
pars_cor_err = dataorta['pars_cor_err']

## Figure 1: Error vs. VPD ##

# Setup figure/axes
fig = Figure()
grpsty = '{group size = 4 by 2, horizontal sep = 0.3cm, vertical sep = 0.4cm}'
grpplot = Groupplot(width='0.3\\textwidth', group_style=grpsty, parent=fig)
ax0 = Axes('axis', ymin=0, ymax=7, xtick='{3, 5, 10}', xticklabels='{,,}',
           ylabel='{$e_{\mathrm{SBI}}$ (\%)}', title='{$\kappa=0\%$}', parent=grpplot)
ax1 = Axes('axis', ymin=0, ymax=7, xtick='{3, 5, 10}', xticklabels='{,,}',
           yticklabels='{,,}', title='{$\kappa=5\%$}', parent=grpplot)
ax2 = Axes('axis', ymin=0, ymax=7, xtick='{3, 5, 10}', xticklabels='{,,}',
           yticklabels='{,,}', title='{$\kappa=10\%$}', parent=grpplot)
ax3 = Axes('axis', ymin=0, ymax=7, xtick='{3, 5, 10}', xticklabels='{,,}',
           yticklabels='{,,}', title='{$\kappa=20\%$}', parent=grpplot)
ax5 = Axes('axis', ymin=40, ymax=100, xtick='{3, 5, 10}', xlabel='{$N$ (VPD)}', ylabel='{$e_{\mathrm{MRI}}$ (\%)}', parent=grpplot)
ax6 = Axes('axis', ymin=40, ymax=100, xtick='{3, 5, 10}', xlabel='{$N$ (VPD)}', yticklabels='{,,}', parent=grpplot)
ax7 = Axes('axis', ymin=40, ymax=100, xtick='{3, 5, 10}', xlabel='{$N$ (VPD)}', yticklabels='{,,}', parent=grpplot)
ax8 = Axes('axis', ymin=40, ymax=100, xtick='{3, 5, 10}', xlabel='{$N$ (VPD)}', yticklabels='{,,}', parent=grpplot)

# Plot data
lsty = [dot, square, triangle]
col = ['black', 'blue', 'red']
for i in [0,2]:
    Line(pars_cor_err[i, 0, :, 2], err_sbi[i, 0, :], col[i], 'solid',
         lsty[i], parent=ax0, label='line:err_aorta_sbi_vpd'+str(i))
    Line(pars_cor_err[i, 1, :, 2], err_sbi[i, 1, :], col[i], 'solid',
         lsty[i], parent=ax1)
    Line(pars_cor_err[i, 2, :, 2], err_sbi[i, 2, :], col[i], 'solid',
         lsty[i], parent=ax2)
    Line(pars_cor_err[i, 3, :, 2], err_sbi[i, 3, :], col[i], 'solid',
         lsty[i], parent=ax3)
    Line(pars_cor_err[i, 0, :, 2], err_mri[i, 0, :], col[i], 'solid',
         lsty[i], parent=ax5)
    Line(pars_cor_err[i, 1, :, 2], err_mri[i, 1, :], col[i], 'solid',
         lsty[i], parent=ax6)
    Line(pars_cor_err[i, 2, :, 2], err_mri[i, 2, :], col[i], 'solid',
         lsty[i], parent=ax7)
    Line(pars_cor_err[i, 3, :, 2], err_mri[i, 3, :], col[i], 'solid',
         lsty[i], parent=ax8)

# Write Tikz file, corresponding TeX file, compile, and view PDF
fname_prefix='error_aorta_fcnof_vpd'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Figure 3: Error vs. noise ##

# Setup figure/axes
fig = Figure()
grpsty = '{group size = 2 by 2, horizontal sep = 0.3cm, vertical sep = 0.4cm}'
grpplot = Groupplot(width='0.3\\textwidth', group_style=grpsty, parent=fig)
ax0 = Axes('axis', ymin=0, ymax=7, xtick='{0, 5, 10, 20}', xticklabels='{,,}',
           ytick='{0,3,6,9,12}', ylabel='{$e_{\mathrm{SBI}}$ (\%)}', title='{$\mathrm{Re}=100$}', parent=grpplot)
ax1 = Axes('axis', ymin=0, ymax=7, xtick='{0, 5, 10, 20}', xticklabels='{,,}',
           ytick='{0,3,6,9,12}', yticklabels='{,,}', title='{$\mathrm{Re}=1000$}', parent=grpplot)
ax5 = Axes('axis', ymin=40, ymax=100, xtick='{0, 5, 10, 20}', xlabel='{$\kappa$ (\%)}', ylabel='{$e_{\mathrm{MRI}}$ (\%)}', parent=grpplot)
ax6 = Axes('axis', ymin=40, ymax=100, xtick='{0, 5, 10, 20}', xlabel='{$\kappa$ (\%)}', yticklabels='{,,}', parent=grpplot)

# Plot data
lsty = [dot, square, triangle, diamond, pentagon]
col = ['black', 'blue', 'red']
for i in range(3):
    Line(100*pars_cor_err[0,:,i,1], err_sbi[0,:,i], col[i], 'solid',
         lsty[i], parent=ax0, label='line:err_aorta_sbi_noise'+str(i))
    Line(100*pars_cor_err[2,:,i,1], err_sbi[2,:,i], col[i], 'solid',
         lsty[i], parent=ax1)
    Line(100*pars_cor_err[0,:,i,1], err_mri[0,:,i], col[i], 'solid',
         lsty[i], parent=ax5)
    Line(100*pars_cor_err[2,:,i,1], err_mri[2,:,i], col[i], 'solid',
         lsty[i], parent=ax6)

# Write Tikz file, corresponding TeX file, compile, and view PDF
fname_prefix='error_aorta_fcnof_noise'
write_tex(fig, fname_prefix=fname_prefix, view=True)

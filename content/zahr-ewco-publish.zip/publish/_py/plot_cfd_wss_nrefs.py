import numpy as np
  
from pytikz.pltobj import Figure, Groupplot, Axes, Line, Graphics, Draw, Node
from pytikz.sys_core import write_tex, cleanup_compile
from pytikz.style import Linestyle

## WSS 1

# Load data
dat0 = np.load('../_dat/sten_wss_truth.npz')
dat1 = np.load('../_dat/sten_wss_sbi_noise20_nref0.npz')
dat2 = np.load('../_dat/sten_wss_sbi_noise20_nref1.npz')
dat3 = np.load('../_dat/sten_wss_sbi_noise20_nref2.npz')

def mk_dist(xf):
    dx = xf[:, 1:]-xf[:, :-1]
    s00 = np.sqrt(np.sum((xf[:, 1:]-xf[:, :-1])**2, axis=0))
    return np.concatenate(([0.0], np.cumsum(s00)))

def mk_cont(Fn0):
    Fn = Fn0.copy('F')
    for k in range(Fn.shape[2]-1):
        Fn[:,-1,k] = 0.5*(Fn0[:,-1,k]+Fn0[:,0,k+1])
        Fn[:,0,k+1] = 0.5*(Fn0[:,-1,k]+Fn0[:,0,k+1])
    return Fn

shp0 = dat0['xf'].shape
xf0 = dat0['xf'].reshape((shp0[0], -1), order='F')
s0 = mk_dist(xf0)
s0 = s0.reshape((shp0[1], shp0[2]), order='F')
Fn0 = mk_cont(dat0['Fn'])

shp1 = dat1['xf'].shape
xf1 = dat1['xf'].reshape((shp1[0], -1), order='F')
s1 = mk_dist(xf1)
s1 = s1.reshape((shp1[1], shp1[2]), order='F')
Fn1 = mk_cont(dat1['Fn'])

shp2 = dat2['xf'].shape
xf2 = dat2['xf'].reshape((shp2[0], -1), order='F')
s2 = mk_dist(xf2)
s2 = s2.reshape((shp2[1], shp2[2]), order='F')
Fn2 = mk_cont(dat2['Fn'])

shp3 = dat3['xf'].shape
xf3 = dat3['xf'].reshape((shp3[0], -1), order='F')
s3 = mk_dist(xf3)
s3 = s3.reshape((shp3[1], shp3[2]), order='F')
Fn3 = mk_cont(dat3['Fn'])

# Create figure and axes
fig = Figure()
ax0 = Axes('axis', width='0.5\\textwidth', parent=fig,
           xlabel='{Distance along wall (UNIT)}',
           ylabel='{$\sigma^\mathrm{wss}$ (UNIT)}',
           xticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}',
           yticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}')

# Plot WSS
Line(s0.flatten('F'), Fn0[2, :, :].flatten('F'), 'black', 'thick', 'solid',
     parent=ax0, label='line:wss_truth')
Line(s1.flatten('F'), Fn1[2, :, :].flatten('F'), 'red', 'thick', 'dashed',
     parent=ax0, label='line:wss_sbi_nref0')
Line(s2.flatten('F'), Fn2[2, :, :].flatten('F'), 'blue', 'thick', 'dotted',
     parent=ax0, label='line:wss_sbi_nref1')
Line(s3.flatten('F'), Fn3[2, :, :].flatten('F'), 'magenta', 'thick', 'dash dot',
     parent=ax0, label='line:wss_sbi_nref2')

# Write Tikz files, compile TeX
fname_prefix='wss_truth_sbi_nrefs'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## WSS cfd
dat = np.load('../../simulations/_dat/full_run_july2_full.npz')
F = dat['F_sbi']
F1 = dat['F_mri']
F0 = dat['F_tru']
su = dat['su']


fig = Figure()
ax0 = Axes('axis', width='0.5//textwidth', parent=fig,
            xlabel='Distance along wall (cm)',
            ylabel='{$\sigma^{WSS}$ cPa}',
			xticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}',
			yticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}')

# Plot WSS
Line(su, F0[2,3,2,0].squeeze(), 'black', 'thick', 'solid',
     parent=ax0, label='line:wss_truth')
Line(su, F[2,3,2,0].squeeze(), 'red', 'thick', 'dashed',
     parent=ax0, label='line:wss_sbi_nref0')
Line(su, F[2,3,2,1].squeeze(), 'blue', 'thick', 'dotted',
     parent=ax0, label='line:wss_sbi_nref1')
Line(su, F[2,3,2,2].squeeze(), 'magenta', 'thick', 'dash dot',
     parent=ax0, label='line:wss_sbi_nref2')

# Write Tikz files, compile TeX
fname_prefix='wss_truth_sbi_nrefs1'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)


import sys
sys.exit()

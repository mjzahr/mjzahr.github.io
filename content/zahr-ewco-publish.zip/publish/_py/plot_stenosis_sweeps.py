import numpy as np
  
from pytikz.pltobj import Figure, Groupplot, Axes, Line, Graphics, Draw, Node
from pytikz.sys_core import write_tex, cleanup_compile
from pytikz.style import Linestyle

# Predefined styles
dot = Linestyle(mark='*', mark_size=1.5, mark_options='{solid, thin}')
dotoff = Linestyle(mark='circle', mark_size=1.5)
square = Linestyle(mark='square*', mark_size=1.5, mark_options='{solid, thin}')
squareoff = Linestyle(mark='square', mark_size=1.5)
pentagon = Linestyle(mark='pentagon*', mark_size=1.5, mark_options='{solid, thin}')
pentagonoff = Linestyle(mark='pentagon', mark_size=1.5)
triangle = Linestyle(mark='triangle*', mark_size=1.5, mark_options='{solid, thin}')
triangleoff = Linestyle(mark='triangle', mark_size=1.5)
diamond = Linestyle(mark='diamond*', mark_size=1.5, mark_options='{solid, thin}')
diamondoff = Linestyle(mark='diamond', mark_size=1.5)
dotsmall = Linestyle(mark='o', mark_size=1, mark_options='{solid,thin}')
squareoffsmall = Linestyle(mark='square*', mark_size=0.5)
plus = Linestyle(mark='+', mark_size=1.5, mark_options='{solid, thin}')

# Load data
dat = np.load('../../simulations/_dat/stenosis_may28.npz')
wssest = dat['wss_estimates']
err_sbi = np.sqrt(dat['e_sbi'])*100
pars_cor_err = dat['pars_cor_err']
dat2 = np.load('../../simulations/_dat/local_mri_only_sten_jun16.npz')
err_mri = np.sqrt(dat2['e_mri'])*100

## Figure 1: Error vs. VPD ##

# Setup figure/axes
fig = Figure()
grpsty = '{group size = 4 by 2, horizontal sep = 0.3cm, vertical sep = 0.4cm}'
grpplot = Groupplot(width='0.3\\textwidth', group_style=grpsty, parent=fig)
ax0 = Axes('axis', ymin=0, ymax=3, xtick='{1, 3, 5, 9, 17}', xticklabels='{,,}',
           ylabel='{$e_{\mathrm{SBI}}$ (\%)}', title='{$\kappa=0\%$}', parent=grpplot)
ax1 = Axes('axis', ymin=0, ymax=3, xtick='{1, 3, 5, 9, 17}', xticklabels='{,,}',
           yticklabels='{,,}', title='{$\kappa=5\%$}', parent=grpplot)
ax2 = Axes('axis', ymin=0, ymax=3, xtick='{1, 3, 5, 9, 17}', xticklabels='{,,}',
           yticklabels='{,,}', title='{$\kappa=10\%$}', parent=grpplot)
ax3 = Axes('axis', ymin=0, ymax=3, xtick='{1, 3, 5, 9, 17}', xticklabels='{,,}',
           yticklabels='{,,}', title='{$\kappa=20\%$}', parent=grpplot)
ax5 = Axes('axis', ymin=0, ymax=70, xtick='{1, 3, 5, 9, 17}', xlabel='{$N$ (VPD)}', ylabel='{$e_{\mathrm{MRI}}$ (\%)}', parent=grpplot)
ax6 = Axes('axis', ymin=0, ymax=70, xtick='{1, 3, 5, 9, 17}', xlabel='{$N$ (VPD)}', yticklabels='{,,}', parent=grpplot)
ax7 = Axes('axis', ymin=0, ymax=70, xtick='{1, 3, 5, 9, 17}', xlabel='{$N$ (VPD)}', yticklabels='{,,}', parent=grpplot)
ax8 = Axes('axis', ymin=0, ymax=70, xtick='{1, 3, 5, 9, 17}', xlabel='{$N$ (VPD)}', yticklabels='{,,}', parent=grpplot)

# Plot data
lsty = [dot, square, triangle]
col = ['black', 'blue', 'red']
for i in range(3):
    Line(pars_cor_err[i,0,1:5,2], err_sbi[i,0,1:5], col[i], 'solid',
         lsty[i], parent=ax0, label='line:err_sbi_vpd'+str(i))
    Line(pars_cor_err[i,1,1:5,2], err_sbi[i,1,1:5], col[i], 'solid',
         lsty[i], parent=ax1)
    Line(pars_cor_err[i,2,1:5,2], err_sbi[i,2,1:5], col[i], 'solid',
         lsty[i], parent=ax2)
    Line(pars_cor_err[i,3,1:5,2], err_sbi[i,3,1:5], col[i], 'solid',
         lsty[i], parent=ax3)
    Line(pars_cor_err[i,0,1:5,2], err_mri[i,0,1:5], col[i], 'solid',
         lsty[i], parent=ax5)
    Line(pars_cor_err[i,1,1:5,2], err_mri[i,1,1:5], col[i], 'solid',
         lsty[i], parent=ax6)
    Line(pars_cor_err[i,2,1:5,2], err_mri[i,2,1:5], col[i], 'solid',
         lsty[i], parent=ax7)
    Line(pars_cor_err[i,3,1:5,2], err_mri[i,3,1:5], col[i], 'solid',
         lsty[i], parent=ax8)

# Write Tikz file, corresponding TeX file, compile, and view PDF
fname_prefix='error_fcnof_vpd'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)


## Figure 2: Error vs. Re ##

# Setup figure/axes
fig = Figure()
grpsty = '{group size = 4 by 2, horizontal sep = 0.3cm, vertical sep = 0.4cm}'
grpplot = Groupplot(width='0.3\\textwidth', group_style=grpsty, parent=fig)
ax0 = Axes('axis', ymin=0, ymax=4, xtick='{100, 500, 1000}', xticklabels='{,,}',
           ylabel='{$e_{\mathrm{SBI}}$ (\%)}', title='{$N=3$ VPD}', parent=grpplot)
ax1 = Axes('axis', ymin=0, ymax=4, xtick='{100, 500, 1000}', xticklabels='{,,}',
           yticklabels='{,,}', title='{$N=5$ VPD}', parent=grpplot)
ax2 = Axes('axis', ymin=0, ymax=4, xtick='{100, 500, 1000}', xticklabels='{,,}',
           yticklabels='{,,}', title='{$N=9$ VPD}', parent=grpplot)
ax3 = Axes('axis', ymin=0, ymax=4, xtick='{100, 500, 1000}', xticklabels='{,,}',
           yticklabels='{,,}', title='{$N=17$ VPD}', parent=grpplot)
ax5 = Axes('axis', ymin=0, ymax=80, xtick='{100, 500, 1000}', xlabel='{$\mathrm{Re}$}', ylabel='{$e_{\mathrm{MRI}}$ (\%)}', parent=grpplot)
ax6 = Axes('axis', ymin=0, ymax=80, xtick='{100, 500, 1000}', xlabel='{$\mathrm{Re}$}', yticklabels='{,,}', parent=grpplot)
ax7 = Axes('axis', ymin=0, ymax=80, xtick='{100, 500, 1000}', xlabel='{$\mathrm{Re}$}', yticklabels='{,,}', parent=grpplot)
ax8 = Axes('axis', ymin=0, ymax=80, xtick='{100, 500, 1000}', xlabel='{$\mathrm{Re}$}', yticklabels='{,,}', parent=grpplot)

# Plot data
lsty = [dot, square, triangle, diamond, pentagon]
col = ['black', 'blue', 'red', 'magenta', 'green']
for i in range(5):
    Line(pars_cor_err[:,i,1,0], err_sbi[:,i,1], col[i], 'solid',
         lsty[i], parent=ax0, label='line:err_sbi_Re'+str(i))
    Line(pars_cor_err[:,i,2,0], err_sbi[:,i,2], col[i], 'solid',
         lsty[i], parent=ax1)
    Line(pars_cor_err[:,i,3,0], err_sbi[:,i,3], col[i], 'solid',
         lsty[i], parent=ax2)
    Line(pars_cor_err[:,i,4,0], err_sbi[:,i,4], col[i], 'solid',
         lsty[i], parent=ax3)
    Line(pars_cor_err[:,i,1,0], err_mri[:,i,1], col[i], 'solid',
         lsty[i], parent=ax5)
    Line(pars_cor_err[:,i,2,0], err_mri[:,i,2], col[i], 'solid',
         lsty[i], parent=ax6)
    Line(pars_cor_err[:,i,3,0], err_mri[:,i,3], col[i], 'solid',
         lsty[i], parent=ax7)
    Line(pars_cor_err[:,i,4,0], err_mri[:,i,4], col[i], 'solid',
         lsty[i], parent=ax8)

# Write Tikz file, corresponding TeX file, compile, and view PDF
fname_prefix='error_fcnof_Re'
write_tex(fig, fname_prefix=fname_prefix, view=True)


## Figure 3: Error vs. noise ##

# Setup figure/axes
fig = Figure()
grpsty = '{group size = 3 by 2, horizontal sep = 0.3cm, vertical sep = 0.4cm}'
grpplot = Groupplot(width='0.3\\textwidth', group_style=grpsty, parent=fig)
ax0 = Axes('axis', ymin=0, ymax=3, xtick='{5, 10, 15, 20}', xticklabels='{,,}',
           ytick='{0,1,2,3}', ylabel='{$e_{\mathrm{SBI}}$ (\%)}', title='{$\mathrm{Re}=100$}', parent=grpplot)
ax1 = Axes('axis', ymin=0, ymax=3, xtick='{5, 10, 15, 20}', xticklabels='{,,}',
           ytick='{0,1,2,3}', yticklabels='{,,}', title='{$\mathrm{Re}=500$}', parent=grpplot)
ax2 = Axes('axis', ymin=0, ymax=3, xtick='{5, 10, 15, 20}', xticklabels='{,,}',
           ytick='{0,1,2,3}', yticklabels='{,,}', title='{$\mathrm{Re}=1000$}', parent=grpplot)
ax5 = Axes('axis', ymin=0, ymax=70, xtick='{5, 10, 15, 20}', xlabel='{$\kappa$ (\%)}', ylabel='{$e_{\mathrm{MRI}}$ (\%)}', parent=grpplot)
ax6 = Axes('axis', ymin=0, ymax=70, xtick='{5, 10, 15, 20}', xlabel='{$\kappa$ (\%)}', yticklabels='{,,}', parent=grpplot)
ax7 = Axes('axis', ymin=0, ymax=70, xtick='{5, 10, 15, 20}', xlabel='{$\kappa$ (\%)}', yticklabels='{,,}', parent=grpplot)

# Plot data
lsty = [dot, square, triangle, diamond, pentagon]
col = ['black', 'blue', 'red', 'magenta', 'green']
for i in range(1, 5):
    Line(100*pars_cor_err[0,1:5,i,1], err_sbi[0,:,i], col[i-1], 'solid',
         lsty[i-1], parent=ax0, label='line:err_sbi_noise'+str(i))
    Line(100*pars_cor_err[1,1:5,i,1], err_sbi[1,:,i], col[i-1], 'solid',
         lsty[i-1], parent=ax1)
    Line(100*pars_cor_err[2,1:5,i,1], err_sbi[2,:,i], col[i-1], 'solid',
         lsty[i-1], parent=ax2)
    Line(100*pars_cor_err[0,1:5,i,1], err_mri[0,:,i], col[i-1], 'solid',
         lsty[i-1], parent=ax5)
    Line(100*pars_cor_err[1,1:5,i,1], err_mri[1,:,i], col[i-1], 'solid',
         lsty[i-1], parent=ax6)
    Line(100*pars_cor_err[2,1:5,i,1], err_mri[2,:,i], col[i-1], 'solid',
         lsty[i-1], parent=ax7)

# Write Tikz file, corresponding TeX file, compile, and view PDF
fname_prefix='error_fcnof_noise'
write_tex(fig, fname_prefix=fname_prefix, view=True)


## Figure 3: WSS scatter plot ##
sigsc = 10.6

dat3 = np.load('../../simulations/_dat/wss_dist.npz')
wss_d_sbi = sigsc*dat3['F_sbi']
wss_d_mri = sigsc*dat3['F_mri']
wss_d_tru = sigsc*dat3['F_tru']

# Create figure and axes
fig = Figure()
grpsty = '{group size = 3 by 3, horizontal sep = 0.4cm, vertical sep = 0.4cm}'
grpplt = Groupplot('axis equal image', width='0.38\\textwidth', group_style=grpsty,
                   xticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}',
                   yticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}',
                   xmin=-0.02, xmax=0.29, xtick='{0, 0.1, 0.2, 0.27}',
                   ymin=-0.02, ymax=0.29, ytick='{0, 0.1, 0.2, 0.27}',
                   parent=fig)

col = ['blue', 'red', 'green', 'magenta', 'cyan', 'black']
mark = [dot, square, pentagon, triangle]
markoff = [squareoff, pentagonoff, triangleoff, diamondoff]

ax0 = Axes('axis', xticklabels='{,,}', title='{$\kappa=5\%$}', parent=grpplt)
ax1 = Axes('axis', xticklabels='{,,}', yticklabels='{,,}',
           title='{$\kappa=10\%$}', parent=grpplt)
ax2 = Axes('axis', 'ylabel near ticks', yticklabel_pos='right',
           xticklabels='{,,}', yticklabels='{,,}',
           title='{$\kappa=15\%$}', ylabel='{$N=5$ VPD}', parent=grpplt)
ax3 = Axes('axis', xticklabels='{,,}', ylabel='{True WSS (Pa)}', parent=grpplt)
ax4 = Axes('axis', xticklabels='{,,}', yticklabels='{,,}', parent=grpplt)
ax5 = Axes('axis', 'ylabel near ticks', yticklabel_pos='right',
            xticklabels='{,,}', yticklabels='{,,}',
            ylabel='{$N=9$ VPD}', parent=grpplt)
ax6 = Axes('axis', parent=grpplt)
ax7 = Axes('axis', yticklabels='{,,}', xlabel='{Reconstructed WSS (Pa)}', parent=grpplt)
ax8 = Axes('axis', 'ylabel near ticks', yticklabel_pos='right',
           yticklabels='{,,}', ylabel='{$N=17$ VPD}', parent=grpplt)

ax = np.array([[ax0, ax1, ax2],
    [ax3, ax4, ax5],
    [ax6, ax7, ax8]])

wss_true_min = 0
wss_true_max = 0.27
for j in range(3):
    for k in range(3):    
        # Plot data
        Line([wss_true_min, wss_true_max], [wss_true_min, wss_true_max],
             'black', 'solid', 'thick', parent=ax[j][k],
              label='line:wss_dist_exact'+str(j)+str(k))
        Line(wss_d_tru[2,j+1,k+2,::5], wss_d_sbi[2,j+1,k+2,::5], col[1], dotsmall, 'only marks',
             parent=ax[j][k], label='line:wss_dist_sbi'+str(j)+str(k))
        Line(wss_d_tru[2,j+1,k+2,::5], wss_d_mri[2,j+1,k+2,::5], col[0], plus, 'only marks', 
             parent=ax[j][k], label='line:wss_dist_mri'+str(j)+str(k))

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='wss_distribution'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)


## Figure 5: Error vs. CFD ##
cfddat = np.load('../../simulations/_dat/full_run_july2_full.npz')
err_sbi = cfddat['e_sbi']*100
err_mri = cfddat['e_mri']*100
pars_cor_err = cfddat['pars_cor_err']
cfdmesh = [368, 766, 1590]

# Setup figure/axes
fig = Figure()
grpsty = '{group size = 4 by 3, horizontal sep = 0.3cm, vertical sep = 0.4cm}'
grpplot = Groupplot(width='0.3\\textwidth', group_style=grpsty, parent=fig)
ax00 = Axes('axis', ymin=0, ymax=7,xticklabels='{,,}', ylabel='{$e_{\mathrm{SBI}}$ (\%)}', title='{$N=3$ VPD}', parent=grpplot)
ax01 = Axes('axis', ymin=0, ymax=7,xtick='{368, 766, 1590}', xticklabels='{,,}',
           yticklabels='{,,}', title='{$N=5$ VPD}', parent=grpplot)
ax02 = Axes('axis', ymin=0, ymax=7,xtick='{368, 766, 1590}', xticklabels='{,,}',
            yticklabels='{,,}', title='{$N=9$ VPD}', parent=grpplot)
ax03 = Axes('axis', 'ylabel near ticks', yticklabel_pos='right',
        ymin=0, ymax=7, xtick='{368, 766, 1590}', xticklabels='{,,}',
		    yticklabels='{,,}', title='{$N=17$ VPD}', ylabel='{$\mathrm{Re}=100$}',
        parent= grpplot)

ax0 = Axes('axis', ymin=0, ymax=11,xticklabels='{,,}', ylabel='{$e_{\mathrm{SBI}}$ (\%)}', parent=grpplot)
ax1 = Axes('axis', ymin=0, ymax=11,xtick='{368, 766, 1590}', xticklabels='{,,}',
           yticklabels='{,,}', parent=grpplot)
ax2 = Axes('axis', ymin=0, ymax=11,xtick='{368, 766, 1590}', xticklabels='{,,}',
            yticklabels='{,,}', parent=grpplot)
ax3 = Axes('axis', 'ylabel near ticks', yticklabel_pos='right',
        ymin=0, ymax=11, xtick='{368, 766, 1590}', xticklabels='{,,}',
		    yticklabels='{,,}', ylabel='{$\mathrm{Re}=500$}', parent= grpplot)

ax5 = Axes('axis', ymin=0, ymax=17, xtick='{368, 766, 1590}', xlabel='{$N_e$}', ylabel='{$e_{\mathrm{SBI}}$ (\%)}', parent=grpplot)
ax6 = Axes('axis', ymin=0, ymax=17, xtick='{368, 766, 1590}', xlabel='{$N_e$}', yticklabels='{,,}', parent=grpplot)
ax7 = Axes('axis', ymin=0, ymax=17, xtick='{368, 766, 1590}', xlabel='{$N_e$}', yticklabels='{,,}', parent=grpplot)
ax8 = Axes('axis', 'ylabel near ticks', yticklabel_pos='right',
       ymin=0, ymax=17, xtick='{368, 766, 1590}', xlabel='{$N_e$}',
       yticklabels='{,,}', ylabel='{$\mathrm{Re}=1000$}', parent=grpplot)

# Plot data
lsty = [dot, square, triangle, diamond, pentagon]
col = ['black', 'blue', 'red', 'magenta', 'green']
for i in range(4):
    Line(cfdmesh[:], err_sbi[0,i,0,:], col[i], 'solid',
         lsty[i], parent=ax00, label='line:err_sbi_cfd'+str(i))
    Line(cfdmesh[:], err_sbi[0,i,1,:], col[i], 'solid',
         lsty[i], parent=ax01)
    Line(cfdmesh[:], err_sbi[0,i,2,:], col[i], 'solid',
         lsty[i], parent=ax02)
    Line(cfdmesh[:], err_sbi[0,i,3,:], col[i], 'solid', lsty[i], parent=ax03)

    Line(cfdmesh[:], err_sbi[1,i,0,:], col[i], 'solid',
         lsty[i], parent=ax0)
    Line(cfdmesh[:], err_sbi[1,i,1,:], col[i], 'solid',
         lsty[i], parent=ax1)
    Line(cfdmesh[:], err_sbi[1,i,2,:], col[i], 'solid',
         lsty[i], parent=ax2)
    Line(cfdmesh[:], err_sbi[1,i,3,:], col[i], 'solid', lsty[i], parent=ax3)

    Line(cfdmesh[:], err_sbi[2,i,0,:], col[i], 'solid',
         lsty[i], parent=ax5)
    Line(cfdmesh[:], err_sbi[2,i,1,:], col[i], 'solid',
         lsty[i], parent=ax6)
    Line(cfdmesh[:], err_sbi[2,i,2,:], col[i], 'solid',
         lsty[i], parent=ax7)
    Line(cfdmesh[:], err_sbi[2,i,3,:], col[i], 'solid', lsty[i], parent=ax8)

# Write Tikz file, corresponding TeX file, compile, and view PDF
fname_prefix='error_fcnof_cfd'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)


import sys
sys.exit()





## Aorta FIG 1 ## 
dataorta = np.load('../../simulations/_dat/implicit_aorta_run_may26.npz')
dataortamri = np.load('../../simulations/_dat/implicit_run_mrionly_june24.npz')
err_sbi = np.sqrt(dataorta['e_sbi'])*100
err_mri = np.sqrt(dataortamri['e_mri'])*100
pars_cor_err = dataorta['pars_cor_err']


col = ['blue', 'red', 'green', 'magenta', 'cyan', 'black']

fig = Figure()
grpsty = '{group size = 3 by 2, horizontal sep = 0.8cm, vertical sep = 0.8cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)
ax0 = Axes('axis', ylabel='{SBI WSS Error}', width='0.25\\textwidth',parent=grpplot)
ax1 = Axes('axis',width='0.25\\textwidth',parent=grpplot)
ax2 = Axes('axis',width='0.25\\textwidth',parent=grpplot)
ax3 = Axes('axis',ylabel = '{MRI WSS Error}', width='0.25\\textwidth',parent=grpplot)
ax4 = Axes('axis',xlabel='{Reynolds number}',width='0.25\\textwidth',parent=grpplot)
ax5 = Axes('axis',width='0.25\\textwidth',parent=grpplot)

# Plot data
for i in range(4):
    Line(pars_cor_err[:,i,0,0], err_sbi[:,i,0], col[i], 'dashed', pentagon,parent=ax0, label='line:err_aorta_sbi_line0_Re'+str(i))
    Line(pars_cor_err[:,i,1,0], err_sbi[:,i,1], col[i], 'dashed', square, parent=ax1, label='line:err_aorta_sbi_line1_Re'+str(i))
    Line(pars_cor_err[:,i,2,0], err_sbi[:,i,2], col[i], 'dashed', triangle, parent=ax2, label='line:err_aorta_sbi_line2_Re'+str(i))
    Line(pars_cor_err[:,i,0,0], err_mri[:,i,0], col[i], pentagonoff, parent=ax3, label='line:err_aorta_mri_line0_Re'+str(i))
    Line(pars_cor_err[:,i,1,0], err_mri[:,i,1], col[i], squareoff, parent=ax4, label='line:err_aorta_mri_line1_Re'+str(i))
    Line(pars_cor_err[:,i,2,0], err_mri[:,i,2], col[i], triangleoff, parent=ax5, label='line:err_aorta_mri_line2_Re'+str(i))

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='error_aorta_fcnof_Re'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Aorta Figure 1.2

# Create figure and axes
fig = Figure()
grpsty = '{group size = 3 by 2, horizontal sep = 0.8cm, vertical sep = 0.8cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)
ax0 = Axes('axis', ylabel='{SBI WSS Error}', width='0.3\\textwidth',
          parent=grpplot)
ax1 = Axes('axis',  width='0.3\\textwidth', parent=grpplot)
ax2 = Axes('axis', width='0.3\\textwidth', parent=grpplot)
ax3 = Axes('axis', ylabel='{MRI WSS Error}',width='0.3\\textwidth',
          parent=grpplot)
ax4 = Axes('axis',xlabel='{Noise}',  width='0.3\\textwidth', parent=grpplot)
ax5 = Axes('axis', width='0.3\\textwidth', parent=grpplot)
# Plot data
for i in range(3):
    Line(pars_cor_err[0,:,i,1], err_sbi[0,:,i], col[i], 'dashed', pentagon,
         parent=ax0, label='line:err_aorta_sbi_line0_noise'+str(i))
    Line(pars_cor_err[1,:,i,1], err_sbi[1,:,i], col[i], 'dashed', square, parent=ax1, label='line:err_aorta_sbi_line1_noise'+str(i))
    Line(pars_cor_err[2,:,i,1], err_sbi[2,:,i], col[i], 'dashed', triangle, parent=ax2, label='line:err_aorta_sbi_line2_noise'+str(i))
    Line(pars_cor_err[0,:,i,1], err_mri[0,:,i], col[i], 'dashed', pentagonoff,
         parent=ax3, label='line:err_aorta_mri_line0_noise'+str(i))
    Line(pars_cor_err[1,:,i,1], err_mri[1,:,i], col[i], 'dashed', squareoff, parent=ax4, label='line:err_aorta_mri_line1_noise'+str(i))
    Line(pars_cor_err[2,:,i,1], err_mri[2,:,i], col[i], 'dashed', triangleoff, parent=ax5, label='line:err_aorta_mri_line2_noise'+str(i))
# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='error_aorta_fcnof_noise'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Aorta Figure 1.3 ##
fig = Figure()
grpsty = '{group size = 4 by 2, horizontal sep = 0.8cm, vertical sep = 0.8cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)
ax0 = Axes('axis', ylabel='{SBI WSS Error}', width='0.25\\textwidth',parent=grpplot)
ax1 = Axes('axis',width='0.25\\textwidth',parent=grpplot)
ax2 = Axes('axis',width='0.25\\textwidth',parent=grpplot)
ax3 = Axes('axis',width='0.25\\textwidth',parent=grpplot)
ax4 = Axes('axis',ylabel='{MRI WSS Error}',width='0.25\\textwidth',parent=grpplot)
ax5 = Axes('axis',width='0.25\\textwidth',parent=grpplot)
ax6 = Axes('axis',xlabel='{Voxels per diameter}', width='0.25\\textwidth', parent=grpplot)
ax7 = Axes('axis',  width='0.25\\textwidth', parent=grpplot)

# Plot data
for i in range(3):
    Line(pars_cor_err[i,0,:,2], err_sbi[i,0,:], col[i], 'dashed', pentagon,parent=ax0, label='line:err_aorta_sbi_line0_vpd'+str(i))
    Line(pars_cor_err[i,1,:,2], err_sbi[i,1,:], col[i], 'dashed', square, parent=ax1, label='line:err_aorta_sbi_line1_vpd'+str(i))
    Line(pars_cor_err[i,2,:,2], err_sbi[i,2,:], col[i], 'dashed', triangle, parent=ax2, label='line:err_aorta_sbi_line2_vpd'+str(i))
    Line(pars_cor_err[i,3,:,2], err_sbi[i,3,:], col[i], 'dashed', dot, parent=ax3, label='line:err_aorta_sbi_line3_vpd'+str(i))
    Line(pars_cor_err[i,0,:,2], err_mri[i,0,:], col[i], pentagonoff, parent=ax4, label='line:err_aorta_mri_line0_vpd'+str(i))
    Line(pars_cor_err[i,1,:,2], err_mri[i,1,:], col[i], squareoff, parent=ax5, label='line:err_aorta_mri_line1_vpd'+str(i))
    Line(pars_cor_err[i,2,:,2], err_mri[i,2,:], col[i], triangleoff, parent=ax6, label='line:err_aorta_mri_line2_vpd'+str(i))
    Line(pars_cor_err[i,3,:,2], err_mri[i,3,:], col[i], dotoff,parent=ax7, label='line:err_aorta_mri_line3_vpd'+str(i))

# Write Tikz file, corresponding TeX file, compile, and view PDF
fname_prefix='error_aorta_fcnof_vpd'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)


## FIG 3 ##

fig = Figure()


ax = Axes('axis', 'axis equal image', xtick='{0, 0.065, 0.13}', ytick='{-0.079, 0.0185, 0.116}', xmin=1e-5, xmax=0.13, ymin=-0.079, ymax=0.116, parent=fig)

Graphics('_img/aorta_mesh.png', [1e-5, 0.13], [-0.079, 0.116], parent=ax)

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='aorta_msh_textry'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Fig 4 ##
fig = Figure()
grpsty = '{group size = 1 by 3, horizontal sep = 0.4cm, vertical sep = 0.4cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)
ax0 = Axes('axis', 'axis equal image', xticklabels='{,,}', ytick='{-0.05,0,0.05}', xmin=0, xmax=1, ymin=-0.05, ymax=0.05, parent=grpplot)
ax1 = Axes('axis', 'axis equal image', xticklabels='{,,}', ytick='{-0.05,0,0.05}', xmin=0, xmax=1, ymin=-0.05, ymax=0.05, parent=grpplot)
ax2 = Axes('axis', 'axis equal image', xtick='{0,0.5,1}',  ytick='{-0.05,0,0.05}', xmin=0, xmax=1, ymin=-0.05, ymax=0.05, parent=grpplot)

Graphics('_img/sten_msh1.png', [0, 1], [-0.05, 0.05], parent=ax0)
Graphics('_img/sten_msh2.png', [0, 1], [-0.05, 0.05], parent=ax1)
Graphics('_img/sten_msh3.png', [0, 1], [-0.05, 0.05], parent=ax2)

fname_prefix='sten_msh_configs'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Fig 5 ## 
fig = Figure()
grpsty = '{group size = 2 by 2, horizontal sep = 0.4cm, vertical sep = 0.4cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)
ax0 = Axes('axis', 'axis equal image', xticklabels='{,,}', ytick='{-0.05,0,0.05}', xmin=0, xmax=1, ymin=-0.09, ymax=0.09, parent=grpplot)
ax1 = Axes('axis', 'axis equal image', xticklabels='{,,}', yticklabels='{,,}', xmin=0, xmax=1, ymin=-0.09, ymax=0.09, parent=grpplot)
ax2 = Axes('axis', 'axis equal image', xtick='{0,0.5,1}', ytick='{-0.05,0,0.05}', xmin=0, xmax=1, ymin=-0.09, ymax=0.09, parent=grpplot)
ax3 = Axes('axis', 'axis equal image', xtick='{0,0.5,1}', yticklabels='{,,}', xmin=0, xmax=1, ymin=-0.09, ymax=0.09, parent=grpplot)

Graphics('_img/true_sten_mesh.png', [0, 1], [-0.09, 0.09], parent=ax0)
Graphics('_img/sten_vox_msh.png', [0, 1], [-0.09, 0.09], parent=ax1)
Graphics('_img/true_sten.png', [0, 1], [-0.09, 0.09], parent=ax2)
Graphics('_img/vox_on_true.png', [0, 1], [-0.09, 0.09], parent=ax3)

fname_prefix='true_vox_on_true'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Fig 6 ##
fig = Figure()
grpsty = '{group size = 2 by 1, horizontal sep = 0.7cm, vertical sep = 0.4cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)
ax0 = Axes('axis', 'axis equal image', xtick='{0.34, 0.5, 0.67}', ytick='{-0.05, 0, 0.05}', xmin=0.34, xmax=0.67, ymin=-0.09, ymax=0.09, parent=grpplot)
ax1 = Axes('axis', 'axis equal image', xtick='{0.34,0.5,0.67}', yticklabels='{,,}', xmin=0.34, xmax=0.67, ymin=-0.09, ymax=0.09, parent=grpplot)

Graphics('_img/vox_dat_0noise.png', [0.34, 0.67], [-0.09, 0.09], parent=ax0)
Graphics('_img/vox_dat_10noise.png', [0.34, 0.67], [-0.09, 0.09], parent=ax1)

fname_prefix='vox_dat_noise'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Fig 7 ##
fig = Figure()
grpsty = '{group size = 2 by 2, horizontal sep = 0.7cm, vertical sep = 0.4cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)
ax0 = Axes('axis', 'axis equal image', xticklabels='{,,}', ytick='{-0.079, 0.0185, 0.116}', xmin=0, xmax=0.13, ymin=-0.079, ymax=0.116, parent=grpplot)
ax1 = Axes('axis', 'axis equal image', xticklabels='{,,}', yticklabels='{,,}', xmin=0, xmax=0.13, ymin=-0.079,ymax=0.116, parent=grpplot)
ax2 = Axes('axis', 'axis equal image', xtick='{0,0.065,0.13}', ytick='{-0.079,0.0185,0.116}', xmin=0, xmax=0.13, ymin=-0.079, ymax=0.116, parent=grpplot)
ax3 = Axes('axis', 'axis equal image', xtick='{0,0.065,0.13}', yticklabels='{,,}', xmin=0, xmax=0.13, ymin=-0.079, ymax=0.116, parent=grpplot)

Graphics('_img/aorta_mesh.png', [0, 0.13], [-0.079, 0.116], parent=ax0)
Graphics('_img/true_flow_aorta500Re.png', [0, 0.13], [-0.079, 0.116], parent=ax1)
Graphics('_img/aorta_vox_0noise10vpd.png', [0, 0.13], [-0.079, 0.116], parent=ax2)
Graphics('_img/aorta_vox_20noise10vpd.png', [0, 0.13], [-0.079, 0.116], parent=ax3)

fname_prefix='aorta_vox_dat_noise'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Fig 8 ## 
fig = Figure()
grpsty = '{group size = 2 by 1, horizontal sep = 0.7cm, vertical sep = 0.4cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)

ax1 = Axes('axis', xtick='{0.3, 0.4, 0.5}', ytick='{-0.05, -0.025, 0, 0.025, 0.05}', xmin=0.3, xmax=0.55, ymin=-0.05, ymax=0.05, parent=grpplot)
ax2 = Axes('axis', xmin=0, xmax=1, ymax=0.0253, ymin = 0, parent=grpplot) 
Graphics('_img/velocity_profile_Re1000_noise20_vpd_4.png', [0.3, 0.522], [-0.05,0.05], parent=ax1)
Graphics('_img/wss_dist_Re1000_noise20_vpd4', [0, 1], [0, 0.0253], parent=ax2)

fname_prefix='velocity_profile_Re1000_noise20_vpd_4'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Fig 9 ## 
fig = Figure()
grpsty = '{group size = 2 by 1, horizontal sep =0.7cm, vertical sep = 0.4cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)

ax1 = Axes('axis', 'axis equal image', xtick = '{0, 0.065, 0.13}', ytick='{-0.079, 0.0185, 0.116}', xmin=0, xmax=0.13, ymin=-0.079, ymax=0.116, parent=grpplot)
ax2 = Axes('axis', 'axis equal image', xtick = '{0, 0.065, 0.13}', yticklabels='{,,}', xmin=0, xmax=0.13, ymin=-0.079, ymax=0.116, parent=grpplot)

Graphics('_img/aorta_true_flow_Re1000_noise20_vpd3.png', [0,0.13], [-0.079, 0.116], parent=ax1)
Graphics('_img/aorta_sbi_flow_Re1000_noise20_vpd3.png', [0,0.13], [-0.079, 0.116], parent=ax2)

fname_prefix='true_and_recon_aorta_flow'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Fig 10 ## CFD profiles 
fig = Figure()

ax = Axes('axis', xmin=0, xmax=1, ymin=0, ymax=0.0253, parent=fig)

Graphics('_img/cfd_trials_wss_profile_Re500_noise20_vpd5.png', [0,1], [0, 0.0253], parent=ax)

fname_prefix='cfd_trials_wss_profile'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Fig 11 ## Aorta WSS profile

fig = Figure()

ax = Axes('axis', xmin=0, xmax=1, ymin=0, ymax=0.0253, parent=fig)

Graphics('_img/aorta_wss_dist_Re1000_noise20_vpd3.png', [0,1], [0, 0.0253], parent=ax)

fname_prefix='aorta_wss_dist'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)


import sys
sys.exit()

# Below here is just example

##### Figure 1: History ####
fig = Figure()
grpsty = '{group size = 3 by 3, horizontal sep = 1.4cm, vertical sep = 0.4cm}'
grpplt = Groupplot(group_style=grpsty, parent=fig)
 
for p in [1, 2, 3]:

    ## Load data
    s = 'nel6p{0:d}q{0:d}'.format(p)
    dat0 = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy0_'+s+'_hist0.npz')
    dat1 = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy0_'+s+'_hist1.npz')
    N = dat0['R0_nrm'].shape[1]

    # Plot KKT residuals
    ax1 = Axes('axis', xtick='{0,50,100}',
               xmin=-5, xmax=105, ymin=6e-8, ymax=2e5,
               ymode='log', width='0.33\\textwidth', parent=grpplt)
    if p>1: ax1.set_properties(ymin=1e-10)
    if p==2: ax1.set_properties(ymax=2e3)
    if p==3: ax1.set_properties(xlabel='{Iteration ($k$)}')
    if p<3: ax1.set_properties(xticklabels='{,,}')
    Line(range(N), dat0['R0_nrm'][0, :], 'black', 'thick', dot,
         mark_repeat=10, parent=ax1, label='line:R0')
    Line(range(N), dat1['dLdY_nrm'][0, :]/dat1['dLdY_nrm'][0, 0], 'red',
         'thick', triangle, mark_repeat=10, parent=ax1, label='line:dLdY')

    # Plot objective residuals
    ax2 = Axes('axis', xtick='{0,50,100}',
               xmin=-5, xmax=105, ymin=6e-4, ymax=2,
               ymode='log', width='0.33\\textwidth', parent=grpplt)
               #title='{$p='+str(p)+'$}', parent=grpplt)
    if p==1: ax2.set_properties(ymin=6e-2, ymax=2)
    if p==3: ax2.set_properties(xlabel='{Iteration ($k$)}')
    if p<3: ax2.set_properties(xticklabels='{,,}')
    Line(range(N), dat0['R1err_nrm'][0, :], 'blue', 'thick', square,
         mark_repeat=10, parent=ax2, label='line:R1err')
    Line(range(N), dat0['R1msh_nrm'][0, :], 'magenta', 'thick', pentagon,
         mark_repeat=10, parent=ax2, label='line:R1msh')

    # Plot numerical parameters
    ax3 = Axes('axis', xtick='{0,50,100}',
               xmin=-5, xmax=105,
               ymode='log', width='0.33\\textwidth', parent=grpplt)
    if p==3: ax3.set_properties(xlabel='{Iteration ($k$)}')
    if p<3: ax3.set_properties(xticklabels='{,,}')
    Line(range(N), dat1['alpha'][0, :], 'black', 'solid',
         parent=ax3, label='line:alpha')
    Line(range(N), dat1['lam'][0, :], 'blue', 'dashed',
         parent=ax3, label='line:lam')
    Line(range(N), dat1['kappa0'][0, :], 'red', 'dash dot',
         parent=ax3, label='line:kappa')
    
# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_nrl0_hist'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

##### Figure 2: Slice at t=0.8 and shock surface ####

# Create figure and axes
fig = Figure()
grpsty = '{group size = 2 by 1, horizontal sep = 1.8cm}'
grpplt = Groupplot(group_style=grpsty, parent=fig)

ax0 = Axes('axis', 'axis equal image',
           width='0.45\\textwidth',
           xlabel='{$z$}', ylabel='{$t$}',
           xtick = '{0.0, 0.5, 0.8, 1.0}',
           ytick = '{0.0, 0.6, 1.2}',
           xmin=-0.2, xmax=1, ymin=0, ymax=1.2, parent=grpplt)
ax1 = Axes('axis', width='0.45\\textwidth',
           xlabel='{$t$}', ylabel='{$\phi(0.8,t)$}',
           xmin=0, xmax=1.2, ymin=-1, ymax=4.3, parent=grpplt)
#ax2 = Axes('axis', width='0.35\\textwidth',
#           xlabel='{$z_\mathrm{s}(t)$}', ylabel='{$t$}',
#           xmin=0, xmax=1, ymin=0, ymax=0.7, parent=grpplt)

# Plot space-time exact solution
Graphics('_img/iburg1v1d_sptm_nrl0_stdy0_nel6p4q4_final_nomsh.png',
         [-0.2, 1], [0, 1.2], parent=ax0)
Line([0.8, 0.8], [0, 1.2], 'solid', 'gray', 'dashed',
     parent=ax0, label='line:iburg-acc:slice')

ts = 0.4
zs = (1+4.0/3.0)*(1-np.sqrt(1+3*ts))+4*ts
Draw([-0.2, zs], [ts, ts], [], '->', '>=latex', cs='axis cs', parent=ax0)
Node('$z_\mathrm{s}(t)$', [0.5*(-0.2+zs), ts], 'axis cs', 'above', parent=ax0)

# Plot exact solution
tstar = 0.584777015771760
t1, t2 = np.linspace(0, tstar, 250), np.linspace(tstar, 1.2, 250)
U1, U2 = -3*0.2/(1+3*t1), 4 + 0*t2
Line(t1, U1, 'black', 'thick', parent=ax1)
Line(t2, U2, 'black', 'thick', parent=ax1)

t = np.linspace(0, 1.2, 500)
xs = (4.0/3.0+1)*(1-np.sqrt(1+3*t))+4*t;
idx = np.where(xs<=1.0)[0]
Line(xs[idx], t[idx], 'black', 'thick', parent=ax0,
     label='line:iburg-acc:exact')

# Plot numerical solutions
pltsty = [['cyan', 'dotted', 'thick'],
          ['red', 'dashed', 'thick'],
          ['yellow', 'dotted', 'thick']]

for p in [1, 2]: # [1, 2, 3]:

    # Load data
    s = 'nel6p{0:d}q{0:d}'.format(p)
    dat_slc = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy0_'+s+'_slice.npz')
    dat_shk = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy0_'+s+'_shock.npz')

    # Plot solution
    xlst, Ulst = format_coord_soln_elemwise(dat_slc['xsl'], dat_slc['Usl'],
                                            dat_slc['which_elem'], True)
    for k in range(len(xlst)):
        Line(xlst[k][1, :], Ulst[k][0, :], *pltsty[p-1], parent=ax1,
             label='line:iburg-acc:p'+str(p))

    # Plot shock
    xlst, Ulst = format_coord_soln_elemwise(dat_shk['xsl'], dat_shk['Usl'],
                                            dat_shk['which_elem'], True)
    for k in range(len(xlst)):
        Line(xlst[k][0, :], Ulst[k][0, :], *pltsty[p-1], parent=ax0)

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_nrl0_slice_shock'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)


##### Figure 3, Table 1: h-convergence ####

# Create figure and axes
fig = Figure()
grpsty = '{group size = 2 by 1, horizontal sep = 2.4cm}'
grpplt = Groupplot(group_style=grpsty, parent=fig)

ax1 = Axes('axis', width='0.42\\textwidth', height='0.325\\textwidth',
           xmode='log', ymode='log', xlabel='{$h$}', ylabel='{$E_\phi$}',
           xmin=0.01, xmax=0.2, ymin=1e-8, ymax=1e-1, parent=grpplt)
ax2 = Axes('axis', width='0.42\\textwidth', height='0.325\\textwidth',
           xmode='log', ymode='log', xlabel='{$h$}', ylabel='{$E_{z_\mathrm{s}}$}',
           xmin=0.01, xmax=0.2, ymin=1e-11, ymax=1e-2, parent=grpplt)
pltsty = [['black',  dot], ['blue', square],
          ['red', triangle], ['magenta', pentagon]]

# Setup data
h = np.zeros((4, 4))
nelem = np.zeros((4, 4))
err_soln = np.zeros((4, 4))
err_shk = np.zeros((4, 4))
for p in [1, 2, 3, 4]:
    dat = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy1_p{0:d}q{0:d}.npz'.format(p))
    h[:, p-1] = dat['h'][0, :]
    nelem[:, p-1] = dat['nelem'][0, :]
    err_soln[:, p-1] = dat['err_soln'][0, :]
    err_shk[:, p-1] = dat['err_shk'][0, :]

# Plot h convergence lines
for p in [1, 2, 3]:

    hpos = h[h[:, p-1]>0, p-1]
    hmin, hmax = 0.5*np.min(hpos), 2*np.max(hpos)

    # Solution error
    Line(h[:, p-1], err_soln[:, p-1], 'solid', 'thick', 
         *pltsty[p-1], parent=ax1, label='line:iburg:hconv:p'+str(p))
    b = np.log(err_soln[-2,p-1])-(p+1)*np.log(h[-2,p-1])
    y1, y2 = np.exp(b+(p+1)*np.log(hmin)), np.exp(b+(p+1)*np.log(hmax))
    Line([hmin, hmax], [y1, y2], 'dashed', pltsty[p-1][0], parent=ax1)

    # Shock error
    Line(h[:, p-1], err_shk[:, p-1], 'solid', 'thick',
         *pltsty[p-1], parent=ax2)
    b = np.log(err_shk[-2,p-1])-(p+1)*np.log(h[-2,p-1])
    y1, y2 = np.exp(b+(p+1)*np.log(hmin)), np.exp(b+(p+1)*np.log(hmax))
    Line([hmin, hmax], [y1, y2], 'dashed', pltsty[p-1][0], parent=ax2)

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_nrl0_hconv'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

# Create h convergence table
for p in [1, 2, 3]:
    f = open('iburg1v1d_sptm_nrl0_hconv_p'+str(p)+'.tab', 'w')
    E = np.vstack((err_soln[:, p-1][None, :], err_shk[:, p-1][None, :]))
    s = create_hconv_tab_sec(p, p, h[:, p-1], nelem[:, p-1], E)
    f.write(s)
    f.close()

##### Figure 4: No reinitialization demo ####

# Create figure and axes
fig = Figure()
grpsty = '{group size = 2 by 1, horizontal sep = 2cm, vertical sep = 1.5cm}'
grpplt = Groupplot(group_style=grpsty, parent=fig)

ax1 = Axes('axis', 'axis equal image',
           xmin=-0.2, xmax=1, ymin=0, ymax=1.2,
           xticklabels='{,,}', yticklabels='{,,}',
           width='0.45\\textwidth', parent=grpplt)
 
ax2 = Axes('axis', xtick='{0,50,100}',
           xlabel='{Iteration ($k$)}',
           xmin=-5, xmax=105, ymode='log',
           width='0.45\\textwidth', parent=grpplt)

## Plot 1: Image
Graphics('_img/iburg1v1d_sptm_nrl0_stdy0_nel6p3q3_noreinit_it040_msh.png',
         [-0.2, 1], [0, 1.2], parent=ax1)

## Plot 2: Convergence history

# Load data
s = 'nel6p{0:d}q{0:d}'.format(p)
dat0 = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy0_nel6p3q3_noreinit_hist0.npz')
dat1 = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy0_nel6p3q3_noreinit_hist1.npz')
N = dat0['R0_nrm'].shape[1]

# Plot residuals
Line(range(N), dat0['R0_nrm'][0, :], 'black', 'thick', dot,
     mark_repeat=10, parent=ax2)
Line(range(N), dat1['dLdY_nrm'][0, :]/dat1['dLdY_nrm'][0, 0], 'red',
     'thick', triangle, mark_repeat=10, parent=ax2)
Line(range(N), dat0['R1err_nrm'][0, :], 'blue', 'thick', square,
     mark_repeat=10, parent=ax2, label='line:R1err')

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_nrl0_noreinit'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

################################## SHKFORM #####################################

##### Figure 1: History ####
fig = Figure()
grpsty = '{group size = 3 by 2, horizontal sep = 1.4cm, vertical sep = 0.4cm}'
grpplt = Groupplot(group_style=grpsty, parent=fig)
 
for p in [2, 3]:

    ## Load data
    s = 'nel20p{0:d}q{0:d}'.format(p)
    dat0 = np.load('../simulations/_dat/iburg1v1d_sptm_shkform_'+s+'_hist0.npz')
    dat1 = np.load('../simulations/_dat/iburg1v1d_sptm_shkform_'+s+'_hist1.npz')
    N = dat0['R0_nrm'].shape[1]
    if p == 3: N = N-6

    # Plot KKT residuals
    ax1 = Axes('axis', xtick='{0,50,100}',
               xmin=-5, xmax=105, ymin=6e-9, ymax=2e2,
               ymode='log', width='0.33\\textwidth', parent=grpplt)
    if p<3: ax1.set_properties(xticklabels='{,,}')
    if p==3: ax1.set_properties(xlabel='{Iteration ($k$)}')
    Line(range(N), dat0['R0_nrm'][0, :N], 'black', 'thick', dot,
         mark_repeat=10, parent=ax1, label='line:R0')
    Line(range(N), dat1['dLdY_nrm'][0, :N]/dat1['dLdY_nrm'][0, 0], 'red',
         'thick', triangle, mark_repeat=10, parent=ax1, label='line:dLdY')

    # Plot objective residuals
    ax2 = Axes('axis', xtick='{0,50,100}',
               xmin=-5, xmax=105, ymin=6e-5, ymax=0.2,
               ymode='log', width='0.33\\textwidth', parent=grpplt)
    if p<3: ax2.set_properties(xticklabels='{,,}')
    if p==2: ax2.set_properties(ymin=6e-4)
    if p==3: ax2.set_properties(xlabel='{Iteration ($k$)}')
    Line(range(N), dat0['R1err_nrm'][0, :N], 'blue', 'thick', square,
         mark_repeat=10, parent=ax2, label='line:R1err')
    Line(range(N), dat0['R1msh_nrm'][0, :N], 'magenta', 'thick', pentagon,
         mark_repeat=10, parent=ax2, label='line:R1msh')

    # Plot numerical parameters
    ax3 = Axes('axis', xtick='{0,50,100}', xmin=-5, xmax=105,
               ymode='log', width='0.33\\textwidth', parent=grpplt)
    if p<3: ax3.set_properties(xticklabels='{,,}')
    if p==3: ax3.set_properties(ymin=6e-6)
    if p==3: ax3.set_properties(xlabel='{Iteration ($k$)}')
    Line(range(N), dat1['alpha'][0, :N], 'black', 'solid',
         parent=ax3, label='line:alpha')
    Line(range(N), dat1['lam'][0, :N], 'blue', 'dashed',
         parent=ax3, label='line:lam')
    Line(range(N), dat1['kappa0'][0, :N], 'red', 'dash dot',
         parent=ax3, label='line:kappa')

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_shkform_hist'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

##### Figure 2: Slices ####

# Create figure and axes
fig = Figure()
#grpsty = '{group size = 3 by 4, horizontal sep = 0.4cm, vertical sep = 0.4cm}'
grpsty = '{group size = 4 by 2, horizontal sep = 0.4cm, vertical sep = 0.4cm}'
grpplt = Groupplot(group_style=grpsty, parent=fig)

#for k in [0, 4, 8, 1, 5, 9, 2, 6, 10, 3, 7, 11]:
for k in [0, 2, 3, 4, 5, 6, 9, 10]:

    # Create axis
    ax_ = Axes('axis', width='0.3\\textwidth',
               xmin=-1, xmax=1, ymin=-1.2, ymax=1.4, parent=grpplt)
    if k in [5, 6, 9, 10]:
        ax_.set_properties(xtick='{-1,0,1}', xlabel='{$z$}')
        if k in [6, 9, 10]:
            ax_.set_properties(yticklabels='{,,}')
    if k in [0, 5]:
        ax_.set_properties(ytick='{-1, 0, 1.2}',
                           ylabel='{$\phi(z,\\bar{t})$}')
        if k == 0:
            ax_.set_properties(xticklabels='{,,}')
    if k not in [0, 5, 6, 9, 10]:
        ax_.set_properties(xticklabels='{,,}', yticklabels='{,,}')
 
    # Load data
    dat_slc = np.load('../simulations/_dat/iburg1v1d_sptm_shkform_nel20p3q3_slice'+str(k+1).zfill(2)+'.npz')
    
    # Plot solution
    xlst, Ulst = format_coord_soln_elemwise(dat_slc['xsl'], dat_slc['Usl'],
                                            dat_slc['which_elem'], True)
    for j in range(len(xlst)):
        Line(xlst[j][0, :], Ulst[j][0, :],
             'black', 'solid', 'thick', parent=ax_)

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_shkform_shock'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

##### Figure 3: Slices (for animation) ####

# Create figure and axes
fig = Figure()
ax = Axes('axis', width='0.3\\textwidth',
          xmin=-1, xmax=1, ymin=-1.2, ymax=1.4,
          xtick='{-1,0,1}', ytick='{-1,0,1.2}', parent=fig)

for k in range(11):

    # Load data
    dat_slc = np.load('../simulations/_dat/iburg1v1d_sptm_shkform_nel20p3q3_slice'+str(k+1).zfill(2)+'.npz')
    
    # Plot solution
    xlst, Ulst = format_coord_soln_elemwise(dat_slc['xsl'], dat_slc['Usl'],
                                            dat_slc['which_elem'], True)
    for j in range(len(xlst)):
        Line(xlst[j][0, :], Ulst[j][0, :],
             'black', 'solid', 'thick', parent=ax, over=str(k+1))

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_shkform_sliceanim'
#write_tex(fig, fname_prefix=fname_prefix, view=False)
#cleanup_compile(fname_prefix)


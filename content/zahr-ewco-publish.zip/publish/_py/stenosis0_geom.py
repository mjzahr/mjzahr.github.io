import numpy as np

from pytikz.pltobj import Figure, Axes, Line, Node
from pytikz.predef import dot, RgbColor
from pytikz.sys_core import write_tex, cleanup_compile

xsc=6 # scale and multiply by 100 to put into cm
A, R0, sig, mu = 0.005*xsc*xsc, 0.05*xsc, 0.1*xsc, 0.5*xsc
print A, R0, sig, mu

import sys
sys.exit()

def yfcn(x):
    return R0-(A/np.sqrt(2*np.pi*sig**2))*np.exp(-0.5*((x-mu)/sig)**2)

# MRI box
xmin, xmax = 0.3*xsc, 0.7*xsc
ymin, ymax = -0.1*xsc, 0.1*xsc

# Create figure and axes
fig = Figure()
ax  = Axes('axis', 'axis equal image',
           'axis x line*=bottom', 'axis y line*=left',
           width='0.62\\textwidth',
           xmin=-0.05*xsc, xmax=1.05*xsc, ymin=-0.125*xsc, ymax=0.125*xsc,
           xtick='{0, '+', '.join([str(a) for a in [xmin, 0.5*xsc, xmax, 1*xsc]])+'}',
           ytick='{'+', '.join([str(a) for a in [ymin, -0.05*xsc, 0.05*xsc, ymax]])+'}',
           yticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}',
           parent=fig)

# Plot domain, boundaries
x0 = np.linspace(0, 1*xsc, 1000)
x = np.concatenate((x0, x0[::-1]))
y = np.concatenate((-yfcn(x0), yfcn(x0[::-1])))
Line(x, y, 'black', 'solid',
     fill='lightgray', opacity=0.6, parent=ax)
Line(x0, yfcn(x0), 'black', 'solid', 'thick', parent=ax,
     label='line:stenosis0-wall')
Line(x0, -yfcn(x0), 'black', 'solid', 'thick', parent=ax)
Line([0, 0], [-R0, R0], 'blue', 'solid', 'thick', parent=ax,
     label='line:stenosis0-inflow')
Line([1*xsc, 1*xsc], [-R0, R0], 'red', 'solid', 'thick', parent=ax,
     label='line:stenosis0-outflow')

# Plot MRI boundary
Line([xmin, xmax, xmax, xmin, xmin], [ymin, ymin, ymax, ymax, ymin],
     'magenta', 'dashed', 'thick',
     parent=ax, label='line:stenosis0-mribox')

# Write files, compile, and view
write_tex(fig, fname_prefix='stenosis0_geom', view=True)
cleanup_compile('stenosis0_geom')

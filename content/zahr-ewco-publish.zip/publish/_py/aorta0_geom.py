import numpy as np

from pytikz.pltobj import Figure, Axes, Line, Graphics
from pytikz.sys_core import write_tex, cleanup_compile
from pytikz.style import Linestyle

# TODO: Run from base directory, not _py

# Create figure, axes
fig = Figure()
ax = Axes('axis', 'axis equal image',
          'axis x line*=bottom', 'axis y line*=left',
          width='0.65\\textwidth',
          xmin=-0.87, xmax=13.35, ymin=-8.78, ymax=12.73,
          xtick='{0, 2.5, 6.6, 10.4, 12.5}',
          ytick='{-7.9, 0, 4.9, 11.6}',
          xticklabel_style='{/pgf/number format/precision=2, /pgf/number format/fixed}',
          yticklabel_style='{/pgf/number format/precision=2, /pgf/number format/fixed}',
          parent=fig)

# Plot image and MRI box
Graphics('_img/aorta0_geom.png', [-0.31, 12.79], [-8.22, 12.17],
         parent=ax)

xmin, xmax = 0, 13.00
ymin, ymax = -7.90, 11.60
Line([xmin, xmax, xmax, xmin, xmin], [ymin, ymin, ymax, ymax, ymin],
     'magenta', 'dashed', 'thick', parent=ax)

# Write Tikz file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/aorta0_geom'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

import numpy as np
  
from pytikz.pltobj import Figure, Groupplot, Axes, Line, Graphics, Draw, Node
from pytikz.sys_core import write_tex, cleanup_compile
from pytikz.style import Linestyle

## Stenosis: mesh, CFD, MRI

# Create mesh and axes
fig = Figure()
grpsty = '{group size = 2 by 3, horizontal sep = 0.4cm, vertical sep = 0.8cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig,
                    title_style='{at={(current bounding box.north west)}, anchor=west}')

ax0 = Axes('axis', 'axis equal image',
           title='(a) Reference mesh',
           axis_lines='none', width='0.58\\textwidth',
           xmin=0, xmax=1, ymin=-0.09, ymax=0.09, parent=grpplot)
ax1 = Axes('axis', 'axis equal image',
           title='(b) Reference velocity',
           axis_lines='none', width='0.58\\textwidth',
           xmin=0, xmax=1, ymin=-0.09, ymax=0.09, parent=grpplot)
ax2 = Axes('axis', 'axis equal image',
           title='(c) MR data (no noise)',
           axis_lines='none', width='0.58\\textwidth',
           xmin=0, xmax=1, ymin=-0.09, ymax=0.09, parent=grpplot)
ax3 = Axes('axis', 'axis equal image',
           title='(d) MRI data (noise)',
           axis_lines='none', width='0.58\\textwidth',
           xmin=0, xmax=1, ymin=-0.09, ymax=0.09, parent=grpplot)
ax4 = Axes('axis', 'axis equal image',
           title='(e) SBI reconstructed velocity',
           axis_lines='none', width='0.58\\textwidth',
           xmin=0, xmax=1, ymin=-0.09, ymax=0.09, parent=grpplot)
ax5 = Axes('axis', 'axis equal image',
           title='(f) MR data from SBI',
           axis_lines='none', width='0.58\\textwidth',
           xmin=0, xmax=1, ymin=-0.09, ymax=0.09, parent=grpplot)

# Import PNG
Graphics('_img/true_sten_mesh.png', [0, 1], [-0.05, 0.05], parent=ax0)
Graphics('_img/true_sten_cfd.png', [0, 1], [-0.05, 0.05], parent=ax1)
Graphics('_img/true_sten_cfd_mri_noise0.png', [0, 1], [-0.09, 0.09], parent=ax2)
Graphics('_img/true_sten_cfd_mri_noise20.png', [0, 1], [-0.09, 0.09], parent=ax3)
Graphics('_img/sbi_sten_cfd_noise20_nref2.png', [0, 1], [-0.05, 0.05], parent=ax4)
Graphics('_img/sbi_sten_vox_noise20_nref2.png', [0, 1], [-0.09, 0.09], parent=ax5)

# Write Tikz files, compile TeX
fname_prefix='_py/stenosis_truth_msh_cfd_mri'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Aorta: mesh, CFD, MRI

# Create mesh and axes
fig = Figure()
grpsty = '{group size = 3 by 2, horizontal sep = 0.5cm, vertical sep = 0.6cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig,
                    title_style='{at={(current bounding box.north west)}, anchor=west}')

ax0 = Axes('axis', 'axis equal image',
           title='(a) Reference mesh',
           axis_lines='none', width='0.5\\textwidth',
           xmin=0, xmax=0.13, ymin=-0.079, ymax=0.1186, parent=grpplot)
ax1 = Axes('axis', 'axis equal image',
           title='(b) Reference velocity',
           axis_lines='none', width='0.5\\textwidth',
           xmin=0, xmax=0.13, ymin=-0.079, ymax=0.1186, parent=grpplot)
ax2 = Axes('axis', 'axis equal image',
           title='(c) MR data (no noise)',
           axis_lines='none', width='0.5\\textwidth',
           xmin=0, xmax=0.13, ymin=-0.079, ymax=0.1186, parent=grpplot)
ax3 = Axes('axis', 'axis equal image',
           title='(d) MR data (noise)',
           axis_lines='none', width='0.5\\textwidth',
           xmin=0, xmax=0.13, ymin=-0.079, ymax=0.1186, parent=grpplot)
ax4 = Axes('axis', 'axis equal image',
           title='(e) SBI reconstructed velocity',
           axis_lines='none', width='0.5\\textwidth',
           xmin=0, xmax=0.13, ymin=-0.079, ymax=0.1186, parent=grpplot)
ax5 = Axes('axis', 'axis equal image',
           title='(f) MR data from SBI',
           axis_lines='none', width='0.5\\textwidth',
           xmin=0, xmax=0.13, ymin=-0.079, ymax=0.1186, parent=grpplot)

# Import PNG
Graphics('_img/true_aorta_mesh.png', [0, 0.1248], [-0.079, 0.1186], parent=ax0)
Graphics('_img/true_aorta_cfd.png', [0, 0.1248], [-0.079, 0.1186], parent=ax1)
Graphics('_img/true_aorta_cfd_mri_noise0.png', [0, 0.13], [-0.079, 0.116], parent=ax2)

Graphics('_img/true_aorta_cfd_mri_noise20.png', [0, 0.13], [-0.079, 0.116], parent=ax3)
Graphics('_img/sbi_aorta_cfd_noise20.png', [0, 0.1248], [-0.079, 0.1186], parent=ax4)
Graphics('_img/sbi_aorta_vox_noise20.png', [0, 0.13], [-0.079, 0.116], parent=ax5)

# Write Tikz files, compile TeX
fname_prefix='_py/aorta_truth_msh_cfd_mri'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Stenosis: mesh levels

# Create figure and axes
fig = Figure()
grpsty = '{group size = 2 by 3, horizontal sep = 0.4cm, vertical sep = 0.2cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)

ax = []
for k in range(6):
    ax_ = Axes('axis', 'axis equal image',
               axis_lines='none', width='0.58\\textwidth',
               xmin=0, xmax=1, ymin=-0.05, ymax=0.05, parent=grpplot)
    ax.append(ax_)

# Import PNG
Graphics('_img/true_sten_mesh_nref0.png', [0, 1], [-0.05, 0.05], parent=ax[0])
Graphics('_img/true_sten_cfd_nref0.png', [0, 1], [-0.05, 0.05], parent=ax[1])
Graphics('_img/true_sten_mesh_nref1.png', [0, 1], [-0.05, 0.05], parent=ax[2])
Graphics('_img/true_sten_cfd_nref1.png', [0, 1], [-0.05, 0.05], parent=ax[3])
Graphics('_img/true_sten_mesh_nref2.png', [0, 1], [-0.05, 0.05], parent=ax[4])
Graphics('_img/true_sten_cfd_nref2.png', [0, 1], [-0.05, 0.05], parent=ax[5])

# Write Tikz files, compile TeX
fname_prefix='_py/stenosis_msh_cfd_nrefs'
#write_tex(fig, fname_prefix=fname_prefix, view=True)
#cleanup_compile(fname_prefix)

## WSS 0
xsc = 6.0
sigsc = 10.6

# Load data
dat0 = np.load('_dat/sten_wss_truth.npz')
dat0b = np.load('_dat/sten_wss_sbi_noise20_nref2.npz')
dat1 = np.load('_dat/aorta_wss_truth.npz')
dat1b = np.load('_dat/aorta_wss_sbi_noise20.npz')

def mk_dist(xf):
    dx = xf[:, 1:]-xf[:, :-1]
    s00 = np.sqrt(np.sum((xf[:, 1:]-xf[:, :-1])**2, axis=0))
    return np.concatenate(([0.0], np.cumsum(s00)))

def mk_cont(Fn0):
    Fn = Fn0.copy('F')
    for k in range(Fn.shape[2]-1):
        Fn[:,-1,k] = 0.5*(Fn0[:,-1,k]+Fn0[:,0,k+1])
        Fn[:,0,k+1] = 0.5*(Fn0[:,-1,k]+Fn0[:,0,k+1])
    return Fn

shp0 = dat0['xf'].shape
xf0 = dat0['xf'].reshape((shp0[0], -1), order='F')
s0 = xsc*mk_dist(xf0)
s0 = s0.reshape((shp0[1], shp0[2]), order='F')
Fn0 = sigsc*mk_cont(dat0['Fn'])

shp0b = dat0b['xf'].shape
xf0b = dat0b['xf'].reshape((shp0b[0], -1), order='F')
s0b = xsc*mk_dist(xf0b)
s0b = s0b.reshape((shp0b[1], shp0b[2]), order='F')
Fn0b = sigsc*mk_cont(dat0b['Fn'])
idx0b = np.logical_and(s0b.flatten('F')>=1.8, s0b.flatten('F')<=4.2)

shp1 = dat1['xf'].shape
xf1 = dat1['xf'].reshape((shp1[0], -1), order='F')
s1 = mk_dist(xf1)
s1 = s1.reshape((shp1[1], shp1[2]), order='F')
Fn1 = mk_cont(dat1['Fn'])

shp1b = dat1b['xf'].shape
xf1b = dat1b['xf'].reshape((shp1b[0], -1), order='F')
s1b = mk_dist(xf1b)
s1b = s1b.reshape((shp1b[1], shp1b[2]), order='F')
Fn1b = mk_cont(dat1b['Fn'])

# Create figure and axes
fig = Figure()
grpsty = '{group size = 2 by 1, horizontal sep = 1.2cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)

ax0 = Axes('axis', width='0.5\\textwidth', parent=grpplot, ymax=0.3,
           title='{WSS distribution (vessel)}',
           xlabel='{Distance along wall (cm)}',
           ylabel='{$\sigma^\mathrm{wss}$ (Pa)}',
           xtick='{0, 1.8, 3, 4.2, 6}',
           xticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}',
           yticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}')
ax1 = Axes('axis', width='0.5\\textwidth', parent=grpplot, ymax=0.15,
           title='{WSS distribution (aorta)}',
           xlabel='{Distance along wall (cm)}',
           xticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}',
           yticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}')

# Plot WSS
Line(s0.flatten('F'), Fn0[2, :, :].flatten('F'), 'black', 'thick', 'solid',
     parent=ax0, label='line:wss_truth')
Line(s0b.flatten('F')[idx0b], Fn0b[2, :, :].flatten('F')[idx0b], 'red', 'thick', 'dashed',
     parent=ax0, label='line:wss_sbi')

Line(s1.flatten('F'), Fn1[2, :, :].flatten('F'), 'black', 'thick', 'solid',
     parent=ax1)
Line(s1b.flatten('F'), Fn1b[2, :, :].flatten('F'), 'red', 'thick', 'dashed',
     parent=ax1)

# Write Tikz files, compile TeX
fname_prefix='_py/wss_truth_sbi'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)


## WSS 1

# Load data
dat0 = np.load('_dat/sten_wss_truth.npz')
dat1 = np.load('_dat/sten_wss_sbi_noise20_nref0.npz')
dat2 = np.load('_dat/sten_wss_sbi_noise20_nref1.npz')
dat3 = np.load('_dat/sten_wss_sbi_noise20_nref2.npz')

def mk_dist(xf):
    dx = xf[:, 1:]-xf[:, :-1]
    s00 = np.sqrt(np.sum((xf[:, 1:]-xf[:, :-1])**2, axis=0))
    return np.concatenate(([0.0], np.cumsum(s00)))

def mk_cont(Fn0):
    Fn = Fn0.copy('F')
    for k in range(Fn.shape[2]-1):
        Fn[:,-1,k] = 0.5*(Fn0[:,-1,k]+Fn0[:,0,k+1])
        Fn[:,0,k+1] = 0.5*(Fn0[:,-1,k]+Fn0[:,0,k+1])
    return Fn

shp0 = dat0['xf'].shape
xf0 = dat0['xf'].reshape((shp0[0], -1), order='F')
s0 = xsc*mk_dist(xf0)
s0 = s0.reshape((shp0[1], shp0[2]), order='F')
Fn0 = sigsc*mk_cont(dat0['Fn'])
idx0 = np.logical_and(s0.flatten('F')>=1.8, s0.flatten('F')<=4.2)

shp1 = dat1['xf'].shape
xf1 = dat1['xf'].reshape((shp1[0], -1), order='F')
s1 = xsc*mk_dist(xf1)
s1 = s1.reshape((shp1[1], shp1[2]), order='F')
Fn1 = sigsc*mk_cont(dat1['Fn'])
idx1 = np.logical_and(s1.flatten('F')>=1.8, s1.flatten('F')<=4.2)

shp2 = dat2['xf'].shape
xf2 = dat2['xf'].reshape((shp2[0], -1), order='F')
s2 = xsc*mk_dist(xf2)
s2 = s2.reshape((shp2[1], shp2[2]), order='F')
Fn2 = sigsc*mk_cont(dat2['Fn'])
idx2 = np.logical_and(s2.flatten('F')>=1.8, s2.flatten('F')<=4.2)

shp3 = dat3['xf'].shape
xf3 = dat3['xf'].reshape((shp3[0], -1), order='F')
s3 = xsc*mk_dist(xf3)
s3 = s3.reshape((shp3[1], shp3[2]), order='F')
Fn3 = sigsc*mk_cont(dat3['Fn'])
idx3 = np.logical_and(s3.flatten('F')>=1.8, s3.flatten('F')<=4.2)

# Create figure and axes
fig = Figure()
ax0 = Axes('axis', width='0.5\\textwidth', parent=fig, 
           ymax=0.29, ytick='{0, 0.1, 0.2, 0.27}',
           xtick='{0, 1.8, 3, 4.2, 6}',
           xlabel='{Distance along wall (cm)}',
           ylabel='{$\sigma^\mathrm{wss}$ (Pa)}',
           xticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}',
           yticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}')

# Plot WSS
Line(s0.flatten('F'), Fn0[2, :, :].flatten('F'), 'black', 'thick', 'solid',
     parent=ax0, label='line:wss_truth')
Line(s1.flatten('F')[idx1], Fn1[2, :, :].flatten('F')[idx1], 'red', 'thick', 'dashed',
     parent=ax0, label='line:wss_sbi_nref0')
Line(s2.flatten('F')[idx2], Fn2[2, :, :].flatten('F')[idx2], 'blue', 'thick', 'dotted',
     parent=ax0, label='line:wss_sbi_nref1')
Line(s3.flatten('F')[idx3], Fn3[2, :, :].flatten('F')[idx3], 'magenta', 'thick', 'dash dot',
     parent=ax0, label='line:wss_sbi_nref2')

# Write Tikz files, compile TeX
fname_prefix='_py/wss_truth_sbi_nrefs'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

import sys
sys.exit()

## WSS cfd
dat = np.load('../simulations/_dat/full_run_july2_full.npz')
F = dat['F_sbi']
F1 = dat['F_mri']
F0 = dat['F_tru']

fig = Figure()
ax0 = Axes('axis', width='0.5//textwidth', parent=fig,
            xlabel='Distance along wall (cm)',
            ylabel='{$\sigma^{WSS}$ cPa}',
			xticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}',
			yticklabel_style='{/pgf/number format/precision=3, /pgf/number format/fixed}')

Line(s0.flatten('F'), F0[3,4,3,1], 'black', 'thick', 'solid',
     parent=ax0, label='line:wss_truth')
Line(s0.flatten('F'), F[3,4,3,0], 'red', 'thick', 'dashed',
     parent=ax0, label='line:wss_sbi_nref0')
Line(s0.flatten('F'), F[3,4,3,1], 'blue', 'thick', 'dotted',
     parent=ax0, label='line:wss_sbi_nref1')
Line(s0.flatten('F'), F[3,4,3,2], 'blue', 'thick', 'dotted',
     parent=ax0, label='line:wss_sbi_nref1')

# Write Tikz files, compile TeX
fname_prefix='_py/wss_truth_sbi_nrefs1'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)


## Fig 4 ##
fig = Figure()
grpsty = '{group size = 1 by 3, horizontal sep = 0.4cm, vertical sep = 0.4cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)
ax0 = Axes('axis', 'axis equal image', xticklabels='{,,}', ytick='{-0.05,0,0.05}', xmin=0, xmax=1, ymin=-0.05, ymax=0.05, parent=grpplot)
ax1 = Axes('axis', 'axis equal image', xticklabels='{,,}', ytick='{-0.05,0,0.05}', xmin=0, xmax=1, ymin=-0.05, ymax=0.05, parent=grpplot)
ax2 = Axes('axis', 'axis equal image', xtick='{0,0.5,1}',  ytick='{-0.05,0,0.05}', xmin=0, xmax=1, ymin=-0.05, ymax=0.05, parent=grpplot)

Graphics('_img/sten_msh1.png', [0, 1], [-0.05, 0.05], parent=ax0)
Graphics('_img/sten_msh2.png', [0, 1], [-0.05, 0.05], parent=ax1)
Graphics('_img/sten_msh3.png', [0, 1], [-0.05, 0.05], parent=ax2)

fname_prefix='sten_msh_configs'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Fig 6 ##
fig = Figure()
grpsty = '{group size = 2 by 1, horizontal sep = 0.7cm, vertical sep = 0.4cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)
ax0 = Axes('axis', 'axis equal image', xtick='{0.34, 0.5, 0.67}', ytick='{-0.05, 0, 0.05}', xmin=0.34, xmax=0.67, ymin=-0.05, ymax=0.05, parent=grpplot)
ax1 = Axes('axis', 'axis equal image', xtick='{0.34,0.5,0.67}', yticklabels='{,,}', xmin=0.34, xmax=0.67, ymin=-0.05, ymax=0.05, parent=grpplot)

Graphics('_img/vox_dat_0noise.png', [0.34, 0.67], [-0.05, 0.05], parent=ax0)
Graphics('_img/vox_dat_10noise.png', [0.34, 0.67], [-0.05, 0.05], parent=ax1)

fname_prefix='vox_dat_noise'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Fig 8 ## 
fig = Figure()
grpsty = '{group size = 2 by 1, horizontal sep = 0.7cm, vertical sep = 0.4cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)

ax1 = Axes('axis', xtick='{0.3, 0.4, 0.5}', ytick='{-0.05, -0.025, 0, 0.025, 0.05}', xmin=0.3, xmax=0.55, ymin=-0.05, ymax=0.05, parent=grpplot)
ax2 = Axes('axis', xmin=0, xmax=1, ymax=0.0253, ymin = 0, parent=grpplot) 
Graphics('_img/velocity_profile_Re1000_noise20_vpd_4.png', [0.3, 0.522], [-0.05,0.05], parent=ax1)
Graphics('_img/wss_dist_Re1000_noise20_vpd4', [0, 1], [0, 0.0253], parent=ax2)

fname_prefix='velocity_profile_Re1000_noise20_vpd_4'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Fig 9 ## 
fig = Figure()
grpsty = '{group size = 2 by 1, horizontal sep =0.7cm, vertical sep = 0.4cm}'
grpplot = Groupplot(group_style=grpsty, parent=fig)

ax1 = Axes('axis', 'axis equal image', xtick = '{0, 0.065, 0.13}', ytick='{-0.079, 0.0185, 0.116}', xmin=0, xmax=0.13, ymin=-0.079, ymax=0.116, parent=grpplot)
ax2 = Axes('axis', 'axis equal image', xtick = '{0, 0.065, 0.13}', yticklabels='{,,}', xmin=0, xmax=0.13, ymin=-0.079, ymax=0.116, parent=grpplot)

Graphics('_img/aorta_true_flow_Re1000_noise20_vpd3.png', [0,0.13], [-0.079, 0.116], parent=ax1)
Graphics('_img/aorta_sbi_flow_Re1000_noise20_vpd3.png', [0,0.13], [-0.079, 0.116], parent=ax2)

fname_prefix='true_and_recon_aorta_flow'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Fig 10 ## CFD profiles 
fig = Figure()

ax = Axes('axis', xmin=0, xmax=1, ymin=0, ymax=0.0253, parent=fig)

Graphics('_img/cfd_trials_wss_profile_Re500_noise20_vpd5.png', [0,1], [0, 0.0253], parent=ax)

fname_prefix='cfd_trials_wss_profile'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

## Fig 11 ## Aorta WSS profile

fig = Figure()

ax = Axes('axis', xmin=0, xmax=1, ymin=0, ymax=0.16, parent=fig)

Graphics('_img/aorta_wss_dist_Re1000_noise20_vpd3.png', [0,1], [0, 0.16], parent=ax)

fname_prefix='aorta_wss_dist'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)


import sys
sys.exit()

# Below here is just example

##### Figure 1: History ####
fig = Figure()
grpsty = '{group size = 3 by 3, horizontal sep = 1.4cm, vertical sep = 0.4cm}'
grpplt = Groupplot(group_style=grpsty, parent=fig)
 
for p in [1, 2, 3]:

    ## Load data
    s = 'nel6p{0:d}q{0:d}'.format(p)
    dat0 = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy0_'+s+'_hist0.npz')
    dat1 = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy0_'+s+'_hist1.npz')
    N = dat0['R0_nrm'].shape[1]

    # Plot KKT residuals
    ax1 = Axes('axis', xtick='{0,50,100}',
               xmin=-5, xmax=105, ymin=6e-8, ymax=2e5,
               ymode='log', width='0.33\\textwidth', parent=grpplt)
    if p>1: ax1.set_properties(ymin=1e-10)
    if p==2: ax1.set_properties(ymax=2e3)
    if p==3: ax1.set_properties(xlabel='{Iteration ($k$)}')
    if p<3: ax1.set_properties(xticklabels='{,,}')
    Line(range(N), dat0['R0_nrm'][0, :], 'black', 'thick', dot,
         mark_repeat=10, parent=ax1, label='line:R0')
    Line(range(N), dat1['dLdY_nrm'][0, :]/dat1['dLdY_nrm'][0, 0], 'red',
         'thick', triangle, mark_repeat=10, parent=ax1, label='line:dLdY')

    # Plot objective residuals
    ax2 = Axes('axis', xtick='{0,50,100}',
               xmin=-5, xmax=105, ymin=6e-4, ymax=2,
               ymode='log', width='0.33\\textwidth', parent=grpplt)
               #title='{$p='+str(p)+'$}', parent=grpplt)
    if p==1: ax2.set_properties(ymin=6e-2, ymax=2)
    if p==3: ax2.set_properties(xlabel='{Iteration ($k$)}')
    if p<3: ax2.set_properties(xticklabels='{,,}')
    Line(range(N), dat0['R1err_nrm'][0, :], 'blue', 'thick', square,
         mark_repeat=10, parent=ax2, label='line:R1err')
    Line(range(N), dat0['R1msh_nrm'][0, :], 'magenta', 'thick', pentagon,
         mark_repeat=10, parent=ax2, label='line:R1msh')

    # Plot numerical parameters
    ax3 = Axes('axis', xtick='{0,50,100}',
               xmin=-5, xmax=105,
               ymode='log', width='0.33\\textwidth', parent=grpplt)
    if p==3: ax3.set_properties(xlabel='{Iteration ($k$)}')
    if p<3: ax3.set_properties(xticklabels='{,,}')
    Line(range(N), dat1['alpha'][0, :], 'black', 'solid',
         parent=ax3, label='line:alpha')
    Line(range(N), dat1['lam'][0, :], 'blue', 'dashed',
         parent=ax3, label='line:lam')
    Line(range(N), dat1['kappa0'][0, :], 'red', 'dash dot',
         parent=ax3, label='line:kappa')
    
# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_nrl0_hist'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

##### Figure 2: Slice at t=0.8 and shock surface ####

# Create figure and axes
fig = Figure()
grpsty = '{group size = 2 by 1, horizontal sep = 1.8cm}'
grpplt = Groupplot(group_style=grpsty, parent=fig)

ax0 = Axes('axis', 'axis equal image',
           width='0.45\\textwidth',
           xlabel='{$z$}', ylabel='{$t$}',
           xtick = '{0.0, 0.5, 0.8, 1.0}',
           ytick = '{0.0, 0.6, 1.2}',
           xmin=-0.2, xmax=1, ymin=0, ymax=1.2, parent=grpplt)
ax1 = Axes('axis', width='0.45\\textwidth',
           xlabel='{$t$}', ylabel='{$\phi(0.8,t)$}',
           xmin=0, xmax=1.2, ymin=-1, ymax=4.3, parent=grpplt)
#ax2 = Axes('axis', width='0.35\\textwidth',
#           xlabel='{$z_\mathrm{s}(t)$}', ylabel='{$t$}',
#           xmin=0, xmax=1, ymin=0, ymax=0.7, parent=grpplt)

# Plot space-time exact solution
Graphics('_img/iburg1v1d_sptm_nrl0_stdy0_nel6p4q4_final_nomsh.png',
         [-0.2, 1], [0, 1.2], parent=ax0)
Line([0.8, 0.8], [0, 1.2], 'solid', 'gray', 'dashed',
     parent=ax0, label='line:iburg-acc:slice')

ts = 0.4
zs = (1+4.0/3.0)*(1-np.sqrt(1+3*ts))+4*ts
Draw([-0.2, zs], [ts, ts], [], '->', '>=latex', cs='axis cs', parent=ax0)
Node('$z_\mathrm{s}(t)$', [0.5*(-0.2+zs), ts], 'axis cs', 'above', parent=ax0)

# Plot exact solution
tstar = 0.584777015771760
t1, t2 = np.linspace(0, tstar, 250), np.linspace(tstar, 1.2, 250)
U1, U2 = -3*0.2/(1+3*t1), 4 + 0*t2
Line(t1, U1, 'black', 'thick', parent=ax1)
Line(t2, U2, 'black', 'thick', parent=ax1)

t = np.linspace(0, 1.2, 500)
xs = (4.0/3.0+1)*(1-np.sqrt(1+3*t))+4*t;
idx = np.where(xs<=1.0)[0]
Line(xs[idx], t[idx], 'black', 'thick', parent=ax0,
     label='line:iburg-acc:exact')

# Plot numerical solutions
pltsty = [['cyan', 'dotted', 'thick'],
          ['red', 'dashed', 'thick'],
          ['yellow', 'dotted', 'thick']]

for p in [1, 2]: # [1, 2, 3]:

    # Load data
    s = 'nel6p{0:d}q{0:d}'.format(p)
    dat_slc = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy0_'+s+'_slice.npz')
    dat_shk = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy0_'+s+'_shock.npz')

    # Plot solution
    xlst, Ulst = format_coord_soln_elemwise(dat_slc['xsl'], dat_slc['Usl'],
                                            dat_slc['which_elem'], True)
    for k in range(len(xlst)):
        Line(xlst[k][1, :], Ulst[k][0, :], *pltsty[p-1], parent=ax1,
             label='line:iburg-acc:p'+str(p))

    # Plot shock
    xlst, Ulst = format_coord_soln_elemwise(dat_shk['xsl'], dat_shk['Usl'],
                                            dat_shk['which_elem'], True)
    for k in range(len(xlst)):
        Line(xlst[k][0, :], Ulst[k][0, :], *pltsty[p-1], parent=ax0)

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_nrl0_slice_shock'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)


##### Figure 3, Table 1: h-convergence ####

# Create figure and axes
fig = Figure()
grpsty = '{group size = 2 by 1, horizontal sep = 2.4cm}'
grpplt = Groupplot(group_style=grpsty, parent=fig)

ax1 = Axes('axis', width='0.42\\textwidth', height='0.325\\textwidth',
           xmode='log', ymode='log', xlabel='{$h$}', ylabel='{$E_\phi$}',
           xmin=0.01, xmax=0.2, ymin=1e-8, ymax=1e-1, parent=grpplt)
ax2 = Axes('axis', width='0.42\\textwidth', height='0.325\\textwidth',
           xmode='log', ymode='log', xlabel='{$h$}', ylabel='{$E_{z_\mathrm{s}}$}',
           xmin=0.01, xmax=0.2, ymin=1e-11, ymax=1e-2, parent=grpplt)
pltsty = [['black',  dot], ['blue', square],
          ['red', triangle], ['magenta', pentagon]]

# Setup data
h = np.zeros((4, 4))
nelem = np.zeros((4, 4))
err_soln = np.zeros((4, 4))
err_shk = np.zeros((4, 4))
for p in [1, 2, 3, 4]:
    dat = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy1_p{0:d}q{0:d}.npz'.format(p))
    h[:, p-1] = dat['h'][0, :]
    nelem[:, p-1] = dat['nelem'][0, :]
    err_soln[:, p-1] = dat['err_soln'][0, :]
    err_shk[:, p-1] = dat['err_shk'][0, :]

# Plot h convergence lines
for p in [1, 2, 3]:

    hpos = h[h[:, p-1]>0, p-1]
    hmin, hmax = 0.5*np.min(hpos), 2*np.max(hpos)

    # Solution error
    Line(h[:, p-1], err_soln[:, p-1], 'solid', 'thick', 
         *pltsty[p-1], parent=ax1, label='line:iburg:hconv:p'+str(p))
    b = np.log(err_soln[-2,p-1])-(p+1)*np.log(h[-2,p-1])
    y1, y2 = np.exp(b+(p+1)*np.log(hmin)), np.exp(b+(p+1)*np.log(hmax))
    Line([hmin, hmax], [y1, y2], 'dashed', pltsty[p-1][0], parent=ax1)

    # Shock error
    Line(h[:, p-1], err_shk[:, p-1], 'solid', 'thick',
         *pltsty[p-1], parent=ax2)
    b = np.log(err_shk[-2,p-1])-(p+1)*np.log(h[-2,p-1])
    y1, y2 = np.exp(b+(p+1)*np.log(hmin)), np.exp(b+(p+1)*np.log(hmax))
    Line([hmin, hmax], [y1, y2], 'dashed', pltsty[p-1][0], parent=ax2)

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_nrl0_hconv'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

# Create h convergence table
for p in [1, 2, 3]:
    f = open('iburg1v1d_sptm_nrl0_hconv_p'+str(p)+'.tab', 'w')
    E = np.vstack((err_soln[:, p-1][None, :], err_shk[:, p-1][None, :]))
    s = create_hconv_tab_sec(p, p, h[:, p-1], nelem[:, p-1], E)
    f.write(s)
    f.close()

##### Figure 4: No reinitialization demo ####

# Create figure and axes
fig = Figure()
grpsty = '{group size = 2 by 1, horizontal sep = 2cm, vertical sep = 1.5cm}'
grpplt = Groupplot(group_style=grpsty, parent=fig)

ax1 = Axes('axis', 'axis equal image',
           xmin=-0.2, xmax=1, ymin=0, ymax=1.2,
           xticklabels='{,,}', yticklabels='{,,}',
           width='0.45\\textwidth', parent=grpplt)
 
ax2 = Axes('axis', xtick='{0,50,100}',
           xlabel='{Iteration ($k$)}',
           xmin=-5, xmax=105, ymode='log',
           width='0.45\\textwidth', parent=grpplt)

## Plot 1: Image
Graphics('_img/iburg1v1d_sptm_nrl0_stdy0_nel6p3q3_noreinit_it040_msh.png',
         [-0.2, 1], [0, 1.2], parent=ax1)

## Plot 2: Convergence history

# Load data
s = 'nel6p{0:d}q{0:d}'.format(p)
dat0 = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy0_nel6p3q3_noreinit_hist0.npz')
dat1 = np.load('../simulations/_dat/iburg1v1d_sptm_nrl0_stdy0_nel6p3q3_noreinit_hist1.npz')
N = dat0['R0_nrm'].shape[1]

# Plot residuals
Line(range(N), dat0['R0_nrm'][0, :], 'black', 'thick', dot,
     mark_repeat=10, parent=ax2)
Line(range(N), dat1['dLdY_nrm'][0, :]/dat1['dLdY_nrm'][0, 0], 'red',
     'thick', triangle, mark_repeat=10, parent=ax2)
Line(range(N), dat0['R1err_nrm'][0, :], 'blue', 'thick', square,
     mark_repeat=10, parent=ax2, label='line:R1err')

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_nrl0_noreinit'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

################################## SHKFORM #####################################

##### Figure 1: History ####
fig = Figure()
grpsty = '{group size = 3 by 2, horizontal sep = 1.4cm, vertical sep = 0.4cm}'
grpplt = Groupplot(group_style=grpsty, parent=fig)
 
for p in [2, 3]:

    ## Load data
    s = 'nel20p{0:d}q{0:d}'.format(p)
    dat0 = np.load('../simulations/_dat/iburg1v1d_sptm_shkform_'+s+'_hist0.npz')
    dat1 = np.load('../simulations/_dat/iburg1v1d_sptm_shkform_'+s+'_hist1.npz')
    N = dat0['R0_nrm'].shape[1]
    if p == 3: N = N-6

    # Plot KKT residuals
    ax1 = Axes('axis', xtick='{0,50,100}',
               xmin=-5, xmax=105, ymin=6e-9, ymax=2e2,
               ymode='log', width='0.33\\textwidth', parent=grpplt)
    if p<3: ax1.set_properties(xticklabels='{,,}')
    if p==3: ax1.set_properties(xlabel='{Iteration ($k$)}')
    Line(range(N), dat0['R0_nrm'][0, :N], 'black', 'thick', dot,
         mark_repeat=10, parent=ax1, label='line:R0')
    Line(range(N), dat1['dLdY_nrm'][0, :N]/dat1['dLdY_nrm'][0, 0], 'red',
         'thick', triangle, mark_repeat=10, parent=ax1, label='line:dLdY')

    # Plot objective residuals
    ax2 = Axes('axis', xtick='{0,50,100}',
               xmin=-5, xmax=105, ymin=6e-5, ymax=0.2,
               ymode='log', width='0.33\\textwidth', parent=grpplt)
    if p<3: ax2.set_properties(xticklabels='{,,}')
    if p==2: ax2.set_properties(ymin=6e-4)
    if p==3: ax2.set_properties(xlabel='{Iteration ($k$)}')
    Line(range(N), dat0['R1err_nrm'][0, :N], 'blue', 'thick', square,
         mark_repeat=10, parent=ax2, label='line:R1err')
    Line(range(N), dat0['R1msh_nrm'][0, :N], 'magenta', 'thick', pentagon,
         mark_repeat=10, parent=ax2, label='line:R1msh')

    # Plot numerical parameters
    ax3 = Axes('axis', xtick='{0,50,100}', xmin=-5, xmax=105,
               ymode='log', width='0.33\\textwidth', parent=grpplt)
    if p<3: ax3.set_properties(xticklabels='{,,}')
    if p==3: ax3.set_properties(ymin=6e-6)
    if p==3: ax3.set_properties(xlabel='{Iteration ($k$)}')
    Line(range(N), dat1['alpha'][0, :N], 'black', 'solid',
         parent=ax3, label='line:alpha')
    Line(range(N), dat1['lam'][0, :N], 'blue', 'dashed',
         parent=ax3, label='line:lam')
    Line(range(N), dat1['kappa0'][0, :N], 'red', 'dash dot',
         parent=ax3, label='line:kappa')

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_shkform_hist'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

##### Figure 2: Slices ####

# Create figure and axes
fig = Figure()
#grpsty = '{group size = 3 by 4, horizontal sep = 0.4cm, vertical sep = 0.4cm}'
grpsty = '{group size = 4 by 2, horizontal sep = 0.4cm, vertical sep = 0.4cm}'
grpplt = Groupplot(group_style=grpsty, parent=fig)

#for k in [0, 4, 8, 1, 5, 9, 2, 6, 10, 3, 7, 11]:
for k in [0, 2, 3, 4, 5, 6, 9, 10]:

    # Create axis
    ax_ = Axes('axis', width='0.3\\textwidth',
               xmin=-1, xmax=1, ymin=-1.2, ymax=1.4, parent=grpplt)
    if k in [5, 6, 9, 10]:
        ax_.set_properties(xtick='{-1,0,1}', xlabel='{$z$}')
        if k in [6, 9, 10]:
            ax_.set_properties(yticklabels='{,,}')
    if k in [0, 5]:
        ax_.set_properties(ytick='{-1, 0, 1.2}',
                           ylabel='{$\phi(z,\\bar{t})$}')
        if k == 0:
            ax_.set_properties(xticklabels='{,,}')
    if k not in [0, 5, 6, 9, 10]:
        ax_.set_properties(xticklabels='{,,}', yticklabels='{,,}')
 
    # Load data
    dat_slc = np.load('../simulations/_dat/iburg1v1d_sptm_shkform_nel20p3q3_slice'+str(k+1).zfill(2)+'.npz')
    
    # Plot solution
    xlst, Ulst = format_coord_soln_elemwise(dat_slc['xsl'], dat_slc['Usl'],
                                            dat_slc['which_elem'], True)
    for j in range(len(xlst)):
        Line(xlst[j][0, :], Ulst[j][0, :],
             'black', 'solid', 'thick', parent=ax_)

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_shkform_shock'
write_tex(fig, fname_prefix=fname_prefix, view=True)
cleanup_compile(fname_prefix)

##### Figure 3: Slices (for animation) ####

# Create figure and axes
fig = Figure()
ax = Axes('axis', width='0.3\\textwidth',
          xmin=-1, xmax=1, ymin=-1.2, ymax=1.4,
          xtick='{-1,0,1}', ytick='{-1,0,1.2}', parent=fig)

for k in range(11):

    # Load data
    dat_slc = np.load('../simulations/_dat/iburg1v1d_sptm_shkform_nel20p3q3_slice'+str(k+1).zfill(2)+'.npz')
    
    # Plot solution
    xlst, Ulst = format_coord_soln_elemwise(dat_slc['xsl'], dat_slc['Usl'],
                                            dat_slc['which_elem'], True)
    for j in range(len(xlst)):
        Line(xlst[j][0, :], Ulst[j][0, :],
             'black', 'solid', 'thick', parent=ax, over=str(k+1))

# Write TikZ file, corresponding TeX file, compile, and view PDF
fname_prefix='_py/iburg1v1d_sptm_shkform_sliceanim'
#write_tex(fig, fname_prefix=fname_prefix, view=False)
#cleanup_compile(fname_prefix)

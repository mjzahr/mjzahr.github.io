function  [Ms,Ks,F] = get_temp_fem(msh,phys,bcs,spars)
% Compute finite element terms (mass, stiffness, external force)
% ---------------------------------------------------------------
% Inputs:
% -------
%   msh     - 1 x 1 structure containing mesh information
%             (see problem_setup.m)
%   phys    - 1 x 1 structure containing physical information
%             (see problem_setup.m)
%   bcs     - 1 x 1 structure containing boundary condition information
%             (see problem_setup.m)
%   spars   - 1 x 1 structure containing sparsity structure information
%             (fields: nnzeros, irow, jcol, LMnnz ... see create_sparsity_struct.m)
% Outputs:
% --------
%   Ms   - nnzeros x 1 double array containing nonzeros of mass
%          matrix (nnzeros defined in create_sparsity_struct.m)
%   Ks   - nnzeros x 1 double array containing nonzeros of mass
%          matrix (nnzeros defined in create_sparsity_struct.m)
%   F    - msh.ndof x 1 double array
% ---------------------------------------------------------------

F = zeros(msh.ndof,1);
Ks = zeros(spars.nnzeros,1);
Ms = zeros(spars.nnzeros,1);
[W,Z] = tri_guassquad(msh.nint);
[N,dN] = tri_shapefun(Z');
for e = 1:msh.nel
    dbcs  = bcs.dbc_loc(msh.t(e,:)');
    Tdbc  = bcs.dbc_val(msh.t(e,:)');
    dTdbc = bcs.dbc_der(msh.t(e,:)');
    Tdbc = Tdbc(dbcs); dTdbc = dTdbc(dbcs);
    nndbcs = logical(reshape((~dbcs)*double(~dbcs'),msh.nen^2,1));
    
    xe = msh.p(msh.t(e,:)',:)';
    
    kel = zeros(msh.nen,msh.nen);
    % mel = zeros(msh.nen,msh.nen); % Coder won't build with this line
    mel = zeros(3,3); % Hard code to help MATLAB Coder
    fel = phys.F(msh.t(e,:)');
    for i = 1:msh.nint
        dXdZ = xe*dN(:,:,i);
        dNdX = dN(:,:,i)/dXdZ;
        J = det(dXdZ);
        
        kel = kel + W(i)*J*(dNdX*phys.kappa*dNdX');
        mel = mel + W(i)*J*(N(:,i)*N(:,i)');
    end

    Ks(spars.LMnnz(nndbcs,e)) = Ks(spars.LMnnz(nndbcs,e)) + reshape(kel(~dbcs,~dbcs),sum(~dbcs)^2,1);
    Ms(spars.LMnnz(nndbcs,e)) = Ms(spars.LMnnz(nndbcs,e)) + reshape(mel(~dbcs,~dbcs),sum(~dbcs)^2,1);
    if sum(dbcs)>0
        F(msh.LM(~dbcs,e)+1) = F(msh.LM(~dbcs,e)+1) + mel(~dbcs,:)*fel - mel(~dbcs,dbcs)*dTdbc - kel(~dbcs,dbcs)*Tdbc;
    end
end
end
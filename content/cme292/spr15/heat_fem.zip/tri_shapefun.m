function  [N,dN] = tri_shapefun(xi)
% Linear triangle shape functions

N  = [xi(1,:);xi(2,:);1-xi(1,:)-xi(2,:)];
dN = repmat([1,0;0,1;-1,-1],[1,1,size(xi,2)]);

end
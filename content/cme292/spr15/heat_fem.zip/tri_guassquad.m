function  [W,Z] = tri_guassquad(nint)
% Weights and points of guass quadrature points for triangles.

if nint == 3
    % exactly integrates polynomial of degree 2
    W = [1/3;1/3;1/3];
    Z = [2/3,1/6,1/6;...
        1/6,2/3,1/6;...
        1/6,1/6,2/3];
elseif nint == 4
    % exactly integrates polynomial of degree 3
    W = [-9/16;25/48;25/48;25/48];
    Z = [1/3,1/3,1/3;...
        3/5,1/5,1/5;...
        1/5,3/5,1/5;...
        1/5,1/5,3/5];
else
    W=[];
    Z=[];
end
W = 0.5*W;

end
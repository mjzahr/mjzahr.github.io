function  [nnzeros,irow,jcol,LMnnz] = create_sparsity_struct(nel,nen,ndof,LM)
% Create sparsity structure of mass and stiffness matrices
% ---------------------------------------------------------------
% Inputs:
% -------
%   nel     - double scalar containing number of elements in mesh
%   nen     - double scalar indicating number of nodes/element
%             (= 3 for triangular elements - our case!)
%   ndof    - double scalar containing number of degrees of freedom
%             in mesh
%   LM      - 3 x nel double vector mapping local node number of 
%             element to degree of freedom number
%   
% Outputs:
% --------
%   nnzeros - double scalar containing number of nonzeros in matrices
%   irow    - nonzeros x 1 double array (one of sparsity triplet)
%   jcol    - nonzeros x 1 double array (one of sparsity triplet)
%   LMnnz   - nen^2 x nel double array
% ---------------------------------------------------------------

%This assumes that the matrix (jacobian) does not have an all zero row.
%Assumes LM is zero based.  Hence the adding of ones everywhere.

irow=zeros(ndof*ndof,1);
jcol=zeros(ndof*ndof,1);
cnt=1;
for e = 1:double(nel)
    LMpos = LM(:,e)>-1;
    ncol = sum(LMpos);
    
    irow(cnt:cnt+ncol^2-1) = reshape(repmat(LM(LMpos,e)',ncol,1),ncol^2,1);
    jcol(cnt:cnt+ncol^2-1) = repmat(LM(LMpos,e),ncol,1);
    cnt=cnt+ncol*ncol;
end
C=unique([irow,jcol],'rows');
irow=C(:,1)+1; jcol=C(:,2)+1; %1-based indexing
nnzeros=length(irow);
rc = [irow,jcol];

%LMnnz array: map from Lnnz# and elem# to nnz# in sparsity structure
LMnnz = zeros(nen^2,nel);
for e = 1:nel
    tmp=repmat(LM(:,e)'+1,[nen,1]);
    LMex = [repmat(LM(:,e)+1,[nen,1]),tmp(:)];
    [~,LOCB] = ismember(LMex,rc,'rows');
    LMnnz(:,e) = LOCB;
end

end
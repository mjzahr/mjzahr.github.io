function  [t,T] = time_integrate(solver,func,jac,T0,tspan,nstep)

ndof = size(T0,1);
switch solver
    case 'backward_euler'
        dt = (tspan(2)-tspan(1))/nstep;
        t = linspace(tspan(1),tspan(2),nstep+1);
        
        T = zeros(ndof,nstep+1);
        T(:,1) = T0;
        
        [L,U,p] = lu(eye(ndof)-dt*jac(0,0),'vector');
        for i = 1:nstep
            T(p,i+1) = U\(L\(T(:,i) + dt*func(t(i+1),0*T0)));
        end
    case 'ode45'
        options = odeset('Jacobian',jac);
        [t,T] = ode45(func,tspan,T0,options);
        T=T';
    case 'ode23s'
        options = odeset('Jacobian',jac);
        [t,T] = ode23s(func,tspan,T0,options);
        T=T';
end
% logical array assignment
x = linspace(0,2*pi,1000);
y = sin(2*x);

plot(x,y,'k-','linew',2); hold on;
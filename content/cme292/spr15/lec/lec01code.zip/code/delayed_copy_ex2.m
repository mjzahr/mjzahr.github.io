function  b = delayed_copy_ex2(A)
A(1,1) = 5; b = 10*A(1,1);
end
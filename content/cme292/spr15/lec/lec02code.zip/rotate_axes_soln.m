X = rand(100,3);
plot3(X(:,1),X(:,2),X(:,3),'b.');

set(gca,'CameraViewAngleMode','manual');
set(gca,'CameraViewAngle',10);
for i = 1:90
    set(gca,'view',[322.5 - i, 30]);
    pause(0.1);
end
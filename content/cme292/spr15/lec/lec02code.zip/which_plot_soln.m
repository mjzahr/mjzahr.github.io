fH(1)=figure;
aH(1)=axes(); hold on;

fH(2)=figure;
aH(2)=axes(); hold on;

x = linspace(0,2*pi,1000);
pstr = {'b','r','k','g','m'};
for k = 1:10
    if rem(k,2) == 0
        plot(aH(1),x,sin(k*x),pstr{ceil(k/2)},'linew',2);
    else
        plot(aH(2),x,sin(k*x),pstr{ceil(k/2)},'linew',2);
    end
end
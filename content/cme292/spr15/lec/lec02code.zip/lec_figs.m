% lecture figures

% Contour
figure; contour(peaks,20);  print(gcf,'-depsc2','../plt/contour_ex');
figure; contourf(peaks,20); print(gcf,'-depsc2','../plt/contourf_ex');
figure; contour3(peaks,20); print(gcf,'-depsc2','../plt/contour3_ex');

% Surf
figure; surf(peaks); print(gcf,'-depsc2','../plt/surf_ex');
figure; surfc(peaks); print(gcf,'-depsc2','../plt/surfc_ex');
figure; waterfall(peaks); print(gcf,'-depsc2','../plt/waterfall_ex');
figure; mesh(peaks); print(gcf,'-depsc2','../plt/mesh_ex');
figure; meshc(peaks); print(gcf,'-depsc2','../plt/meshc_ex');

% Quiver, Contour, Streamline
figure;
[x,y] = meshgrid(-2:.2:2,-1:.15:1);
z = x .* exp(-x.^2 - y.^2); [px,py] = gradient(z,.2,.15);
contour(x,y,z), hold on
quiver(x,y,px,py);
streamline(x,y,px,py,[-0.5,-0.5,-0.5,-1,-1,-1],[-0.5,0,0.5,-0.5,0,0.5]), hold off, axis image
print(gcf,'-depsc2','../plt/quiver_streamline_ex');

% Vector volume
% coneplot
figure;
load wind
vel = sqrt(u.*u + v.*v + w.*w);
p = patch(isosurface(x,y,z,vel, 40));
isonormals(x,y,z,vel, p)
set(p, 'FaceColor', 'red', 'EdgeColor', 'none');

[f verts] = reducepatch(isosurface(x,y,z,vel, 30), .2);
h=coneplot(x,y,z,u,v,w,verts(:,1),verts(:,2),verts(:,3),2);
set(h, 'FaceColor', 'blue', 'EdgeColor', 'none');
[cx cy cz] = meshgrid(linspace(71,134,10),linspace(18,59,10),3:4:15);
h2=coneplot(x,y,z,u,v,w,cx,cy,cz,v,2); %color by North/South velocity
set(h2, 'EdgeColor', 'none');

axis tight; box on
camproj p; camva(24); campos([185 2 102])
camlight left; lighting phong
print(gcf,'-depsc2','../plt/coneplot_ex');

% streamtube
figure;
load wind
[sx sy sz] = meshgrid(80, 20:10:50, 0:5:15);
h=streamtube(x,y,z,u,v,w,sx,sy,sz);
axis tight
shading interp;
view(3);
camlight; lighting gouraud
print(gcf,'-depsc2','../plt/streamtube_ex');

% streamslice
figure;
z = peaks;
surf(z); hold on
shading interp;
[c ch] = contour3(z,20); set(ch, 'edgecolor', 'b')
[u v] = gradient(z);
h = streamslice(-u,-v);  % downhill
set(h, 'color', 'k')
for i=1:length(h);
    zi = interp2(z,get(h(i), 'xdata'), get(h(i),'ydata'));
    set(h(i),'zdata', zi);
end
view(30,50); axis tight
print(gcf,'-depsc2','../plt/streamslice_ex');

% Create mesh
addpath('path/to/heat_fem')
addpath('path/to/heat_fem/distmesh')

% NOTE: Debug with mesh = 'coarse'.  Do final timings
% with mesh = 'fine' (if there is sufficient memory on
% your computer, if not, change line 16 to
% [p,t] = create_mesh('rect_with_circle',0.02); )
% mesh = 'coarse';
mesh = 'fine';

switch mesh
    case 'coarse'
        [p,t] = create_mesh('rect_with_circle',0.05);
    case 'fine'
        [p,t] = create_mesh('rect_with_circle',0.02);
end
tic; [msh,phys,bcs] = setup_problem(p,t); t_setup=toc;
tic; [msh.ID,msh.LM] = build_matrices(t,bcs.dbc_loc,msh.np); t_build=toc;

% Create sparsity structure of mass and stiffness matrices
tic; [spars.nnzeros,spars.irow,spars.jcol,spars.LMnnz] = create_sparsity_struct(msh.nel,msh.nen,msh.ndof,msh.LM); t_sparse=toc;

% Evaluate mass and stiffness matrices and force term
% This is a linear problem so M, K are constant
% We assume force term is also constant
tic; [Ms,Ks,F] = get_temp_fem(msh,phys,bcs,spars); t_fem=toc;

% Compute required quantities for heat flow
tic;
M = sparse(spars.irow,spars.jcol,Ms);
K = sparse(spars.irow,spars.jcol,Ks);

MinvF = M\F;
MinvK = full(M\K);
t_invert = toc;

% Integrate
func = @(t,T) MinvF - MinvK*T;
jac  = @(t,T) -MinvK;
tspan = [0,1]; nstep = 400;
T0 = zeros(msh.ndof,1);
tic; [time,T] = time_integrate('backward_euler',func,jac,T0,tspan,nstep); t_integrate=toc;

% Timing summary
fprintf('%34s\n','Timing Summary');
fprintf('----------------------------------------------------------\n');
fprintf('%34s: \t %e s\n','Setup Problem (mesh, physics, bcs)',t_setup);
fprintf('%34s: \t %e s\n','Build FEM Matrices',t_build);
fprintf('%34s: \t %e s\n','Create Sparsity Structures',t_sparse);
fprintf('%34s: \t %e s\n','Invert Mass Matrix',t_invert);
fprintf('%34s: \t %e s\n','Time Integration',t_integrate);

% Postprocessing
h = simpplot(msh.p,msh.t);
print(gcf,'-depsc2','heat_mesh');
set(h,'facecolor','interp');

Tf = zeros(size(bcs.dbc_loc));
Tf(bcs.dbc_loc) = bcs.dbc_val(bcs.dbc_loc);
for i = 1:size(T,2)
    Tf(~bcs.dbc_loc) = T(:,i);
    set(h,'facevertexcdata',Tf); drawnow;
end
print(gcf,'-depsc2','heat_soln');
classdef  dsg_elem_def < handle
    
    properties (SetAccess=private,GetAccess=public)
        figHan  = []; % Figure handle
        axHan   = []; % Axes handle
        ptHan   = []; % Node handles
        surfHan = []; % Surface handle
        
        sdg_name  = []; % Name of SDESIGN file
        sdg_nodes = []; % Design element nodes
        surf_nodes= []; % Location of surface nodes on airfoil
        sdg_nodes_disp=[]; % Displacement of design element nodes
    end
    
    properties (Hidden)
        sdesign_template = '';
        sdesign_exec     = '/srv/zfs01/user_data/mzahr/sdesign.Linux.opt';
        sdesign_iter     = '';
        surfnodes_fname  = '';
        displace_fname   = '';
    end
    
    methods
        function [self] = dsg_elem_def(sdesign_template_in)
            % This is the constructor for the dsg_elem_def class.  It is responsible for reading the SDESIGN
            % template file passed in 'sdesign_template_in' and setting appropriate filename (namely, the
            % file name for the SDESIGN input file that will be passed to SDESIGN in the system call; the
            % file name of the surface displacements that SDESIGN will return; the file containing the surface
            % nodes (undeformed); etc).  This function will also plot the surface and control nodes, as well
            % as set the graphics handles for the corresponding figure, axes, and objects to class properties.
            % Callback routines are set for the figure and axes objects to enable graphically moving the control
            % nodes.
            
            % Filenames
            self.sdesign_template= sdesign_template_in;
            self.sdesign_iter    = [sdesign_template_in,'.iter'];
            self.surfnodes_fname = dsg_elem_def.get_surfacenode_file(sdesign_template_in);
            self.displace_fname = strrep(sdesign_template_in,'.sdesign','.vmo');
            
            % Get surface and design element nodes
            self.sdg_nodes  = dsg_elem_def.get_design_element_nodes(sdesign_template_in);
            self.surf_nodes = dsg_elem_def.read_surfacenodes(self.surfnodes_fname);
            self.sdg_nodes_disp = zeros(size(self.sdg_nodes));
            
            % Plot limits
            xlim = [min(self.sdg_nodes(:,1)),max(self.sdg_nodes(:,1))];
            ylim = [min(self.sdg_nodes(:,2)),max(self.sdg_nodes(:,2))];
            dx = xlim(2)-xlim(1);
            dy = ylim(2)-ylim(1);
            
            % Setup graphics
            self.figHan = figure('WindowButtonUpFcn',@(han,src) self.release_button(han,src));
            self.axHan  = axes('nextplot','add',...
                'DataAspectRatioMode','manual',...
                'DataAspectRatio',[1,1,1],...
                'XLim',[xlim(1)-0.1*dx,xlim(2)+0.1*dx],...
                'YLim',[ylim(1)-1.0*dy,ylim(2)+1.0*dy]);
            for i = 1:size(self.sdg_nodes,1);
                self.ptHan(i) = plot(self.sdg_nodes(i,1),self.sdg_nodes(i,2),'ro','markerfacecolor','r','markeredgecolor','k');
            end
            set(self.ptHan,'UserData',false,'ButtonDownFcn',@(han,src)self.select_node(han,src));
            self.surfHan = plot(self.surf_nodes(:,1),self.surf_nodes(:,2),'b-','linew',2);
        end
        
        function [] = draw_surface(self,x,y)
            % Set surface xdata and ydata to x,y respectively
            
            % YOUR CODE HERE
        end
        
        function [] = select_node(self,hobj,~)
            % This will be the ButtonDownFcn callback of the design element
            % nodes.  It will set the 'UserData' property to true
            % indicating it is selected.
            
            % Make sure all nodes unselected and then select appropriate
            set(self.ptHan,'UserData',false);
            set(hobj,'UserData',true);
            
        end
        
        function [] = release_button(self,hobj,~)
            % This will be the WindowButtonUpFcn of the figure.  It will
            % determine the coordinates (in the axes) of the pointer and
            % move the selected node to the position.  If no node is
            % selected, it does nothin.  If inside this function, button
            % click has already occurred.
            
            % Extract selected nodes
            selected_nodes=get(self.ptHan,'UserData');
            selected_nodes=[selected_nodes{:}]';
            
            % Return if no nodes selected, otherwise extract index
            if ~any(selected_nodes), return; end;
            ind = find(selected_nodes);
            
            % Pointer position
            pp = get(gca,'CurrentPoint'); pp = pp(1,1:2)';
            
            % Set node position
            self.set_node_position(ind,pp);
            
            % Determine DISPLACEMENT of node
            self.sdg_nodes_disp(ind,:) = pp - self.sdg_nodes(ind,:)';
            
            % Write sdesign file
            self.write_sdesign();
            
            % Call sdesign
            self.run_sdesign();
            
            % Read sdesign
            disp = dsg_elem_def.read_surfacenode_disp(self.displace_fname);
            
            % Update surface position
            self.draw_surface(self.surf_nodes(:,1),self.surf_nodes(:,2));
        end
        
        function [] = set_node_position(self,node_num,pos)
            % Move specified node to specified position
            set(self.ptHan(node_num),'xdata',pos(1),'ydata',pos(2));
        end
        
        function [] = write_sdesign(self)
            % Write node deformation in sdesign file
            
            % Open files (template and iteration)
            
            % Copy template to iteration file line by line,
            % modifying appropriate lines
            
            % Close files

        end
        
        function [] = run_sdesign(self)
            % Call sdesign with appropriate input file
            % Sdesign is an executable (needs to be system call)
            % Call sdesign: /path/to/sdesign.Linux.opt /path/to/input
            
        end        
    end
    
    methods (Static=true)
        function [dsgnodes]  = get_design_element_nodes(sdesign_file)
            % This function reads the nodes and edges of the design element from the
            % SDESIGN template (or input) file.  Do not modify.
 
            % SDESIGN keywords
            keys = {'SDOUTPUT','DEFINE','NODES',...
                    'EDGES','PATCH','VOLUME',...
                    'DSGVAR','LINK','FEMESH','END'};
            isdefine =false;
            isnodes  =false;
            dsgnodes =[];
            % Open file
            fid = fopen(sdesign_file);
            while 1
                % Get line
                tline = fgetl(fid);
                if ~ischar(tline), break, end;
                
                % Remove comments
                ind_comment = regexp(tline,'#');
                if ~isempty(ind_comment)
                    tline(:,ind_comment(1):end)=[];
                end
                if isempty(tline), continue; end;
                
                % Remove whitespace
                tline = strtrim(tline);
                
                if sum(ismember(keys,tline)) > 0
                    if strcmpi(tline,'DEFINE')
                        isdefine = true;
                        isnodes  = false;
                        continue;
                    elseif strcmpi(tline,'NODES')
                        isdefine = false;
                        isnodes  = true;
                        continue;
                    else
                        isdefine = false;
                        isnodes  = false;
                    end
                end
                
                % Define variables
                if isdefine
                    eval([tline,';']);
                end
                
                % Get nodes
                if isnodes
                    dsgnodes = [dsgnodes; eval(['[',tline,']'])];
                end
            end
            fclose(fid);
            
            % Remove numbers
            dsgnodes(:,[1,4])=[];
            dsgnodes = unique(dsgnodes,'rows','stable');
        end
        
        function [surfnodes] = get_surfacenode_file(sdesign_file)
            % Search through each line of SDESIGN file and extract surface
            % nodes file
            
            fid = fopen(sdesign_file);
            while 1
                tline = fgetl(fid);
                if ~ischar(tline), break, end;
                
                if ~isempty(regexp(tline,'FEMESH','once'))
                    ind = regexp(tline,'"');
                    surfnodes = tline(ind(1)+1:ind(2)-1);
                end
            end
        end
        
        function [nodes] = read_surfacenodes(fname)
            % Read XY coordinates of surface nodes
            
            % Open file and ignore first line
            fid=fopen(fname);
            fgetl(fid);
            
            % Read all nodes
            X = textscan(fid,'%d%f%f%f');
            nodes = [X{2:3}];
            
            % Close file
            fclose(fid);
        end
        
        function [disp] = read_surfacenode_disp(fname)
            % Read XY coordinates of surface node displacements
            
            
            % Open file and ignore first three line
            
            % Read all nodes
            
            % Close file
            
            disp = 0; % Replace this line of code and complete to above tasks
                      % fill disp with the columns of fname.
        end
    end
end

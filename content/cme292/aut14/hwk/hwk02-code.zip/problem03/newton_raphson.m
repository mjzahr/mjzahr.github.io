function  [x,output] = newton_raphson(func,x0,options)

% Get initial residual
[R,J] = func(x0);

x=x0;
converged=false;
for niter = 1:options.maxit
    % Newton-Raphson search direction
    
    % Update solution
    
    % Compute nonlinear terms at new solution
    
    % Check for convergence
    if converged
        break;
    end
end

% Get outputs from nonlinear iterations
output=[];
end
x0 = [1;1];
A  = [-1,-5];
b  = 0;
lb = [-2;-2];
ub = [2;2];

[xstar,fstar] = fmincon(@fmincon_obj_soln,x0,A,b,[],[],lb,ub,@fmincon_constr_soln);

[X,Y] = meshgrid(linspace(lb(1),ub(1),30),linspace(lb(2),ub(2),30));
F = zeros(size(X));
C = zeros(size(X));
AA = zeros(size(X));

for i = 1:size(X,1)
    for j = 1:size(X,2)
        F(i,j) = fmincon_obj_soln([X(i,j),Y(i,j)]);
        C(i,j) = fmincon_constr_soln([X(i,j),Y(i,j)]);
        AA(i,j)= A*[X(i,j);Y(i,j)];
    end
end

figure;
h(1) = surf(X,Y,F);
xlabel('x1'); ylabel('x2');
view(gca,[-81.5 48]);
print(gcf,'-depsc2','fmincon_obj');

figure;
h(2) = surf(X,Y,C); hold on;
h(3) = surf(X,Y,AA);
h(4) = surf(X,Y,0*F,'edgecolor','none','facecolor','k');
xlabel('x1'); ylabel('x2');
view(gca,[-81.5 48]);
print(gcf,'-depsc2','fmincon_constr');

figure;
h(5) = surf(X,Y,F); hold on;
h(6) = surf(X,Y,C,'edgecolor','none','facecolor','r');
h(7) = surf(X,Y,AA,'edgecolor','none','facecolor','b');
h(8) = surf(X,Y,0*F,'edgecolor','none','facecolor','k');
h(9) = plot3(xstar(1),xstar(2),fstar,'bo','markersize',10,'markerfacecolor','b','markeredgecolor','k');
h(10) = plot3(xstar(1),xstar(2),0,'mo','markersize',10,'markerfacecolor','m','markeredgecolor','k');
xlabel('x1'); ylabel('x2');
view(gca,[-83.5 12]);
print(gcf,'-depsc2','fmincon_soln');
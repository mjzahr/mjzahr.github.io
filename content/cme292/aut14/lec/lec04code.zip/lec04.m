% lec04
%% Non-uniqueness and non-existence of solution of nonlinear equations
x = linspace(-2,2,1000);

figure('paperpositionmode','auto');
plot(x,x.^2+1,'k-','linew',2); hold on;
plot(x,x.^2,'r--','linew',2);
plot(x,x.^2-1,'b:','linew',2);
plot(x,0*x,'k--'); plot([0,0],[-1,5],'k--');
xlabel('$x$','interpreter','latex'); ylabel('$f(x)$','interpreter','latex');
% legend('0 Solutions','1 Solution','2 Solutions');
leg=legend('$f(x) = x^2 + 1$','$f(x) = x^2$','$f(x) = x^2 - 1$');
set(leg,'interpreter','latex','Position',[0.5890625 0.692857142857143 0.303794642857143 0.209375]);
print(gcf,'-depsc2','nleqn_ex'); fixPSlinestyle('nleqn_ex.eps');

%% Newton Demo
% Should work easily
newton_demo(@(x) x.^2-1,@(x) 2*x,5,[-6,6]);

% Should work, but not easily (gradient -> 0 at solution)
newton_demo(@(x) x.^2,@(x) 2*x,5,[-6,6]);

% Might work, but unpredictable, start near extrema
newton_demo(@(x) sin(x),@(x) cos(x),3*pi/2-0.1,[-10*pi,10*pi]);

%% Bisection Demo
bisection_demo(@(x) sin(x),[-1.5*pi,1.25*pi]);
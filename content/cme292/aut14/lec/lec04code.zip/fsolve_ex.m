function  [out1,out2]=fsolve_ex()
% fsolve_soln
x0 = [1;1];

[x1,f1,exit1,out1] = fsolve( 'WRITE ME!' );

options = optimset('Jacobian','on');
[x2,f2,exit2,out2] = fsolve(  'WRITE ME!'  );

end

function [f,df] = func(x)

% Write me!!!

end
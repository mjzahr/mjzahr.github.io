function  [f,df] = fmincon_obj_soln(x)

% f  = 2*x(1)^3 - 3*x(1)^2 - x(2)^2;
% df = [6*x(1)^2-6*x(1);-2*x(2)];

f  = x(1)^3 + x(2)^3;
df = [3*x(1)^2;3*x(2)^2];

end
function  [out1,out2]=fsolve_soln()
% fsolve_soln
x0 = [1;1];

[x1,f1,exit1,out1] = fsolve(@func,x0);

options = optimset('Jacobian','on');
[x2,f2,exit2,out2] = fsolve(@func,x0,options);

end

function [f,df] = func(x)

f  = [x(1)-4*x(1)^2-x(1)*x(2);...
      2*x(2)-x(2)^2-3*x(1)*x(2)];
df = [1-8*x(1)-x(2),-x(1);...
      -3*x(2),2-2*x(2)-3*x(1)];

end
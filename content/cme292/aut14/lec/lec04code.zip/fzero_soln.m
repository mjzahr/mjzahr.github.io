% Try different starting conditions.  See what happens!

[x1,fval1,exitflag1,output1] = fzero(@(x) x^2  ,4);
[x2,fval2,exitflag2,output2] = fzero(@(x) x^2-1,4);
[x3,fval3,exitflag3,output3] = fzero(@(x) x^2+1,4);
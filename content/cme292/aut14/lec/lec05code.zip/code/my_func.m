function [f] = my_func(x)


f = x^2;

end
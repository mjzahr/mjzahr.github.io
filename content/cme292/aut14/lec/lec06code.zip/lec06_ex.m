%% DLMREAD
% STARTER CODE FOR LIFTDRAG PLOT
pstr = {'r','b'};
fnames = dir('liftdrag');
for i = 1:length(fnames)-2
    fname = ['liftdrag/',fnames(i+2).name];
    % YOUR CODE!!
end
% YOUR CODE!!

%% File position
fid = fopen('liftdrag/unsteady.hdm.LiftDrag');
line1 = fgetl(fid);
for i = 1:10
    line=fgetl(fid);
end

fprintf('File location = %d\n',ftell(fid));
fprintf('At end of file? = %d\n',feof(fid));
frewind(fid);
fprintf('File location = %d\n',ftell(fid));
fprintf('At end of file? = %d\n',feof(fid));
fseek(fid,1000,-1);
fprintf('File location = %d\n',ftell(fid));
fprintf('At end of file? = %d\n',feof(fid));
while (fgetl(fid) ~= -1); end;
fprintf('File location = %d\n',ftell(fid));
fprintf('At end of file? = %d\n',feof(fid));

%% TEXTSCAN
% UC Berkeley Graphics group mesh format
fname = 'meshes/dragon';

fid = fopen([fname,'.node']);
fgetl(fid);
nodes  = textscan(fid,'%d %f %f %f %d');
fclose(fid);
p = [nodes{2:end-1}];

fid = fopen([fname,'.ele']);
fgetl(fid);
elems  = textscan(fid,'%d %d %d %d %d');
fclose(fid);
t = [elems{2:end}];

figure;
simpplot(p,t);
set(gca,'cameraposition',[40.5091 39.0167 488.426],...
        'view',[ 0,90]);
print(gcf,'-depsc2','dragon');

% FRG mesh format
fname = 'meshes/AGARDwtt.top';
fid = fopen(fname);

% YOUR CODE!!

fclose(fid);

% YOUR CODE!!

%% Spreadsheet
M = rand(10,4);
[stat,msg] = xlswrite('examp.xls',M,2,'D3:M12');

%% Images
man  = imread('images/mandrill.jpeg','jpeg');
palm = imread('images/palm.png','png');

figure('pos',[129,351,1063,419]);
subplot(1,2,1); image(man);
subplot(1,2,2); image(palm);

imwrite(man,'images/mandrill.png','png');
imwrite(palm,'images/palm.jpeg','jpeg');
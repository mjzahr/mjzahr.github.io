s = '/srv/zfs01/user_data/mzahr/sdesign.Linux.opt';
system([s,' naca0012.sdesign.iter']);
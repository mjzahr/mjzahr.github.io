function [p,t,rho0,E,nu] = vega2distmesh( fname , matonly )

if nargin < 2 || isempty(matonly), matonly=false; end;

fid = fopen(fname);
while 1
    tline = fgetl(fid);
    if ~ischar(tline), break, end
    
    if ~matonly
        if strcmpi(deblank(tline),'*VERTICES')
            tmp=fgetl(fid); tmp=str2num(tmp);
            np = tmp(1);
            
            p=zeros(np,3);
            for i = 1:np
                verttxt = fgetl(fid);
                vertinfo = str2num(verttxt);
                p(i,:) = vertinfo(1,2:end);
            end
        end
        
        if strcmpi(deblank(tline),'*ELEMENTS')
            eltype = fgetl(fid);
            if ~strcmp(eltype,'TET')
                fprintf('Only TETs supported...Exiting.');
                return;
            end
            tmp=fgetl(fid); tmp=str2num(tmp);
            nel = tmp(1);
            
            t=zeros(nel,4);
            for i = 1:nel
                elemtxt = fgetl(fid);
                eleminfo = str2num(elemtxt);
                t(i,:) = eleminfo(1,2:end);
            end
        end
    end
    
    if ~isempty(strfind(deblank(tline),'*MATERIAL'))
        matprop = fgetl(fid);
        if isempty(findstr(matprop,'ENU'))
            fprintf('Only materials parameterized by E, nu supported...Exiting.');
            return;
        end
        
        commas = regexp(matprop,',');
        matprop = str2num(matprop(commas(1)+1:end));
        
        rho0 = matprop(1);
        E = matprop(2);
        nu = matprop(3);
    end
end
fclose(fid);
if ~matonly
    p=p(:,[1,3,2]);
    [p,t]=fixmesh(p,t);
else
    p=[]; t=[];
end
end


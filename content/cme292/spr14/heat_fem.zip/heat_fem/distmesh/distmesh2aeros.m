function  [] = distmesh2aeros(fname,msh,fExtNodal,dbc,udbc,phys,openflag)

if nargin < 7 || isempty(openflag), openflag='w+'; end;

p = msh.X';
t = msh.IEN'+1;

np = size(p,1);
nsd=size(p,2);
nel=size(t,1);
nen=size(t,2);

elemnum = 23; %4 node tetrahedra in AERO-S

fid = fopen(fname,openflag);

%Write NODES
fprintf(fid,'NODES\n');
for i = 1:np
    fprintf(fid,'%i %20.16e %20.16e %20.16e\n',i,p(i,1),p(i,2),p(i,3));
end
fprintf(fid,'*************************************************\n');

%Write connectivity
fprintf(fid,'TOPOLOGY\n');
for i = 1:nel
    fprintf(fid,'%i %i %i %i %i %i\n',i,elemnum,t(i,1),t(i,2),t(i,3),t(i,4));
end
fprintf(fid,'*************************************************\n');

%Write NBCs
fprintf(fid,'FORCE\n');
cnt=0;
for i = 1:np
   for j = 1:nsd
       if ~dbc(j,i)
           cnt=cnt+1;
           if fExtNodal(cnt) == 0, continue; end
           fprintf(fid,'%i %i %20.16e\n',i,j,fExtNodal(cnt));
       end
   end
end
fprintf(fid,'*************************************************\n');

%Write DBCs
fprintf(fid,'DISPLACEMENTS\n');
cnt=0;
for i = 1:np
   for j = 1:nsd
       if dbc(j,i)
           cnt=cnt+1;
           fprintf(fid,'%i %i %20.16e\n',i,j,udbc(cnt));
       end
   end
end
fprintf(fid,'*************************************************\n');

%Write Attribute
fprintf(fid,'ATTRIBUTE\n');
nummat = msh.nummat;
for i = 1:nummat
   ind = find((msh.mat+1) == i);
   interfaces = find(abs(diff(ind))>1);
   if isempty(interfaces) && ~isempty(ind) %indicates no jumps
       if length(ind)==1
           fprintf(fid,'%i %i\n',ind,i); 
       else
           fprintf(fid,'%i %i %i\n',ind(1),ind(end),i);
       end;
       continue;
   else
       fprintf(fid,'%i %i %i\n',ind(1),ind(interfaces(1)),i);
       for j = 2:length(interfaces)
           fprintf(fid,'%i %i %i\n',ind(interfaces(j-1)+1),ind(interfaces(j)),i);
       end
       fprintf(fid,'%i %i %i\n',ind(interfaces(end)+1),ind(end),i);
   end    
end
fprintf(fid,'*************************************************\n');


%Write Material
fprintf(fid,'MATERIAL\n');
for i = 1:nummat
    E = phys(i).mu*(3*phys(i).lam + 2*phys(i).mu)/(phys(i).lam + phys(i).mu); %Convert from Lame parameters to Young's modulus
    nu = 0.5*phys(i).lam/(phys(i).lam + phys(i).mu);          %and Poisson's ratio
    rho = phys(i).rho0;
    fprintf(fid,'%i 0.0 %20.16e %20.16e %20.16e 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0 0.0\n',i,E,nu,rho);
end
fprintf(fid,'*************************************************\n');

%END
fprintf(fid,'END');

fclose(fid);
end
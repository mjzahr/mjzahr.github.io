function  [ID,LM] = build_matrices(t,dbc_loc,np)
% Build matrices for mapping between local and global quantities
% ---------------------------------------------------------------
% Inputs:
% -------
%   t       - nel x 3 double matrix containing global
%             node number ofeach node a given element
%   dbc_loc - np x1 boolean vector indicating nodes
%             corresponding to Dirichlet BCs
%   np      - double containing number of nodes in mesh
%   
% Outputs:
% --------
%   ID - 1 x np double vector mapping node to degred of freedom
%   LM - 3 x nel double vector mapping local node number of 
%        element to degree of freedom number
% ---------------------------------------------------------------

%ID array: map from dof# and Gnode# to Gdof#
ID=zeros(1,np);
dofcnt=0;
dbccnt=0;
for j=1:np
    if dbc_loc(j)
        dbccnt=dbccnt-1;
        ID(j)=dbccnt;
    else
        dofcnt=dofcnt+1;
        ID(j)=dofcnt-1;
    end
end

%LM array: map from Lnode# and elem# to dof#
LM = ID(t');
end
function  [p,t] = create_mesh(fname,h)

addpath('distmesh');

save_str = fname;
switch fname
    case 'naca'
        if exist(save_str), load([save_str,'.mat']); return; end;
        
        [p,~,t]=initmesh('naca');
    case 'unit_circle'
        if nargin == 1, h = 0.2; end;
        hstr = num2str(h); hstr(hstr == '.')='p';
        save_str = [save_str,'_h',hstr,'.mat'];
        if exist(save_str), load(save_str); return; end;
        
        fprintf('Uniform Mesh on Unit Circle\n');
        fd=@(p) sqrt(sum(p.^2,2))-1;
        [p,t]=distmesh2d(fd,@huniform,h,[-1,-1;1,1],[]);
    case 'polygon'
        if nargin == 1, h = 0.1; end;
        hstr = num2str(h); hstr(hstr == '.')='p';
        save_str = [save_str,'_h',hstr,'.mat'];
        if exist(save_str), load(save_str); return; end;
        
        fprintf('Polygon\n');
        pv=[-0.4 -0.5;0.4 -0.2;0.4 -0.7;1.5 -0.4;0.9 0.1;
            1.6 0.8;0.5 0.5;0.2 1;0.1 0.4;-0.7 0.7;-0.4 -0.5];
        [p,t]=distmesh2d(@dpoly,@huniform,0.1,[-1,-1; 2,1],pv,pv);
    case 'ellipse'
        if nargin == 1, h = 0.2; end;
        hstr = num2str(h); hstr(hstr == '.')='p';
        save_str = [save_str,'_h',hstr,'.mat'];
        if exist(save_str), load(save_str); return; end;
        
        fprintf('Ellipse\n');
        fd=@(p) p(:,1).^2/2^2+p(:,2).^2/1^2-1;
        [p,t]=distmesh2d(fd,@huniform,h,[-2,-1;2,1],[]);
    case 'square_line_source'
        if nargin == 1, h = 0.01; end;
        hstr = num2str(h); hstr(hstr == '.')='p';
        save_str = [save_str,'_h',hstr,'.mat'];
        if exist(save_str), load(save_str); return; end;
        
        fprintf('Square, with size function point and line sources\n');
        fd=@(p) drectangle(p,0,1,0,1);
        fh=@(p) min(min(0.01+0.3*abs(dcircle(p,0,0,0)), ...
            0.025+0.3*abs(dpoly(p,[0.3,0.7; 0.7,0.5]))),0.15);
        [p,t]=distmesh2d(fd,fh,h,[0,0;1,1],[0,0;1,0;0,1;1,1]);
    case 'rect_with_circle'
        if nargin == 1, h = 0.05; end;
        hstr = num2str(h); hstr(hstr == '.')='p';
        save_str = [save_str,'_h',hstr,'.mat'];
        if exist(save_str), load(save_str); return; end;
        
        fprintf('Rectangle with circular hole, refined at circle boundary\n');
        fd=@(p) ddiff(drectangle(p,-1,1,-1,1),dcircle(p,0,0,0.5));
        fh=@(p) 0.05+0.3*dcircle(p,0,0,0.5);
        [p,t]=distmesh2d(fd,fh,h,[-1,-1;1,1],[-1,-1;-1,1;1,-1;1,1]);
end
save(save_str,'p','t');

end
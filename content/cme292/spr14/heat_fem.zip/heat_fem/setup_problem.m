function  [msh,phys,bcs] = setup_problem(p,t)
%% Mesh and integrations properties/matrices
msh.p   = p;
msh.t   = t;
msh.np  = size(p,1);
msh.nel = size(t,1);
msh.nen = 3; % triangles
msh.nint = 4; % four integration points (third order poly exactly)
msh.LM  = zeros(msh.nen,msh.nel);

%% Physical parameters (thermal conductivity and heat sources)
phys.kappa = [1,0;0,1];
phys.F     = zeros(msh.np,1);

%% Boundary conditions
bcs.dbc_loc  = abs(p(:,1)+1)<1e-6;
bcs.dbc_find = find(bcs.dbc_loc);
bcs.dbc_num  = sum(bcs.dbc_loc);
bcs.dbc_val  = 5*double(bcs.dbc_loc);%5*sin(msh.p(:,2)).*double(bcs.dbc_loc);
bcs.dbc_der  = 0*double(bcs.dbc_loc);

%% Adjust mesh based on Dirichlet BCs
msh.ndof = msh.np - sum(bcs.dbc_loc);
end
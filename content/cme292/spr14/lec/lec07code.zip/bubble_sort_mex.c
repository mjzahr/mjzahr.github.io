#include "mex.h"
#include "matrix.h"

void mexFunction(int nlhs, mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]) {
    int i, M;
    bool swapped;
    double *v, *s, tmp;
            
    /* Get size of vector (assume column) */
    M = mxGetM(prhs[0]);
    /* Get pointer to data of input */
    v = mxGetPr(prhs[0]);
    
    /* Get output and pointer to its data of output */
    plhs[0] = mxCreateDoubleMatrix(M, 1, mxREAL);
    s = mxGetPr(plhs[0]);
    
    /* Copy input array to output array */
    for (i = 0; i < M; ++i) {s[i] = v[i];}
    
    /* Bubble sort algorithm */
    while ( true ) {
        swapped = false;
        for (i = 1; i < M; ++i) {
            if (s[i-1] > s[i]) {
                tmp = s[i-1];
                s[i-1] = s[i];
                s[i]   = tmp;
                swapped = true;
            }
        }
        if (!swapped) { return; }
    }       
}
/* From "Writing MATLAB C/MEX Code (Getreuer) */

#include "mex.h" /* Always include this */

void mexFunction(int nlhs, mxArray *plhs[],       /* Output variables */
                 int nrhs, const mxArray *prhs[]) /* Input variables */
{
    mexPrintf("Hello world!\n");
    return;
}
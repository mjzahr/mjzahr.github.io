function  b = delayed_copy_ex3(A)
b = 10*A(1,1); disp(A); A(1,1) = 5; disp(A);
end
function main_out = loc_func_ex()
main_out = ['I can call the ',loc_func()];
end

function loc_out = loc_func()
loc_out = 'local function';
end
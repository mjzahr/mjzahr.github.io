%% ODE solvers
eps = 1e-4;
f = @(t,y) y^2*(1-y);
[t45,y45]  =ode45(f,[0,2/eps],eps);
[t23s,y23s]=ode23s(f,[0,2/eps],eps);

length(t45)
length(t23s)

plot(t45,y45,'b-'); hold on;
plot(t23s,y23s,'r--');
syms rho lam mu u X1 X2 X3

X = [X1;X2;X3];
u = [X1*X2*X3;X1^2+X2^2;sin(X3)];
%% QR (regression)
load('regression_data.mat');
xfine = linspace(min(x),max(x),1000);
order = 5;

VV = vander(x);
V = VV(:,end-order:end);
[Q,R] = qr(V,0);
c = R\(Q'*y);

figure;
plot(x,y,'ro'); hold on;
plot(xfine,polyval(c,xfine),'k-','linew',2);
legend('Data','Polynomial');
print(gcf,'-depsc2','poly_fit');
load matrix1.mat
A = sparse(linsys.row,linsys.col,linsys.val);
b = linsys.b;
clear linsys;

%% Cholesky
p = amd(A);

R    = chol(A);
Ramd = chol(A(p,p));
Rinc = cholinc(A,1e-2);

figure;
subplot(2,2,1); spy(A); title('A');
subplot(2,2,2); spy(R); title('R');
subplot(2,2,3); spy(Ramd); title('R (amd)');
subplot(2,2,4); spy(Rinc); title('R (inc)');
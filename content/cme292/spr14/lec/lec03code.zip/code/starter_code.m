load matrix1.mat
A = sparse(linsys.row,linsys.col,linsys.val);
b = linsys.b;
clear linsys;
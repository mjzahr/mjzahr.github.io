[X,Y,Z,V] = flow();

set(gca,'View',[149.5, 44]);

syms rho u v p e gamma c

% Define quantities (U, V, Fx, Fy)

% Substitute expression for energy

% Compute jacobians

% Find wave speed matrices

% Before plugging into EVD, use expression for speed of sound
% Future simplification.

% Eigenvalue decomposition

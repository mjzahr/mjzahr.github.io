addpath('/path/to/nltruss');

mesh = 'mesh3';
nel = eval([mesh,'()']);
[msh,bcs,mat] = setup_problem(0.1*ones(nel,1),mesh);
func = @(W) staticResidual(W,msh,mat,bcs);
x0   = zeros(msh.ndof,1);

options = struct('maxit',1000);
[x,output] = newton_raphson(func,x0,options);